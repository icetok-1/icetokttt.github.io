#ifndef PAYMENT_H
#define PAYMENT_H

#include <QWidget>
#include <QtCharts>

namespace Ui {
class payment;
}

class payment : public QWidget
{
    Q_OBJECT

public:
    explicit payment(QWidget *parent = nullptr);
    ~payment();

private slots:
    void updateCharts(QChart *, QChart *, QChart *);
    void on_showTableBtn_clicked();

    void on_pushButton_clicked();

private:
    Ui::payment *ui;
};

#endif // PAYMENT_H
