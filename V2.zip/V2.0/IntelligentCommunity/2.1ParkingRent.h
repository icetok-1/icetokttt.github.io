#ifndef CHUZU_H
#define CHUZU_H

#include <QWidget>
#include <QTableView>
#include <QString>

namespace Ui {
class ParkingRent;
}

class ParkingRent : public QWidget
{
    Q_OBJECT

public:
    explicit ParkingRent(QWidget *parent = nullptr);
    ~ParkingRent();

private slots:
    void on_selectpushButton_clicked();

    void on_yespushButton_clicked();

private:
    Ui::ParkingRent *ui;
    void table1show();
    void table2show();
    void initTableView(QTableView *table, const QString &tip, int columnCount);
};

#endif // CHUZU_H
