#ifndef PersonnelManagement_H
#define PersonnelManagement_H

#include <QWidget>

namespace Ui {
class Widget;
}

class PersonnelManagement : public QWidget
{
    Q_OBJECT

public:
    explicit PersonnelManagement(QWidget *parent = nullptr);
    ~PersonnelManagement();

private slots:
    void on_pushButton_clicked();     // 查询
    void on_pushButton_2_clicked();   // 修改
    void on_pushButton_3_clicked();   // 添加
    void on_pushButton_4_clicked();   // 删除
    void on_pushButton_5_clicked();

private:
    void clearInputs();
    void setupStyles();

private:
    Ui::Widget *ui;
};

#endif // GUANLIYUANRENISHIGUANLI_H
