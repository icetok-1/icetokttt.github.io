#include "0.7AttendanceInquiry.h"
#include "ui_0.7AttendanceInquiry.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlError>
#include <QMessageBox>
#include <QHeaderView>
#include <QtCharts/QtCharts>
#include <QDate>
#include <QLabel>
#include <QFileDialog>
#include <QStandardPaths>
#include <QPdfWriter>
#include <QPainter>
using namespace QtCharts;
extern int useridentification;

AttendanceInquiry::AttendanceInquiry(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AttendanceInquiry)
{
    ui->setupUi(this);
    ui->lineEdit->setText(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation));
    setStyle();
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    this->setLayout(mainLayout);
    QLabel *titleLabel = new QLabel( this);
    QFont titleFont;
    titleFont.setPointSize(16);
    titleFont.setBold(true);
    titleLabel->setFont(titleFont);
    titleLabel->setAlignment(Qt::AlignCenter);
    QHBoxLayout *topLayout = new QHBoxLayout();
    topLayout->addWidget(ui->label);
    topLayout->addWidget(ui->lineEdit);
    topLayout->addWidget(ui->browseButton);
    topLayout->addWidget(ui->pushButton);
    mainLayout->addLayout(topLayout);
    auto *model = new QSqlQueryModel(this);
    if (!QSqlDatabase::database().isOpen()) {
        QMessageBox::warning(this, "数据库错误", "数据库连接未打开");
        return;
    }
    QString sql = "SELECT name, shangban, xiaban, date FROM attendance";
    QSqlQuery query;
    if (!query.exec(sql)) {
        QMessageBox::warning(this, "查询失败", "执行查询失败：" + query.lastError().text());
        return;
    }
    model->setQuery(sql);
    if (model->lastError().isValid()) {
        QMessageBox::warning(this, "查询失败", "读取出勤记录失败：" + model->lastError().text());
        return;
    }
    model->setHeaderData(0, Qt::Horizontal, "姓名");
    model->setHeaderData(1, Qt::Horizontal, "上班时间");
    model->setHeaderData(2, Qt::Horizontal, "下班时间");
    model->setHeaderData(3, Qt::Horizontal, "日期");
    ui->tableView->setModel(model);
    ui->tableView->horizontalHeader()->setStyleSheet(
        "QHeaderView::section { background-color: #87CEFA; color: black; font-weight: bold; }"
    );
    ui->tableView->horizontalHeader()->setVisible(true);
    ui->tableView->verticalHeader()->setVisible(true);
    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->setColumnWidth(0, 150);
    ui->tableView->setColumnWidth(1, 250);
    ui->tableView->setColumnWidth(2, 250);
    ui->tableView->setColumnWidth(3, 250);
    mainLayout->addWidget(ui->tableView);
    QTabWidget *chartTabs = new QTabWidget(this);
    mainLayout->addWidget(chartTabs);
    QWidget *pieTab = new QWidget();
    QVBoxLayout *pieLayout = new QVBoxLayout(pieTab);
    pieTab->setLayout(pieLayout);
    chartTabs->addTab(pieTab, "月度出勤状态分布");
    createPieChart(pieLayout);
    QWidget *userBarTab = new QWidget();
    QVBoxLayout *userBarLayout = new QVBoxLayout(userBarTab);
    chartTabs->addTab(userBarTab, "员工出勤统计");
    createUserAttendanceBarChart(userBarLayout); // 调用新图表函数
}
AttendanceInquiry::~AttendanceInquiry()
{
    delete ui;
}
void AttendanceInquiry::setStyle()
{
    QString buttonStyle = R"(
        QPushButton {
        border-radius: 4px;
        padding: 6px 12px;
        font-weight: bold;
        }

        QPushButton:hover {
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            background-color: white;
            color: palette(button-text);
        }

        QPushButton:pressed {
            background-color: palette(button);
            color: palette(button-text);
        }
    )";
    QString lineEditStyle = R"(
        QLineEdit {
            background-color: #bdc3c7;
            border: 1px solid #BDBDBD;
            border-radius: 8px;
            padding: 4px;
        }

        QLineEdit:focus {
            border: 2px solid #1976D2;
            background-color: #F5F5F5;
            outline: none;
        }
    )";
    QString tableViewStyle = R"(
        QTableView {
            alternate-background-color: #F5F5F5;
            selection-background-color: #BBDEFB;
            selection-color: black;
        }

        QTableView::item:hover {
            background-color: #EEEEEE;
        }
    )";
    QString tabStyle = R"(
        QTabWidget::pane {
            border: 1px solid #BDBDBD;
            background: white;
        }
        QTabBar::tab {
            background: #E0E0E0;
            border: 1px solid #BDBDBD;
            padding: 8px 15px;
            margin-right: 2px;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
        }
        QTabBar::tab:selected {
            background: #1976D2;
            color: white;
            font-weight: bold;
        }
        QTabBar::tab:hover {
            background: #64B5F6;
        }
    )";
    ui->tableView->setStyleSheet(ui->tableView->styleSheet() + tableViewStyle);
    this->setStyleSheet(this->styleSheet() + tabStyle);
}
void AttendanceInquiry::createPieChart(QVBoxLayout *layout)
{
    QSqlQuery query;
    query.exec(R"(
        SELECT
            SUM(CASE WHEN shangban LIKE '%(迟到)%' THEN 1 ELSE 0 END) AS late_count,
            SUM(CASE WHEN xiaban LIKE '%(早退)%' THEN 1 ELSE 0 END) AS early_count,
            SUM(CASE
                WHEN shangban NOT LIKE '%(迟到)%'
                AND xiaban NOT LIKE '%(早退)%'
                AND shangban IS NOT NULL
                AND xiaban IS NOT NULL
                THEN 1 ELSE 0
            END) AS normal_count,
            SUM(CASE WHEN shangban IS NULL OR xiaban IS NULL THEN 1 ELSE 0 END) AS absent_count
        FROM attendance
    )");
    if (!query.next()) {
        QMessageBox::warning(this, "数据错误", "无法获取出勤状态数据");
        return;
    }
    int lateCount = query.value(0).toInt();
    int earlyCount = query.value(1).toInt();
    int normalCount = query.value(2).toInt();
    int absentCount = query.value(3).toInt();
    QPieSeries *series = new QPieSeries();
    if (normalCount > 0) series->append("正常出勤 " + QString::number(normalCount), normalCount);
    if (lateCount > 0)   series->append("迟到 " + QString::number(lateCount), lateCount);
    if (earlyCount > 0)  series->append("早退 " + QString::number(earlyCount), earlyCount);
    if (absentCount > 0) series->append("缺勤 " + QString::number(absentCount), absentCount);
    double validTotal = series->sum();
    QList<QPieSlice*> slices = series->slices();
    for (int i = 0; i < slices.size(); ++i) {
        switch (i) {
            case 0: slices.at(i)->setColor(QColor(76, 175, 80)); break;
            case 1: slices.at(i)->setColor(QColor(255, 152, 0)); break;
            case 2: slices.at(i)->setColor(QColor(244, 67, 54)); break;
            case 3: slices.at(i)->setColor(QColor(96, 125, 139)); break;
        }
    }
    for (QPieSlice *slice : slices) {
        slice->setLabelVisible();
        double percentage = validTotal > 0 ? (slice->value() / validTotal) * 100.0 : 0;
        slice->setLabel(slice->label() + " - " + QString::number(percentage, 'f', 1) + "%");
        slice->setLabelPosition(QPieSlice::LabelOutside);
        slice->setLabelArmLengthFactor(0.1);
    }
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("全体员工出勤状态分布");
    chart->setAnimationOptions(QChart::SeriesAnimations);
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    layout->addWidget(chartView);
}

void AttendanceInquiry::createUserAttendanceBarChart(QVBoxLayout *layout)
{
    QSqlQuery query;
    if (!query.exec(R"(
        SELECT
            name,
            SUM(CASE WHEN shangban NOT LIKE '%(迟到)%' AND shangban IS NOT NULL AND xiaban IS NOT NULL THEN 1 ELSE 0 END) AS normal_count,
            SUM(CASE WHEN shangban LIKE '%(迟到)%' THEN 1 ELSE 0 END) AS late_count
        FROM attendance
        GROUP BY name
    )")) {
        QMessageBox::warning(this, "查询失败", "统计出勤数据失败：" + query.lastError().text());
        return;
    }
    QBarSet *normalSet = new QBarSet("正常出勤");
    QBarSet *lateSet = new QBarSet("迟到");
    QStringList categories;
    while (query.next()) {
        QString name = query.value(0).toString();
        int normal = query.value(1).toInt();
        int late = query.value(2).toInt();

        categories.append(name);
        *normalSet << normal;
        *lateSet << late;
    }
    QBarSeries *series = new QBarSeries();
    series->append(normalSet);
    series->append(lateSet);
    normalSet->setColor(QColor(76, 175, 80));
    lateSet->setColor(QColor(96, 125, 139));
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("员工出勤统计");
    chart->setAnimationOptions(QChart::SeriesAnimations);
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);
    QValueAxis *axisY = new QValueAxis();
    axisY->setTitleText("次数");
    axisY->setRange(0, 10);
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    layout->addWidget(chartView);
}
void AttendanceInquiry::on_browseButton_clicked()
{
    QString dir = QFileDialog::getExistingDirectory(this, "选择保存目录", ui->lineEdit->text());
    if (!dir.isEmpty()) {
        ui->lineEdit->setText(dir);
    }
}
void AttendanceInquiry::on_pushButton_clicked()
{
    QString path = ui->lineEdit->text();
    if (path.isEmpty()) {
        QMessageBox::critical(this, "错误", "保存路径不能为空");
        return;
    }
    QDir dir(path);
    if (!dir.exists()) {
        if (!dir.mkpath(".")) {
            QMessageBox::critical(this, "错误", "无法创建目录");
            return;
        }
    }
    QFile testFile(path + "/test_write.tmp");
    if (!testFile.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, "错误", "目录不可写: " + testFile.errorString());
        return;
    }
    testFile.remove();
    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        if (!db.open()) {
            QMessageBox::critical(this, "数据库错误", db.lastError().text());
            return;
        }
    }
       QString pdfPath = path + "/考勤记录.pdf";
       QPdfWriter writer(pdfPath);
       writer.setPageSize(QPageSize(QPageSize::A4));
       writer.setPageMargins(QMarginsF(20, 20, 20, 20));
       QPainter painter(&writer);
       if (!painter.isActive()) {
           QMessageBox::critical(this, "PDF错误", "无法创建PDF绘制器");
           return;
       }
       QFont font("SimSun", 10);
       painter.setFont(font);
       QFontMetrics fontMetrics(font);
       int nameWidth = fontMetrics.horizontalAdvance("姓名") + 1500;
       int shangbanWidth = fontMetrics.horizontalAdvance("上班时间") + 1500;
       int xiabanWidth = fontMetrics.horizontalAdvance("下班时间") + 1500;
       int dateWidth = fontMetrics.horizontalAdvance("2025-12-31") + 2000;
       int x = 1000;
       int y = 1000;
       const int rowHeight = fontMetrics.height() + 500;
       painter.setPen(Qt::black);
       painter.setBrush(QBrush(Qt::lightGray));
       painter.drawRect(x, y, nameWidth, rowHeight);
       painter.drawRect(x + nameWidth, y, shangbanWidth, rowHeight);
       painter.drawRect(x + nameWidth + shangbanWidth, y, xiabanWidth, rowHeight);
       painter.drawRect(x + nameWidth + shangbanWidth + xiabanWidth, y, dateWidth, rowHeight);
       painter.setPen(Qt::black);
       painter.drawText(x, y + rowHeight/2 + fontMetrics.ascent()/2, "姓名");
       painter.drawText(x + nameWidth, y + rowHeight/2 + fontMetrics.ascent()/2, "上班时间");
       painter.drawText(x + nameWidth + shangbanWidth, y + rowHeight/2 + fontMetrics.ascent()/2, "下班时间");
       painter.drawText(x + nameWidth + shangbanWidth + xiabanWidth, y + rowHeight/2 + fontMetrics.ascent()/2, "日期");
       y += rowHeight;
       QSqlQuery query("SELECT name, shangban, xiaban, date FROM attendance ORDER BY date", db);
       if (!query.exec()) {
           QMessageBox::critical(this, "查询错误", query.lastError().text());
           return;
       }
       painter.setBrush(Qt::NoBrush);
       int rowCount = 0;
       while (query.next()) {
           if (y > writer.height() - 1500) {
               writer.newPage();
               y = 1000;
               rowCount = 0;
               painter.setBrush(QBrush(Qt::lightGray));
               painter.drawRect(x, y, nameWidth, rowHeight);
               painter.drawRect(x + nameWidth, y, shangbanWidth, rowHeight);
               painter.drawRect(x + nameWidth + shangbanWidth, y, xiabanWidth, rowHeight);
               painter.drawRect(x + nameWidth + shangbanWidth + xiabanWidth, y, dateWidth, rowHeight);
               painter.setPen(Qt::black);
               painter.drawText(x, y + rowHeight/2 + fontMetrics.ascent()/2, "姓名");
               painter.drawText(x + nameWidth, y + rowHeight/2 + fontMetrics.ascent()/2, "上班时间");
               painter.drawText(x + nameWidth + shangbanWidth, y + rowHeight/2 + fontMetrics.ascent()/2, "下班时间");
               painter.drawText(x + nameWidth + shangbanWidth + xiabanWidth, y + rowHeight/2 + fontMetrics.ascent()/2, "日期");
               y += rowHeight;
               painter.setBrush(Qt::NoBrush);
           }
           painter.drawLine(x, y, x + nameWidth + shangbanWidth + xiabanWidth + dateWidth, y);
           painter.drawText(x, y + rowHeight/2 + fontMetrics.ascent()/2, query.value("name").toString());
           painter.drawText(x + nameWidth, y + rowHeight/2 + fontMetrics.ascent()/2, query.value("shangban").toString());
           painter.drawText(x + nameWidth + shangbanWidth, y + rowHeight/2 + fontMetrics.ascent()/2, query.value("xiaban").toString());
           painter.drawText(x + nameWidth + shangbanWidth + xiabanWidth, y + rowHeight/2 + fontMetrics.ascent()/2, query.value("date").toString());
           y += rowHeight;
           rowCount++;
       }
       painter.end();
       QMessageBox::information(this, "成功", "PDF导出成功: " + pdfPath);
   }
