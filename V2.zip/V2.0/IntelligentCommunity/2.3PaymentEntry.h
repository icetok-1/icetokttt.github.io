#ifndef PAYMENTENTRY_H
#define PAYMENTENTRY_H

#include <QWidget>
#include <QStandardItemModel>

QT_BEGIN_NAMESPACE
namespace Ui { class PaymentEntry; }
QT_END_NAMESPACE

class PaymentEntry : public QWidget
{
    Q_OBJECT

public:
    explicit PaymentEntry(QWidget *parent = nullptr);
    ~PaymentEntry();

private slots:
    void on_pushButton_clicked();      // 保存
    void on_pushButton_2_clicked();    // 删除
    void onOwnerSelectionChanged(const QString &text);

private:
    void populateOwnersComboBox();                 // 初始化 / 重新加载业主列表
    void appendRowToView(const QList<QString> &);  // 视图追加一行
    bool removeRowFromDb(const QList<QString> &);  // 数据库删除
    void clearInputFields();                       // 清空输入区

    void refreshTableView();
private:
    Ui::PaymentEntry *ui;
    QStandardItemModel *tableModel;
};

#endif // PAYMENTENTRY_H
