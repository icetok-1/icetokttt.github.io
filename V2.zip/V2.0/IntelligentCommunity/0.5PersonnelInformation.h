#ifndef PersonnelInformation_H
#define PersonnelInformation_H

#include <QWidget>
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QTableView>
#include <string>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlRelationalTableModel>
namespace Ui {
class PersonnelInformation;
}

class PersonnelInformation : public QWidget
{
    Q_OBJECT

public:
    explicit PersonnelInformation(QWidget *parent = nullptr);
    ~PersonnelInformation();

private slots:
    void on_pushButton_clicked();
    void on_btnDelete_clicked();
    void on_btnSave_clicked();
    void setupStyle();

private:
    Ui::PersonnelInformation *ui;
    QSqlDatabase db;
    QSqlTableModel *model;
};


#endif // PersonnelInformation_H
