#include "2.1ParkingRent.h"
#include "ui_2.1ParkingRent.h"
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlError>
#include <QDebug>
#include <QHeaderView>
#include <QStandardItemModel>
#include <QStyledItemDelegate>

class CenterAlignDelegate : public QStyledItemDelegate {
public:
    CenterAlignDelegate(QObject *parent = nullptr) : QStyledItemDelegate(parent) {}

    void initStyleOption(QStyleOptionViewItem *option,
                         const QModelIndex &index) const override {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;
    }
};

extern int useridentification;

ParkingRent::ParkingRent(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ParkingRent)
{
    ui->setupUi(this);

    // 初始化 tableView：未售出车位
    QStandardItemModel *initModel1 = new QStandardItemModel(1, 1, this);
    QStandardItem *item1 = new QStandardItem("请点击查询以查看未售出车位列表");
    item1->setTextAlignment(Qt::AlignCenter);
    initModel1->setItem(0, 0, item1);
    ui->tableView->setModel(initModel1);
    ui->tableView->setItemDelegate(new CenterAlignDelegate(this)); // 添加委托
    ui->tableView->horizontalHeader()->setVisible(false);
    ui->tableView->verticalHeader()->setVisible(false);
    ui->tableView->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Fixed);
    ui->tableView->horizontalHeader()->setDefaultSectionSize(this->width());

    // 初始化 tableView_2：申请记录
    QStandardItemModel *initModel2 = new QStandardItemModel(1, 1, this);
    QStandardItem *item2 = new QStandardItem("车位申请记录将在此处显示");
    item2->setTextAlignment(Qt::AlignCenter);
    initModel2->setItem(0, 0, item2);
    ui->tableView_2->setModel(initModel2);
    ui->tableView_2->setItemDelegate(new CenterAlignDelegate(this)); // 添加委托
    ui->tableView_2->horizontalHeader()->setVisible(false);
    ui->tableView_2->verticalHeader()->setVisible(false);
    ui->tableView_2->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);

    // 公共样式
    auto applyTableStyle = [](QTableView *table) {
        table->setAlternatingRowColors(true);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);

        table->setStyleSheet(R"(
            QTableView {
                font-style: italic;
                color: gray;
                gridline-color: lightgray;
                background-color: #fafafa;
                alternate-background-color: #f5f5f5;
            }
            QTableView::item:hover {
                background-color: #D6EAF8;
            }
        )");
    };

    applyTableStyle(ui->tableView);
    applyTableStyle(ui->tableView_2);
}

ParkingRent::~ParkingRent()
{
    delete ui;
}

void ParkingRent::table1show() {
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString sql = "SELECT number, addr, sellout, user_id FROM park WHERE sellout = '否'";
    model->setQuery(sql);
    model->setHeaderData(0, Qt::Horizontal, "车位编号");
    model->setHeaderData(1, Qt::Horizontal, "车位地址");
    model->setHeaderData(2, Qt::Horizontal, "是否出售");
    model->setHeaderData(3, Qt::Horizontal, "所有者");

    ui->tableView->setModel(model);
    ui->tableView->setItemDelegate(new CenterAlignDelegate(this)); // 添加委托
    ui->tableView->horizontalHeader()->setVisible(true);
    ui->tableView->setStyleSheet(R"(
        QTableView::item {
            font-style: normal;
            color: #202020;
        }
        QTableView {
            gridline-color: lightgray;
            background-color: white;
            alternate-background-color: #f5f5f5;
        }
        QTableView::item:hover {
            background-color: #D6EAF8;
        }
    )");

    ui->tableView->horizontalHeader()->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #7DC8F7;
            color: white;
            font-weight: bold;
            padding: 4px;
            border: 1px solid lightgray;
        }
    )");

    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    ui->tableView->setColumnWidth(0, 300);
    ui->tableView->setColumnWidth(1, 550);
    ui->tableView->setColumnWidth(2, 300);
    ui->tableView->setColumnWidth(3, 250);
}

void ParkingRent::table2show() {
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString sql = R"(
        SELECT s.parknum, s.state, s.date, u.name, u.IDcard, u.tel
        FROM ParkingApply AS s
        INNER JOIN usrlist AS u ON s.user_id = u.id

        ORDER BY s.date ASC
    )";
    model->setQuery(sql);
    model->setHeaderData(0, Qt::Horizontal, "车位编号");
    model->setHeaderData(1, Qt::Horizontal, "进度状态");
    model->setHeaderData(2, Qt::Horizontal, "申请时间");
    model->setHeaderData(3, Qt::Horizontal, "姓名");
    model->setHeaderData(4, Qt::Horizontal, "身份证号");
    model->setHeaderData(5, Qt::Horizontal, "联系方式");

    ui->tableView_2->setModel(model);
    ui->tableView_2->setItemDelegate(new CenterAlignDelegate(this)); // 添加委托
    ui->tableView_2->horizontalHeader()->setVisible(true);
    ui->tableView_2->setStyleSheet(R"(
        QTableView::item {
            font-style: normal;
            color: #202020;
        }
        QTableView {
            gridline-color: lightgray;
            background-color: white;
            alternate-background-color: #f5f5f5;
        }
        QTableView::item:hover {
            background-color: #D6EAF8;
        }
    )");

    ui->tableView_2->horizontalHeader()->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #7DC8F7;
            color: white;
            font-weight: bold;
            padding: 4px;
            border: 1px solid lightgray;
        }
    )");

    ui->tableView_2->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    ui->tableView_2->setColumnWidth(0, 200);
    ui->tableView_2->setColumnWidth(1, 150);
    ui->tableView_2->setColumnWidth(2, 200);
    ui->tableView_2->setColumnWidth(3, 150);
    ui->tableView_2->setColumnWidth(4, 410);
    ui->tableView_2->setColumnWidth(5, 300);
}

void ParkingRent::on_selectpushButton_clicked() {
    table1show();
    table2show();
}

void ParkingRent::on_yespushButton_clicked() {
    QString name = ui->namelineEdit->text().trimmed();
    QString IDcard = ui->IDlineEdit->text().trimmed();
    QString parkNumber = ui->numlineEdit->text().trimmed();

    if (name.isEmpty() || IDcard.isEmpty() || parkNumber.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请完整填写姓名、身份证号和车位编号！");
        return;
    }

    QSqlQuery query;
    QString getUserSql = QString("SELECT id FROM usrlist WHERE name='%1' AND IDcard='%2'")
                         .arg(name, IDcard);

    if (!query.exec(getUserSql) || !query.next()) {
        QMessageBox::warning(this, "错误", "用户信息不存在，请检查输入！");
        return;
    }

    QString userId = query.value(0).toString();

    QString checkParkSql = QString("SELECT sellout FROM park WHERE number='%1'").arg(parkNumber);
    if (!query.exec(checkParkSql) || !query.next()) {
        QMessageBox::warning(this, "错误", "车位不存在！");
        return;
    }
    if (query.value(0).toString() == "是") {
        QMessageBox::warning(this, "错误", "该车位已出售！");
        return;
    }

    QSqlDatabase::database().transaction();

    QString updateParkSql = QString("UPDATE park SET sellout='是', user_id=%1 WHERE number='%2'")
                            .arg(userId, parkNumber);
    if (!query.exec(updateParkSql)) {
        QSqlDatabase::database().rollback();
        QMessageBox::critical(this, "错误", "更新车位信息失败：" + query.lastError().text());
        return;
    }

    QString updatePassSql = QString("UPDATE ParkingApply SET state='已通过' "
                                     "WHERE user_id=%1 AND parknum='%2'")
                                     .arg(userId, parkNumber);
    if (!query.exec(updatePassSql)) {
        QSqlDatabase::database().rollback();
        QMessageBox::critical(this, "错误", "更新申请状态失败：" + query.lastError().text());
        return;
    }

    QString updateRejectSql = QString("UPDATE ParkingApply SET state='请另申车位' "
                                       "WHERE user_id != %1 AND parknum='%2'")
                                       .arg(userId, parkNumber);
    if (!query.exec(updateRejectSql)) {
        QSqlDatabase::database().rollback();
        QMessageBox::critical(this, "错误", "更新其他申请状态失败：" + query.lastError().text());
        return;
    }

    if (!QSqlDatabase::database().commit()) {
        QMessageBox::critical(this, "错误", "数据库提交失败：" + QSqlDatabase::database().lastError().text());
        return;
    }

    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString resultSql = QString(R"(
        SELECT p.number, p.addr, p.sellout, u.name, u.IDcard, u.tel
        FROM park AS p
        INNER JOIN usrlist AS u ON p.user_id = u.id
        WHERE u.IDcard = '%1'
    )").arg(IDcard);

    model->setQuery(resultSql);
    model->setHeaderData(0, Qt::Horizontal, "车位编号");
    model->setHeaderData(1, Qt::Horizontal, "车位地址");
    model->setHeaderData(2, Qt::Horizontal, "是否出售");
    model->setHeaderData(3, Qt::Horizontal, "购买者姓名");
    model->setHeaderData(4, Qt::Horizontal, "身份证号");
    model->setHeaderData(5, Qt::Horizontal, "联系方式");

    ui->tableView->setModel(model);
    ui->tableView->setItemDelegate(new CenterAlignDelegate(this)); // 添加委托

    table1show();
    table2show();

    QMessageBox::information(this, "操作成功", "车位分配成功！");
    ui->namelineEdit->clear();
    ui->IDlineEdit->clear();
    ui->numlineEdit->clear();
}
