#include "1.0ownermainwindow.h"
#include "DataBaseManagerAndMainWindow.h"
#include "ui_1.0ownermainwindow.h"
#include <ownerinfo.h>
#include "particlesystem.h"
#include "1.2baoxiu.h"
#include "1.3Trouble.h"
#include "1.1car.h"
#include "1.5SelfPayment.h"
#include "1.6welcome.h"
#include "carpark.h"
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QSplitter>
#include <QSqlQuery>
#include <QLabel>
#include <QFont>
#include <QPainter>
#include <notice.h>
extern int useridentification;
Owner_MainWindow::Owner_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Owner_MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("业主管理面板");
    this->setFixedSize(1700, 1100);
    m_particlesystem = new particlesystem(this);
    m_particlesystem->start();
    QTreeWidget *menuTree = new QTreeWidget;
    menuTree->setHeaderHidden(true);
    menuTree->setFixedWidth(260);
    menuTree->setStyleSheet(R"(
             QTreeWidget {
                 background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                 stop:0 #2079a1,
                 stop:1 #26cdcb);
                 border: none;
                 outline: 0;
              }
              QTreeWidget::item {
                background-color: transparent;
                border: none;
                padding: 6px 10px;
                margin: 2px;
                color: white;
                font-weight: bold;
                outline: none;
                border-radius:6px;
             }
             QTreeWidget::item:hover {
                background-color: qlineargradient(
                x1:0, y1:0.5, x2:1, y2:0.5,
                stop:0 rgba(33, 134, 167, 40),
                stop:1 rgba(29, 117, 146, 80)
                );
             }
             QTreeWidget::item:selected {
                 background-color: qlineargradient(
                 x1:0, y1:0.5, x2:1, y2:0.5,
                 stop:0 rgba(33, 134, 167, 40),
                 stop:1 rgba(29, 117, 146, 150)
                 );
                 color: white;
                 border: none;
             }
       )");

    QFont rootFont;  rootFont.setFamily("微软雅黑");  rootFont.setBold(true);  rootFont.setPointSize(16);
    QFont childFont; childFont.setFamily("微软雅黑"); childFont.setPointSize(12);
    //欢迎页
    QTreeWidgetItem *welcomeroot = new QTreeWidgetItem(menuTree, QStringList() << "首页");
    welcomeroot->setFont(0, rootFont);
    welcomeroot->setIcon(0, QIcon(":/iicoon/2.svg"));   // 请确保在 resources.qrc 中
    welcomeroot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *welcome = new QTreeWidgetItem(welcomeroot, QStringList() << " 欢迎");
    welcome->setFont(0, childFont);
    welcome->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *info = new QTreeWidgetItem(welcomeroot, QStringList() << " 个人信息");
    info->setFont(0, childFont);
    info->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *notices = new QTreeWidgetItem(welcomeroot, QStringList() << " 公告");
    notices->setFont(0, childFont);
    notices->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *returnpage = new QTreeWidgetItem(welcomeroot, QStringList() << " 返回登录界面");
    returnpage->setFont(0, childFont);
    returnpage->setSizeHint(0, QSize(200, 50));
    // 车位管理
    QTreeWidgetItem *parkRoot = new QTreeWidgetItem(menuTree, QStringList() << "车位管理");
    parkRoot->setFont(0, rootFont);
    parkRoot->setIcon(0, QIcon(":/iicoon/4.svg"));   // 请确保在 resources.qrc 中
    parkRoot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *parkInfo = new QTreeWidgetItem(parkRoot, QStringList() << " 车辆信息");
    parkInfo->setFont(0, childFont);
    parkInfo->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *carparkInfo = new QTreeWidgetItem(parkRoot, QStringList() << " 车位信息");
    carparkInfo->setFont(0, childFont);
    carparkInfo->setSizeHint(0, QSize(200, 50));
    // 缴费管理
    QTreeWidgetItem *payRoot = new QTreeWidgetItem(menuTree, QStringList() << "缴费管理");
    payRoot->setFont(0, rootFont);
    payRoot->setIcon(0, QIcon(":/iicoon/5.svg"));
    payRoot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *paySelf  = new QTreeWidgetItem(payRoot, QStringList() << " 自主缴费");
    paySelf->setFont(0, childFont);
    paySelf->setSizeHint(0, QSize(200, 50));

    // 维修管理
    QTreeWidgetItem *repairRoot = new QTreeWidgetItem(menuTree, QStringList() << "维修管理");
    repairRoot->setFont(0, rootFont);
    repairRoot->setIcon(0, QIcon(":/iicoon/6.svg"));
    repairRoot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *repairReport = new QTreeWidgetItem(repairRoot, QStringList() << " 故障报修");
    repairReport->setFont(0, childFont);
    repairReport->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *repairCheck = new QTreeWidgetItem(repairRoot, QStringList() << " 维修查询与评价");
    repairCheck->setFont(0, childFont);
    repairCheck->setSizeHint(0, QSize(200, 50));

    menuTree->setRootIsDecorated(true);
    menuTree->setIndentation(24);
    menuTree->collapseAll();

    QWidget *defaultPage = new Welcome;

    QSplitter *splitter = new QSplitter(this);
    splitter->addWidget(menuTree);
    splitter->addWidget(defaultPage);
    splitter->setStretchFactor(1, 1);
    splitter->setHandleWidth(2);
    splitter->setStyleSheet("QSplitter::handle { background-color: black; }");
    this->setCentralWidget(splitter);

    QString qwer = QString("SELECT * FROM usrlist WHERE id=%1").arg(useridentification);
    QSqlQuery query;
    query.exec(qwer);
    query.next();
    QString usrname = query.value(5).toString().trimmed();

    QLabel *normal = new QLabel(tr("欢迎您业主：%1").arg(usrname), this);
    ui->statusbar->addWidget(normal);
    ui->statusbar->setSizeGripEnabled(false);
    ui->statusbar->setStyleSheet("QStatusBar::item{border: 0px;}");

    connect(menuTree, &QTreeWidget::itemClicked, this,
        [=](QTreeWidgetItem *item, int)
    {
        QString text = item->text(0);
        QWidget *newPage = nullptr;

        if (text == " 车辆信息")              newPage = new car;
        else if (text == " 个人信息")         newPage = new ownerinfo;
        else if (text == " 欢迎")            newPage = new Welcome;
        else if (text == " 车位信息")         newPage = new Carpark;
        else if (text == " 公告")            newPage = new  notice;
        else if (text == " 自主缴费")         newPage = new SelfPayment;
        else if (text == " 故障报修")         newPage = new baoxiu;
        else if (text == " 维修查询与评价")    newPage = new Trouble;
        else if (text == " 返回登录界面"){
            MainWindow *w = new MainWindow();
            w->show();
            this->hide();
        }
        if (newPage) {
            QWidget *old = splitter->widget(1);
            splitter->replaceWidget(1, newPage);
            delete old;
        }
    });
}
void Owner_MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    m_particlesystem->draw(&painter);
}
Owner_MainWindow::~Owner_MainWindow()
{
    delete ui;
    delete m_particlesystem;
}
