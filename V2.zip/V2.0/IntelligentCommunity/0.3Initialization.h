#ifndef Initialization_H
#define Initialization_H

#include <QWidget>

namespace Ui {
class Initialization;
}

class Initialization : public QWidget
{
    Q_OBJECT

public:
    explicit Initialization(QWidget *parent = nullptr);
    ~Initialization();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Initialization *ui;
};

#endif // Initialization_H
