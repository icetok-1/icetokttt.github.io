#include "0.4LeaveApproval.h"
#include "ui_0.4LeaveApproval.h"
#include <QDebug>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlError>
#include <QMessageBox>

extern int useridentification;

LeaveApproval::LeaveApproval(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LeaveApproval)
{
    ui->setupUi(this);
    setStyle();
    connect(ui->tableView, &QTableView::clicked, this, &LeaveApproval::on_tableView_clicked);
    auto *model = new QSqlQueryModel(this);
    QString sql = "SELECT name, date, id, date2, shenpi, xiaojia, lid FROM leave";
    model->setQuery(sql);
    model->setHeaderData(0, Qt::Horizontal, "姓名");
    model->setHeaderData(1, Qt::Horizontal, "请假时间");
    model->setHeaderData(2, Qt::Horizontal, "请假事由");
    model->setHeaderData(3, Qt::Horizontal, "结束时间");
    model->setHeaderData(4, Qt::Horizontal, "审批结果");
    model->setHeaderData(5, Qt::Horizontal, "销假时间");
    model->setHeaderData(6, Qt::Horizontal, "请假id");
    ui->tableView->setModel(model);
    ui->tableView->setColumnHidden(6, true);
    ui->tableView->horizontalHeader()->setStyleSheet(
        "QHeaderView::section { background-color: #87CEFA; color: black; font-weight: bold; }"
    );
    ui->tableView->horizontalHeader()->setVisible(true);
    ui->tableView->verticalHeader()->setVisible(true);
    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->setColumnWidth(0, 100);
    ui->tableView->setColumnWidth(1, 150);
    ui->tableView->setColumnWidth(2, 200);
    ui->tableView->setColumnWidth(3, 150);
    ui->tableView->setColumnWidth(4, 150);
    ui->tableView->setColumnWidth(5, 150);
    ui->tableView->setColumnWidth(6, 150);
}
LeaveApproval::~LeaveApproval()
{
    delete ui;
}
void LeaveApproval::on_pushButton_clicked()
{
    auto *model = new QSqlQueryModel(this);
    QString sql = "SELECT name, date, id, date2, shenpi, xiaojia, lid FROM leave";
    model->setQuery(sql);

    if (model->lastError().isValid()) {
        QMessageBox::warning(this, "更新失败", "无法获取请假记录：" + model->lastError().text());
        return;
    }
    model->setHeaderData(0, Qt::Horizontal, "姓名");
    model->setHeaderData(1, Qt::Horizontal, "请假时间");
    model->setHeaderData(2, Qt::Horizontal, "请假事由");
    model->setHeaderData(3, Qt::Horizontal, "结束时间");
    model->setHeaderData(4, Qt::Horizontal, "审批结果");
    model->setHeaderData(5, Qt::Horizontal, "销假时间");
    model->setHeaderData(6, Qt::Horizontal, "请假id");
    ui->tableView->setColumnHidden(6, true);//隐藏请假id
    ui->tableView->setModel(model);
    ui->tableView->setColumnWidth(0, 100);
    ui->tableView->setColumnWidth(1, 150);
    ui->tableView->setColumnWidth(2, 200);
    ui->tableView->setColumnWidth(3, 150);
    ui->tableView->setColumnWidth(4, 150);
    ui->tableView->setColumnWidth(5, 150);
    ui->tableView->setColumnWidth(6, 150);
    ui->tableView->horizontalHeader()->setStyleSheet(
        "QHeaderView::section { background-color: #87CEFA; color: black; font-weight: bold; }"
    );
}
void LeaveApproval::on_pushButton_2_clicked()
{
    QString approvalResult = ui->lineEdit_5->text().trimmed();
    if (currentLeaveId.isEmpty() || approvalResult.isEmpty()) {
        QMessageBox::information(this, "输入不完整", "请输入姓名和审批结果");
        return;
    }
    QSqlQuery query;
    query.prepare("UPDATE leave SET shenpi = :shenpi WHERE lid = :lid");
    query.bindValue(":shenpi", approvalResult);
    query.bindValue(":lid", currentLeaveId); // 使用类成员ID进行更新
    if (!query.exec()) {
        QMessageBox::critical(this, "修改失败", "审批结果保存失败：" + query.lastError().text());
        return;
    }
    QMessageBox::information(this, "操作成功", "审批结果可更新查看！");
    ui->lineEdit->clear();
    ui->lineEdit_5->clear();
}
void LeaveApproval::setStyle()
{
    QString buttonStyle = R"(
        QPushButton {
        border-radius: 4px;
        padding: 6px 12px;
        font-weight: bold;

        }
        QPushButton:hover {
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            background-color: white;
            color: palette(button-text);
        }
        QPushButton:pressed {
            background-color: palette(button);
            color: palette(button-text);
        }
    )";
    QString lineEditStyle = R"(
        QLineEdit {
            background-color: #bdc3c7;
            border: 1px solid #BDBDBD;
            border-radius: 8px;
            padding: 4px;
        }

        QLineEdit:focus {
            border: 2px solid #1976D2;
            background-color: #F5F5F5;
            outline: none;
        }

    )";
    QString tableViewStyle = R"(
        QTableView {
            alternate-background-color: #F5F5F5;
            selection-background-color: #BBDEFB;
            selection-color: black;
        }

        QTableView::item:hover {
            background-color: #EEEEEE;
        }
    )";
    ui->lineEdit->setStyleSheet(lineEditStyle);
    ui->lineEdit_5->setStyleSheet(lineEditStyle);
    QString existingTableStyle = ui->tableView->styleSheet();
    ui->tableView->setStyleSheet(existingTableStyle + tableViewStyle);
}
void LeaveApproval::on_tableView_clicked(const QModelIndex &index)
{
    QSqlQueryModel *model = qobject_cast<QSqlQueryModel*>(ui->tableView->model());
    if (model) {
        QString name = model->data(model->index(index.row(), 0)).toString();
        QString approval = model->data(model->index(index.row(), 4)).toString();
        currentLeaveId = model->data(model->index(index.row(), 6)).toString();
        ui->lineEdit->setText(name);
        ui->lineEdit_5->setText(approval);
    }
}
