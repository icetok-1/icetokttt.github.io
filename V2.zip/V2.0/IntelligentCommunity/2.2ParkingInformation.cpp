#include "2.2ParkingInformation.h"
#include "ui_2.2ParkingInformation.h"

#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QString>
#include <QDebug>
#include <QMessageBox>
#include <QTableView>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QStyledItemDelegate>

class CenterAlignDelegate : public QStyledItemDelegate {
public:
    using QStyledItemDelegate::QStyledItemDelegate;
    void initStyleOption(QStyleOptionViewItem *option, const QModelIndex &index) const override {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;
    }
};

extern int useridentification;

ParkingInformation::ParkingInformation(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ParkingInformation)
{
    ui->setupUi(this);

    ui->tableView->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #e7f9ff;
            color: black;
            padding: 4px;
            border: 1px solid #ddd;
            font-weight: bold;
        }
    )");

    connect(ui->tableView, &QTableView::clicked,
            this, &ParkingInformation::on_tableView_clicked);

    loadAllParkingData();
}

ParkingInformation::~ParkingInformation()
{
    delete ui;
}

void ParkingInformation::loadAllParkingData()
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString sql = "SELECT number, addr, sellout, user_id FROM park";
    model->setQuery(sql);

    model->setHeaderData(0, Qt::Horizontal, "车位编号");
    model->setHeaderData(1, Qt::Horizontal, "车位地址");
    model->setHeaderData(2, Qt::Horizontal, "是否出售");
    model->setHeaderData(3, Qt::Horizontal, "所有者");

    ui->tableView->setModel(model);

    // 设置列宽
    ui->tableView->setColumnWidth(0, 300);
    ui->tableView->setColumnWidth(1, 550);
    ui->tableView->setColumnWidth(2, 200);
    ui->tableView->setColumnWidth(3, 300);

    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    ui->tableView->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);

    for (int col = 0; col < 4; ++col)
        ui->tableView->setItemDelegateForColumn(col, new CenterAlignDelegate(this));
}

void ParkingInformation::on_addButton_clicked()
{
    QString number = ui->numEdit->text().trimmed();
    QString addr = ui->addrEdit->text().trimmed();
    QString userId = ui->useridEdit->text().trimmed();

    QString sellout;
    if (ui->yradioButton->isChecked()) {
        sellout = "是";
    } else if (ui->nradioButton->isChecked()) {
        sellout = "否";
    }

    if (number.isEmpty() || addr.isEmpty() || sellout.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请完整填写所有字段！");
        return;
    }

    QSqlQuery query;
    QString sql = QString("INSERT INTO park (number, addr, sellout, user_id) "
                          "VALUES ('%1', '%2', '%3', '%4')")
                          .arg(number, addr, sellout, userId);

    if (!query.exec(sql)) {
        QMessageBox::critical(this, "插入失败", "数据库插入失败：" + query.lastError().text());
        return;
    }

    QMessageBox::information(this, "成功", "车位添加成功！");
    loadAllParkingData();
}

void ParkingInformation::on_modifyButton_clicked()
{
    QString number = ui->numEdit->text().trimmed();
    QString addr = ui->addrEdit->text().trimmed();
    QString userId = ui->useridEdit->text().trimmed();

    QString sellout;
    if (ui->yradioButton->isChecked()) {
        sellout = "是";
    } else if (ui->nradioButton->isChecked()) {
        sellout = "否";
    }

    if (number.isEmpty() || addr.isEmpty() || sellout.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请完整填写所有字段！");
        return;
    }

    QSqlDatabase db = QSqlDatabase::database();
    db.transaction(); // 开始事务

    QSqlQuery checkParkQuery;
    checkParkQuery.prepare("SELECT COUNT(*) FROM park WHERE number = :number");
    checkParkQuery.bindValue(":number", number);

    if (!checkParkQuery.exec() || !checkParkQuery.next()) {
        QMessageBox::critical(this, "查询失败", "检查车位失败：" + checkParkQuery.lastError().text());
        return;
    }

    if (checkParkQuery.value(0).toInt() == 0) {
        QMessageBox::warning(this, "车位不存在", QString("车位编号 %1 不存在！").arg(number));
        return;
    }

    if (!userId.isEmpty()) {
        QSqlQuery checkUserQuery;
        checkUserQuery.prepare("SELECT COUNT(*) FROM usrlist WHERE id = :userId");
        checkUserQuery.bindValue(":userId", userId);

        if (!checkUserQuery.exec() || !checkUserQuery.next()) {
            QMessageBox::critical(this, "查询失败", "检查用户失败：" + checkUserQuery.lastError().text());
            return;
        }

        if (checkUserQuery.value(0).toInt() == 0) {
            QMessageBox::warning(this, "用户不存在", QString("用户ID %1 不存在！").arg(userId));
            return;
        }
    }

    QSqlQuery updateQuery;
    updateQuery.prepare("UPDATE park SET "
                        "addr = :addr, "
                        "sellout = :sellout, "
                        "user_id = :user_id "
                        "WHERE number = :number");

    updateQuery.bindValue(":addr", addr);
    updateQuery.bindValue(":sellout", sellout);
    updateQuery.bindValue(":number", number);

    if (userId.isEmpty()) {
        updateQuery.bindValue(":user_id", QVariant(QVariant::Int));
    } else {
        updateQuery.bindValue(":user_id", userId.toInt());
    }

    if (!updateQuery.exec()) {
        db.rollback();
        QMessageBox::critical(this, "修改失败", "数据库更新失败：" + updateQuery.lastError().text());
        return;
    }

    if (sellout == "是" && !userId.isEmpty()) {
        QSqlQuery checkOwnershipQuery;
        checkOwnershipQuery.prepare("SELECT COUNT(*) FROM park WHERE user_id = :user_id AND sellout = '是'");
        checkOwnershipQuery.bindValue(":user_id", userId.toInt());

        if (checkOwnershipQuery.exec() && checkOwnershipQuery.next() &&
            checkOwnershipQuery.value(0).toInt() > 1) {
            QMessageBox::warning(this, "警告",
                QString("用户ID %1 已拥有其他车位！一个用户只能拥有一个车位。").arg(userId));
            db.rollback();
            return;
        }
    }

    if (db.commit()) {
        QMessageBox::information(this, "成功", "车位信息修改成功！");
        loadAllParkingData();
    } else {
        QMessageBox::critical(this, "提交失败", "事务提交失败：" + db.lastError().text());
    }
}


void ParkingInformation::on_queryButton_clicked()
{
    QString number = ui->numEdit->text().trimmed();
    if (number.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请输入车位编号进行查询！");
        return;
    }

    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString sql = QString("SELECT number, addr, sellout, user_id FROM park WHERE number='%1'")
                  .arg(number);

    model->setQuery(sql);

    if (model->rowCount() == 0) {
        QMessageBox::information(this, "查询结果", "未找到对应车位编号！");
    }

    model->setHeaderData(0, Qt::Horizontal, "车位编号");
    model->setHeaderData(1, Qt::Horizontal, "车位地址");
    model->setHeaderData(2, Qt::Horizontal, "是否出售");
    model->setHeaderData(3, Qt::Horizontal, "所有者");

    ui->tableView->setModel(model);

    ui->tableView->setColumnWidth(0, 300);
    ui->tableView->setColumnWidth(1, 550);
    ui->tableView->setColumnWidth(2, 200);
    ui->tableView->setColumnWidth(3, 300);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    ui->tableView->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);

    for (int col = 0; col < 4; ++col)
        ui->tableView->setItemDelegateForColumn(col, new CenterAlignDelegate(this));
}

void ParkingInformation::on_pushButton_clicked()
{
    loadAllParkingData();
}

void ParkingInformation::on_tableView_clicked(const QModelIndex &index)
{
    int row = index.row();
    QAbstractItemModel *model = ui->tableView->model();

    QString number = model->data(model->index(row, 0)).toString();
    QString addr = model->data(model->index(row, 1)).toString();
    QString userId = model->data(model->index(row, 3)).toString(); // 第3列是user_id

    ui->numEdit->setText(number);
    ui->addrEdit->setText(addr);
    ui->useridEdit->setText(userId);
}
