#ifndef OwnerInformation_H
#define OwnerInformation_H

#include <QWidget>
#include <QModelIndex>
#include <QSqlTableModel>
namespace Ui {
class OwnerInformation;
}

class OwnerInformation : public QWidget
{
    Q_OBJECT

public:
    explicit OwnerInformation(QWidget *parent = nullptr);
    ~OwnerInformation();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_tableView_clicked(const QModelIndex &index);
private:
    Ui::OwnerInformation *ui;
    QSqlTableModel *model = nullptr;
};

#endif // OwnerInformation_H
