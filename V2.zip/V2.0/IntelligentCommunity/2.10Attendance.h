#ifndef MONTHLYATTENDANCE_H
#define MONTHLYATTENDANCE_H

#include <QWidget>

#include <QDebug>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QTableView>
#include <string>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlRelationalTableModel>
namespace Ui {
class Attendance;
}

class Attendance : public QWidget
{
    Q_OBJECT

public:
    explicit Attendance(QWidget *parent = nullptr);
    ~Attendance();
private slots:
    void on_pushButton1_clicked();

private:
    Ui::Attendance *ui;
    void refreshTableView();
};

#endif // MONTHLYATTENDANCE_H
