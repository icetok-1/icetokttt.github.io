#include "1.1car.h"
#include "ui_1.1car.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QDebug>
#include <QDate>
#include <QItemSelectionModel>
#include <QSqlRecord>
#include <QSqlError>
extern int useridentification;

car::car(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::car)
{
    ui->setupUi(this);
    ui->numlineEdit->setPlaceholderText("车牌号");
    ui->brandlineEdit->setPlaceholderText("车辆品牌");
    ui->colorlineEdit->setPlaceholderText("车辆颜色");
    table1show();
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    connect(ui->tableView, &QTableView::clicked, this, &car::on_tableView_clicked);

}

car::~car()
{
    delete ui;
}
void car::table1show()
{
    auto *model = new QSqlQueryModel(this);
    model->setQuery(QString("SELECT car_id, color, brand FROM car WHERE user_id = %1").arg(useridentification));
    model->setHeaderData(0, Qt::Horizontal, "车牌号");
    model->setHeaderData(1, Qt::Horizontal, "颜色");
    model->setHeaderData(2, Qt::Horizontal, "品牌");

    ui->tableView->setModel(model);
    qDebug() << "车辆记录数：" << model->rowCount();
    if (auto *header = ui->tableView->horizontalHeader())
    {
        header->setSectionResizeMode(QHeaderView::Interactive);
        header->resizeSection(0, 300);
        header->resizeSection(1, 500);
        header->resizeSection(2, 120);
        header->setStretchLastSection(true);
    }

}
void car::on_pushButton_clicked()
{
    QString car_id    = ui->numlineEdit->text().trimmed();
    QString car_color = ui->colorlineEdit->text().trimmed();
    QString car_brand = ui->brandlineEdit->text().trimmed();

    if (car_id.isEmpty() || car_color.isEmpty() || car_brand.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请填写完整车辆信息");
        return;
    }

    {
        QSqlQuery checkQuery;
        checkQuery.prepare(
            "SELECT COUNT(*) "
            "FROM car "
            "WHERE car_id = :car_id"
        );
        checkQuery.bindValue(":car_id", car_id);
        if (!checkQuery.exec()) {
            QMessageBox::critical(
                this,
                "数据库错误",
                QString("校验车牌号时出错：%1").arg(checkQuery.lastError().text())
            );
            return;
        }
        if (checkQuery.next() && checkQuery.value(0).toInt() > 0) {
            QMessageBox::warning(this, "重复提交", "该车牌号已存在，无法重复提交");
            return;
        }
    }

    {
        QSqlQuery insertQuery;
        insertQuery.prepare(
            "INSERT INTO car (color, brand, car_id, user_id) "
            "VALUES (:color, :brand, :car_id, :user_id)"
        );
        insertQuery.bindValue(":color",    car_color);
        insertQuery.bindValue(":brand",    car_brand);
        insertQuery.bindValue(":car_id",   car_id);
        insertQuery.bindValue(":user_id",  useridentification);
        if (!insertQuery.exec()) {
            QMessageBox::critical(
                this,
                "错误",
                QString("添加车辆失败：%1").arg(insertQuery.lastError().text())
            );
            return;
        }
    }

    ui->numlineEdit->clear();
    ui->colorlineEdit->clear();
    ui->brandlineEdit->clear();
    table1show();
}

void car::on_delpushButton_clicked()
{
    QModelIndexList selectedRows = ui->tableView->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this, "选择错误", "请先在表格中选择要删除的车辆");
        return;
    }

    // 获取车牌号（使用第一列数据）
    int row = selectedRows.first().row();
    QString carId = ui->tableView->model()->index(row, 0).data().toString();

    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "确认删除",
        QString("确定要删除车牌号为【%1】的车辆信息吗？").arg(carId),
        QMessageBox::Yes | QMessageBox::No
    );

    if (reply != QMessageBox::Yes) return;

    // 执行删除
    QSqlQuery query;
    query.prepare("DELETE FROM car WHERE car_id = ? AND user_id = ?");
    query.addBindValue(carId);
    query.addBindValue(useridentification);

    if (!query.exec()) {
        QMessageBox::critical(this, "错误", "删除失败: " + query.lastError().text());
    } else if (query.numRowsAffected() > 0) {
        QMessageBox::information(this, "成功", "车辆删除成功！");
        ui->numlineEdit->clear();
        ui->colorlineEdit->clear();
        ui->brandlineEdit->clear();
        table1show();
    } else {
        QMessageBox::warning(this, "错误", "未找到该车辆信息");
    }
}
void car::on_tableView_clicked(const QModelIndex &index)
{
    // 确保模型有效
    if (auto *model = ui->tableView->model()) {
        // 获取选中行的数据
        int row = index.row();
        QString licensePlate = model->data(model->index(row, 0)).toString();
        QString color = model->data(model->index(row, 1)).toString();
        QString brand = model->data(model->index(row, 2)).toString();

        // 填充到界面控件
        /*ui->numlineEdit->setText(licensePlate);
        ui->brandlineEdit->setText(brand);
        ui->colorlineEdit->setText(color);*/

        // 自动选中整行（确保选择模式已设置）
        ui->tableView->selectRow(row);
    }
}
