#include "2.8MaintainManage.h"
#include "ui_2.8MaintainManage.h"

#include <QSqlError>
#include <QMessageBox>
#include <QHeaderView>

extern int useridentification;

MaintainManage::MaintainManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MaintainManage)
{
    ui->setupUi(this);

    ui->tableView->setEditTriggers(QAbstractItemView::DoubleClicked |
                                   QAbstractItemView::SelectedClicked);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setItemDelegate(new CenterAlignDelegate(this)); // 居中显示

    ui->tableView->horizontalHeader()->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #E6F2FF;  /* 淡蓝色 */
            color: black;
            padding: 4px;
            border: 1px solid #dcdcdc;
            font-weight: bold;
        })");

    ui->tableView->setAlternatingRowColors(true);  // 启用交替颜色
    ui->tableView->setStyleSheet(R"(
        QTableView {
            alternate-background-color: #F7F7F7;  /* 淡灰色 */
            background-color: white;
            gridline-color: #cccccc;
        })");

    initModel();
    model->select();
}

MaintainManage::~MaintainManage()
{
    delete ui;
}

void MaintainManage::initModel()
{
    if (model) return;

    model = new WeixiuTableModel(this);
    model->setTable("weixiu");
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);

    QStringList headers = { u8"序号", u8"姓名", u8"电话", u8"地址",
                            u8"问题描述", u8"受理情况", u8"维修进度",
                            u8"维修评价", u8"工作人员", u8"ID" };
    for (int i = 0; i < headers.size(); ++i)
        model->setHeaderData(i, Qt::Horizontal, headers.at(i));

    ui->tableView->setModel(model);
    ui->tableView->hideColumn(9);  // 隐藏ID列

    ui->tableView->setColumnWidth(0, 120);  // 序号
    ui->tableView->setColumnWidth(1, 130);  // 姓名
    ui->tableView->setColumnWidth(2, 200);  // 电话
    ui->tableView->setColumnWidth(3, 200);  // 地址
    ui->tableView->setColumnWidth(4, 200);  // 问题描述
    ui->tableView->setColumnWidth(5, 130);  // 受理情况
    ui->tableView->setColumnWidth(6, 130);  // 维修进度
    ui->tableView->setColumnWidth(7, 150);  // 维修评价
    ui->tableView->setColumnWidth(8, 130);  // 工作人员
}

void MaintainManage::on_pushButton_clicked()
{
    initModel();
    model->select();
}

void MaintainManage::on_pushButton_2_clicked()
{
    if (!model) {
        QMessageBox::information(this, "提示", "请先加载数据！");
        return;
    }

    if (model->submitAll()) {
        model->select();
        QMessageBox::information(this, "成功", "修改已保存！");
    } else {
        QMessageBox::warning(this, "保存失败",
                              "数据库提交失败：\n" + model->lastError().text());
        model->revertAll();
    }
}

void MaintainManage::on_pushButton_3_clicked()
{
    if (!model) {
        QMessageBox::information(this, "提示", "请先加载数据！");
        return;
    }

    int row = ui->tableView->currentIndex().row();
    if (row < 0) {
        QMessageBox::warning(this, "警告", "请先选中要删除的行！");
        return;
    }

    int ret = QMessageBox::question(this, "删除报修记录",
                                    "确认删除当前所选记录？",
                                    QMessageBox::Yes | QMessageBox::No);
    if (ret == QMessageBox::No) return;

    model->removeRow(row);
    if (model->submitAll()) {
        model->select();
        QMessageBox::information(this, "成功", "删除成功！");
    } else {
        QMessageBox::warning(this, "删除失败",
                              "数据库提交失败：\n" + model->lastError().text());
        model->revertAll();
    }
}
