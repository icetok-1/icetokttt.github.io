#include "0.0admin_mainwindow.h"
#include "ui_0.0admin_mainwindow.h"
#include "0.8repairmanage.h"
#include "0.6PersonnelManagement.h"
#include "0.7AttendanceInquiry.h"
#include "0.4LeaveApproval.h"
#include "0.3Initialization.h"
#include "0.2About.h"
#include "0.5PersonnelInformation.h"
#include "welcome.h"
#include "0.8repairmanage.h"
#include "0.9payment.h"
#include <QTreeWidget>
#include <DataBaseManagerAndMainWindow.h>
#include <QTreeWidgetItem>
#include <QSqlQuery>
#include <QLabel>
#include <QSplitter>
#include <QVBoxLayout>
#include <QPainter>
#include <editnotice.h>
extern int useridentification;
admin_MainWindow::admin_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::admin_MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("管理员管理面板");
    this->setFixedSize(1700, 1100);
    m_particlesystem = new particlesystem(this);
    m_particlesystem->start();
    QTreeWidget *menuTree = new QTreeWidget;
    menuTree->setHeaderHidden(true);
    menuTree->setFixedWidth(260);
    menuTree->setStyleSheet(R"(
             QTreeWidget {
                 background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                 stop:0 #2079a1,
                 stop:1 #26cdcb);
                 border: none;
                 outline: 0;
              }
              QTreeWidget::item {
                background-color: transparent;  /* 透明以显示渐变背景 */
                border: none;
                padding: 6px 10px;
                margin: 2px;
                color: white;
                font-weight: bold;
                outline: none;
                border-radius:6px;
             }
             QTreeWidget::item:hover {
                background-color: qlineargradient(
                x1:0, y1:0.5, x2:1, y2:0.5,
                stop:0 rgba(33, 134, 167, 40),
                stop:1 rgba(29, 117, 146, 80)
                );
             }
             QTreeWidget::item:selected {
                 background-color: qlineargradient(
                 x1:0, y1:0.5, x2:1, y2:0.5,
                 stop:0 rgba(33, 134, 167, 40),
                 stop:1 rgba(29, 117, 146, 150)
                 );
                 color: white;
                 border: none;
             }
       )");

    QFont rootFont;
    rootFont.setFamily("微软雅黑");
    rootFont.setBold(true);
    rootFont.setPointSize(16);

    QFont childFont;
    childFont.setFamily("微软雅黑");
    childFont.setPointSize(12);

    QTreeWidgetItem *systemRoot = new QTreeWidgetItem(menuTree, QStringList() << "系统设置");
    systemRoot->setFont(0, rootFont);
    systemRoot->setIcon(0, QIcon(":/iicoon/1.svg"));
    systemRoot->setSizeHint(0, QSize(200, 95));
    QTreeWidgetItem *sysInit = new QTreeWidgetItem(systemRoot, QStringList() << "  系统初始化");
    QTreeWidgetItem *sysWel = new QTreeWidgetItem(systemRoot, QStringList() << "  欢迎页");
    QTreeWidgetItem *w = new QTreeWidgetItem(systemRoot, QStringList() << "  返回登录界面");
    sysInit->setFont(0, childFont);
    sysInit->setSizeHint(0, QSize(200, 50));

    sysWel->setFont(0, childFont);
    sysWel->setSizeHint(0, QSize(200, 50));

    w->setFont(0, childFont);
    w->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *personnelRoot = new QTreeWidgetItem(menuTree, QStringList() << "人事管理");
    personnelRoot->setFont(0, rootFont);
    personnelRoot->setIcon(0, QIcon(":/iicoon/2.svg"));
    personnelRoot->setSizeHint(0, QSize(200, 95));
    QTreeWidgetItem *perManage = new QTreeWidgetItem(personnelRoot, QStringList() << "  人事管理");
    QTreeWidgetItem *perQuery = new QTreeWidgetItem(personnelRoot, QStringList() << "  人事信息");
    QTreeWidgetItem *pernotice = new QTreeWidgetItem(personnelRoot, QStringList() << "  公告管理");

    perManage->setFont(0, childFont);
    perManage->setSizeHint(0, QSize(200, 50));

    perQuery->setFont(0, childFont);
    perQuery->setSizeHint(0, QSize(200, 50));

    pernotice->setFont(0, childFont);
    pernotice->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *attendanceRoot = new QTreeWidgetItem(menuTree, QStringList() << "出勤管理");
    attendanceRoot->setFont(0, rootFont);
    attendanceRoot->setIcon(0, QIcon(":/iicoon/3.svg"));
    attendanceRoot->setSizeHint(0, QSize(200, 95));
    QTreeWidgetItem *attMonth = new QTreeWidgetItem(attendanceRoot, QStringList() << "  月度出勤");
    QTreeWidgetItem *attLeave = new QTreeWidgetItem(attendanceRoot, QStringList() << "  请假审批");
    attMonth->setFont(0, childFont);
    attMonth->setSizeHint(0, QSize(200, 50));

    attLeave->setFont(0, childFont);
    attLeave->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *repairRoot = new QTreeWidgetItem(menuTree, QStringList() << "维修管理");
    repairRoot->setFont(0, rootFont);
    repairRoot->setIcon(0, QIcon(":/iicoon/6.svg"));
    repairRoot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *repMonth = new QTreeWidgetItem(repairRoot, QStringList() << "  指派工作");
    repMonth->setFont(0, childFont);
    repMonth->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *paymentRoot = new QTreeWidgetItem(menuTree, QStringList() << "财务信息");
    paymentRoot->setFont(0, rootFont);
    paymentRoot->setIcon(0, QIcon(":/iicoon/5.svg"));
    paymentRoot->setSizeHint(0, QSize(200, 95));
    QTreeWidgetItem *payMonth = new QTreeWidgetItem(paymentRoot, QStringList() << "  财务统计");

    payMonth->setFont(0, childFont);
    payMonth->setSizeHint(0, QSize(200, 50));

    menuTree->setRootIsDecorated(true);
    menuTree->setIndentation(18);
    menuTree->collapseAll();

    QWidget *defaultPage = new Welcome;

    splitter = new QSplitter(this);
    splitter->addWidget(menuTree);
    splitter->addWidget(defaultPage);
    splitter->setStretchFactor(1, 1);
    splitter->setHandleWidth(2);
    splitter->setStyleSheet("QSplitter::handle { background-color: black; }");
    this->setCentralWidget(splitter);

    QString qwer = QString("SELECT * FROM usrlist WHERE id=%1").arg(useridentification);
    QSqlQuery query;
    query.exec(qwer);
    query.next();
    QString usrname = query.value(5).toString().trimmed();
    QLabel *normal = new QLabel(tr("欢迎您管理员：%1").arg(usrname), this);
    ui->statusbar->addWidget(normal);
    ui->statusbar->setSizeGripEnabled(false);
    ui->statusbar->setStyleSheet("QStatusBar::item{border: 0px;}");

    connect(menuTree, &QTreeWidget::itemClicked, this, [=](QTreeWidgetItem *item, int) {
        QString text = item->text(0);
        QWidget *newPage = nullptr;

        if (text == "  系统初始化") newPage = new Initialization;
        //else if (text == "  关于我们") newPage = new canshushezhi;
        else if (text == "  公告管理") newPage = new editnotice;
        else if (text == "  欢迎页") newPage = new Welcome;
        else if (text == "  返回登录界面"){
            MainWindow *w = new MainWindow();
            w->show();
            this->hide();
        }
        else if (text == "  人事管理") newPage = new PersonnelManagement;
        else if (text == "  人事信息") newPage = new PersonnelInformation;
        else if (text == "  月度出勤") newPage = new AttendanceInquiry;
        else if (text == "  请假审批") newPage = new LeaveApproval;
        else if (text == "  指派工作") newPage = new repairManage;
        else if (text == "  财务统计") newPage = new payment;
        if (newPage) {
            QWidget *old = splitter->widget(1);
            splitter->replaceWidget(1, newPage);
            delete old;
        }
    });
}
void admin_MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    m_particlesystem->draw(&painter);
}

admin_MainWindow::~admin_MainWindow()
{
    delete ui;
    delete m_particlesystem;
}
