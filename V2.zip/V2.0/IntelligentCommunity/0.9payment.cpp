#include "0.9payment.h"
#include "ui_0.9payment.h"
#include "payment_1detail.h"
#include "payment_2detail.h"
#include <QtCharts/QChart>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtCharts/QChartView>
#include <QSqlQuery>
#include <QMap>
#include <QtCharts>

extern int useridentification;

struct DateData {
    double yesAmount; // 已收金额
    double noAmount;  // 未收金额
};

struct TypeData {
    double yesAmount; // 已收类型金额
    double noAmount;  // 未收类型金额
};

payment::payment(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::payment)
{
    ui->setupUi(this);
    //connect(ui->pushButton_showTable, &QPushButton::clicked, this, &payment::on_showTableBtn_clicked);

        QChart *barChart = new QChart();
        barChart->setTitle("费用统计（按时间）");
        QChartView *barView = new QChartView(barChart, this);
        QVBoxLayout *topLayout = new QVBoxLayout(ui->topChart);
        topLayout->addWidget(barView);

        QChart *pieYesChart = new QChart();
        pieYesChart->setTitle("已收费用类型占比");
        QChartView *pieYesView = new QChartView(pieYesChart, this);
        QVBoxLayout *leftLayout = new QVBoxLayout(ui->bottomLeftChart);
        leftLayout->addWidget(pieYesView);

        QChart *pieNoChart = new QChart();
        pieNoChart->setTitle("未收费用类型占比");
        QChartView *pieNoView = new QChartView(pieNoChart, this);
        QVBoxLayout *rightLayout = new QVBoxLayout(ui->bottomRightChart);
        rightLayout->addWidget(pieNoView);

        updateCharts(barChart, pieYesChart, pieNoChart);
}

payment::~payment()
{
    delete ui;
}

void payment::updateCharts(QChart *barChart, QChart *pieYesChart, QChart *pieNoChart) {
    barChart->removeAllSeries();
    pieYesChart->removeAllSeries();
    pieNoChart->removeAllSeries();

    QMap<QString, DateData> dateMap;
    QSqlQuery query("SELECT date, state, number FROM payment");
    while (query.next()) {
        QString date = query.value(0).toString();
        bool isYes = (query.value(1).toString() == "是");
        double amount = query.value(2).toDouble();
        dateMap[date].yesAmount += (isYes ? amount : 0);
        dateMap[date].noAmount += (isYes ? 0 : amount);
    }

    QBarSet *yesSet = new QBarSet("已收");
    QBarSet *noSet = new QBarSet("未收");
    QStringList dates;
    for (auto it = dateMap.begin(); it != dateMap.end(); ++it) {
        dates << it.key();
        yesSet->append(it->yesAmount);
        noSet->append(it->noAmount);
    }
    QBarSeries *barSeries = new QBarSeries;
    barSeries->setBarWidth(0.6);
    barSeries->append(yesSet);
    barSeries->append(noSet);
    barChart->addSeries(barSeries);

    QValueAxis *axisY = new QValueAxis();
    axisY->setTitleText("金额");
    axisY->setLabelFormat("%.2f");
    barChart->addAxis(axisY, Qt::AlignLeft);
    barSeries->attachAxis(axisY);

    double maxAmount = 0;
    for (int i = 0; i < barSeries->barSets().size(); ++i) {
        QBarSet* set = barSeries->barSets().at(i);
        for (int j = 0; j < set->count(); ++j) {
            maxAmount = qMax(maxAmount, set->at(j));
        }
    }
    axisY->setRange(0, maxAmount * 1.1); // 设置Y轴范围，留出10%的余量

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(dates);
    barChart->addAxis(axisX, Qt::AlignBottom);
    barSeries->attachAxis(axisX);
    barChart->legend()->setAlignment(Qt::AlignBottom);

    QMap<QString, TypeData> typeYesMap, typeNoMap;
    query.exec("SELECT type, state, number FROM payment");
    while (query.next()) {
        QString type = query.value(0).toString();
        bool isYes = (query.value(1).toString() == "是");
        double amount = query.value(2).toDouble();
        (isYes ? typeYesMap[type].yesAmount : typeNoMap[type].noAmount) += amount;
    }

    QPieSeries *pieYesSeries = new QPieSeries;
    for (auto it = typeYesMap.begin(); it != typeYesMap.end(); ++it) {
        pieYesSeries->append(it.key(), it->yesAmount);
    }
    pieYesChart->addSeries(pieYesSeries);
    pieYesChart->legend()->setAlignment(Qt::AlignBottom);

    for (QPieSlice* slice : pieYesSeries->slices()) {
            double percentage = (slice->value() / pieYesSeries->sum()) * 100;
            slice->setLabel(QString("%1 (%2%)").arg(slice->label()).arg(percentage, 0, 'f', 1));
            slice->setLabelVisible(true);
        }
    pieYesChart->legend()->setAlignment(Qt::AlignBottom);

    QPieSeries *pieNoSeries = new QPieSeries;
    for (auto it = typeNoMap.begin(); it != typeNoMap.end(); ++it) {
        pieNoSeries->append(it.key(), it->noAmount);
    }
    pieNoChart->addSeries(pieNoSeries);
    pieNoChart->legend()->setAlignment(Qt::AlignBottom);

    for (QPieSlice* slice : pieNoSeries->slices()) {
           double percentage = (slice->value() / pieNoSeries->sum()) * 100;
           slice->setLabel(QString("%1 (%2%)").arg(slice->label()).arg(percentage, 0, 'f', 1));
           slice->setLabelVisible(true);
       }
    pieNoChart->legend()->setAlignment(Qt::AlignBottom);
}

void payment::on_showTableBtn_clicked() {
    payment_1detail *detail1UI = new payment_1detail(this);
    detail1UI->show();
}

void payment::on_pushButton_clicked(){
    payment_2detail *detail2UI = new payment_2detail(this);
    detail2UI->show();
}
