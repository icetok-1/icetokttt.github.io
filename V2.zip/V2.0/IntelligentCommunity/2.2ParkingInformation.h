#ifndef CAR_H
#define CAR_H

#include <QWidget>

namespace Ui {
class ParkingInformation;
}

class ParkingInformation : public QWidget
{
    Q_OBJECT

public:
    explicit ParkingInformation(QWidget *parent = nullptr);
    ~ParkingInformation();

private slots:

    void on_addButton_clicked();

    void on_modifyButton_clicked();

    void on_queryButton_clicked();

    void on_pushButton_clicked();

    void on_tableView_clicked(const QModelIndex &index);

private:
    Ui::ParkingInformation *ui;
    void loadAllParkingData();
};

#endif // CAR_H
