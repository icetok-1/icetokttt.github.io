#include "1.3Trouble.h"
#include "ui_1.3Trouble.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>
#include <QSqlQueryModel>
#include <QItemSelectionModel>
#include <QHeaderView>

extern int useridentification;

Trouble::Trouble(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Trouble)
{
    ui->setupUi(this);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows); // 整行选择
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection); // 单选模式
    connect(ui->tableView, &QTableView::doubleClicked,
    this, &Trouble::on_tableView_doubleClicked);
    tableshow();
}
void Trouble::on_tableView_doubleClicked(const QModelIndex &index)
{
    ui->tableView->selectRow(index.row());
}
Trouble::~Trouble()
{
    delete ui;
}
void Trouble::on_queryButton_clicked()
{
    tableshow();
}
void Trouble::on_pushButton_2_clicked()
{
    QModelIndexList selectedIndexes = ui->tableView->selectionModel()->selectedRows();
    if(selectedIndexes.isEmpty()) {
        QMessageBox::warning(this, "警告", "请先选择一条维修记录！");
        return;
    }

    int selectedRow = selectedIndexes.first().row();
    QSqlQueryModel *model = qobject_cast<QSqlQueryModel*>(ui->tableView->model());
    if(!model) {
        QMessageBox::critical(this, "错误", "无法获取表格模型");
        return;
    }

    QModelIndex idIndex = model->index(selectedRow, 0);
    QString repairId = model->data(idIndex).toString();

    QString evaluation = ui->lineEdit_6->text().trimmed();
    if(evaluation.isEmpty()) {
        QMessageBox::warning(this, "警告", "请输入评价内容！");
        return;
    }
    QSqlQuery query;
    query.prepare("UPDATE weixiu SET 维修评价 = :evaluation WHERE ID = :repairId");
    query.bindValue(":evaluation", evaluation);
    query.bindValue(":repairId", repairId);
    if(!query.exec()) {
        qDebug() << "评价更新失败:" << query.lastError().text();
        QMessageBox::critical(this, "错误", "评价提交失败: " + query.lastError().text());
        return;
    }
    QMessageBox::information(this, "成功", "维修评价提交成功！");
    tableshow();
    ui->lineEdit_6->clear();
}
void Trouble::tableshow()
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString queryStr = "SELECT "
                       "ID, "
                       "姓名, "
                       "电话, "
                       "受理情况, "
                       "维修进度, "
                       "地址, "
                       "问题描述, "
                       "工作人员, "
                       "维修评价 "
                       "FROM weixiu "
                       "WHERE 序号 = :useridentification";
    QSqlQuery query;
    query.prepare(queryStr);
    query.bindValue(":useridentification", useridentification);
    if (!query.exec()) {
        qDebug() << "查询失败:" << query.lastError().text();
        delete model;
        return;
    }
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, "维修单号");
    model->setHeaderData(1, Qt::Horizontal, "姓名");
    model->setHeaderData(2, Qt::Horizontal, "电话");
    model->setHeaderData(3, Qt::Horizontal, "受理情况");
    model->setHeaderData(4, Qt::Horizontal, "维修进度");
    model->setHeaderData(5, Qt::Horizontal, "地址");
    model->setHeaderData(6, Qt::Horizontal, "问题描述");
    model->setHeaderData(7, Qt::Horizontal, "工作人员");
    model->setHeaderData(8, Qt::Horizontal, "维修评价");
    QAbstractItemModel *oldModel = ui->tableView->model();
    ui->tableView->setModel(model);
    QHeaderView *header = ui->tableView->horizontalHeader();
    if (header) {
        for (int i = 0; i < 8; ++i)
        {
            header->setSectionResizeMode(i, QHeaderView::Interactive);
        }
        header->setSectionResizeMode(8, QHeaderView::Stretch);
        header->resizeSection(0, 100);  // 维修单号
        header->resizeSection(1, 80);   // 姓名
        header->resizeSection(2, 120);  // 电话
        header->resizeSection(3, 100);  // 受理情况
        header->resizeSection(4, 100);  // 维修进度
        header->resizeSection(5, 150);  // 地址
        header->resizeSection(6, 200);  // 问题描述
        header->resizeSection(7, 100);  // 工作人员
    }
    delete oldModel;
    qDebug() << "刷新表格，记录数：" << model->rowCount();
}
