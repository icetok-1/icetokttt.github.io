#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QVector>
#include <QTimer>
#include <QPointF>
#include <QRandomGenerator>
#include <QPropertyAnimation>
#include <QMouseEvent>

namespace Ui {
class MainWindow;
class ParticleSystem;

}
// 粒子结构体
struct Particle {
    QPointF position;
    QPointF velocity;
    qreal rotation;
    qreal rotationSpeed;
    qreal size;
    QColor color;
    int life;
    int initialLife;
};
//粒子系统
class ParticleSystem : public QObject {
    Q_OBJECT
public:
    explicit ParticleSystem(QWidget *parent = nullptr);
    const QVector<Particle>& particles() const { return m_particles; }

private slots:
    void updateParticles();

private:
    void addParticle();
    QWidget *m_parent;
    QTimer *m_timer;
    QVector<Particle> m_particles;

};
//重构LineEdit控件
class HoverLineEdit : public QLineEdit
{
    Q_OBJECT
public:
    explicit HoverLineEdit(QWidget *parent = nullptr);

protected:
    // 鼠标事件重写
    void enterEvent(QEvent *event) override;
    void leaveEvent(QEvent *event) override;

private:
    QPropertyAnimation *m_animation;
    QRect m_originalGeometry;
    bool m_isHovered = false;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
protected:
    void paintEvent(QPaintEvent *event) override;

private slots:
    void on_pushButton_clicked(bool checked);
    void on_pushButton_2_clicked(bool checked);

private:
    Ui::MainWindow *ui;
    ParticleSystem *m_particleSystem;
};

#endif // MAINWINDOW_H
