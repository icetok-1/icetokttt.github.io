#ifndef overall_H
#define overall_H

extern int useridentification;
int useridentification = 0;

#endif // overall_H
