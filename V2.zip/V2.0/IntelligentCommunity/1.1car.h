#ifndef USERCAR_H
#define USERCAR_H
#include <QWidget>
namespace Ui {
class car;
}
class car : public QWidget
{
    Q_OBJECT

public:
    explicit car(QWidget *parent = nullptr);
    ~car();

private slots:
    void on_pushButton_clicked();

    void on_delpushButton_clicked();


private:
    Ui::car *ui;
    void table1show();
    void on_tableView_clicked(const QModelIndex &index);
};

#endif // USERCAR_H
