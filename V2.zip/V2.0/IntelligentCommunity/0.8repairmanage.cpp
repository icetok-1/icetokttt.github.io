#include "0.8repairmanage.h"
#include "ui_0.8repairmanage.h"
#include <QSqlError>
#include <QMessageBox>
#include <QShortcut>
#include <QSqlQuery>

repairManage::repairManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::repairManage),
    selectedRepairId(-1),
    selectedWorker("")
{
    ui->setupUi(this);
    loadData();
    setupStyles();
    QShortcut* shortcutR = new QShortcut(QKeySequence(Qt::Key_R), this);
    connect(shortcutR, &QShortcut::activated, this, &repairManage::loadData);
}
repairManage::~repairManage()
{
    delete ui;
}
void repairManage::loadData()
{
    leftModel = new QSqlTableModel(this);
    leftModel->setTable("weixiu");
    leftModel->select();

    leftModel->setHeaderData(0, Qt::Horizontal, "序号");
    leftModel->setHeaderData(1, Qt::Horizontal, "姓名");
    leftModel->setHeaderData(2, Qt::Horizontal, "电话");
    leftModel->setHeaderData(3, Qt::Horizontal, "地址");
    leftModel->setHeaderData(4, Qt::Horizontal, "问题描述");
    leftModel->setHeaderData(8, Qt::Horizontal, "工作人员");
    ui->leftTable->setModel(leftModel);
    ui->leftTable->hideColumn(5);
    ui->leftTable->hideColumn(7);
    ui->leftTable->hideColumn(9);

    rightModel = new QSqlTableModel(this);
    rightModel->setTable("usrlist");
    rightModel->setFilter("mark=2");
    rightModel->select();

    rightModel->setHeaderData(1, Qt::Horizontal, "电话");
    rightModel->setHeaderData(5, Qt::Horizontal, "姓名");
    ui->rightTable->setModel(rightModel);
    ui->rightTable->horizontalHeader()->moveSection(5, 0);
    ui->rightTable->horizontalHeader()->moveSection(1, 1);

    ui->rightTable->hideColumn(0);
    ui->rightTable->hideColumn(2);
    ui->rightTable->hideColumn(3);
    ui->rightTable->hideColumn(4);
}

void repairManage::on_leftTable_clicked(const QModelIndex &index)
{
    selectedRepairId = leftModel->data(leftModel->index(index.row(), 9)).toInt();
}

void repairManage::on_rightTable_clicked(const QModelIndex &index)
{
    selectedWorker = rightModel->data(rightModel->index(index.row(), 5)).toString();
}

void repairManage::on_assignButton_clicked()
{
    if (selectedRepairId == -1 || selectedWorker.isEmpty()) {
        QMessageBox::warning(this, "提示", "请选择维修记录和工作人员");
        loadData();
        return;
    }
    QSqlQuery updateQuery;
        updateQuery.prepare("UPDATE weixiu SET 工作人员 = :worker, 维修进度 = '已派工' WHERE id = :rid");
        updateQuery.bindValue(":worker", selectedWorker);
        updateQuery.bindValue(":rid", selectedRepairId);
    if (updateQuery.exec()) {
        QMessageBox::information(this, "成功", "工作人员指派成功！");
        leftModel->select();
    } else {
        QMessageBox::critical(this, "失败", "指派失败：" + updateQuery.lastError().text());
    }
    loadData();
}
void repairManage::setupStyles()
{
    QString buttonStyle = R"(
        QPushButton {
        border-radius: 4px;
        padding: 6px 12px;
        font-weight: bold;
        }
        QPushButton:hover {
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            background-color: white;
            color: palette(button-text);
        }
        QPushButton:pressed {
            background-color: palette(button);
            color: palette(button-text);
        }
    )";

    QString lineEditStyle = R"(
        QLineEdit {
            background-color: #bdc3c7;
            border: 1px solid #BDBDBD;
            border-radius: 8px;
            padding: 4px;
        }

        QLineEdit:focus {
            border: 2px solid #1976D2;
            background-color: #F5F5F5;
            outline: none;
        }

    )";

    QString tableViewStyle = R"(
        QTableView {
            alternate-background-color: #F5F5F5;
            selection-background-color: #BBDEFB;
            selection-color: black;
        }

        QTableView::item:hover {
            background-color: #EEEEEE;
        }
    )";

    ui->assignButton->setStyleSheet(ui->assignButton->styleSheet() + "background-color: #607D8B; color: white;"); // 显示按钮-灰色

    ui->leftTable->setStyleSheet(tableViewStyle);
    ui->rightTable->setStyleSheet(tableViewStyle);


}
