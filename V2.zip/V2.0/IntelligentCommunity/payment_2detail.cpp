#include "payment_2detail.h"
#include "ui_payment_2detail.h"
#include "0.9payment.h"
#include <QtCharts/QChart>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtCharts/QChartView>
#include <QSqlQuery>
#include <QMap>
#include <QtCharts>

payment_2detail::payment_2detail(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::payment_2detail)
{
    ui->setupUi(this);

    QTableWidget *table = new QTableWidget(this);
    table->setColumnCount(4);
    table->setHorizontalHeaderLabels({"日期", "维修（未收）", "物业（未收）", "车位（未收）"});

    QMap<QString, QMap<QString, double>> data;
    QSqlQuery query("SELECT date, type, number FROM payment WHERE state = '否'");
    while (query.next()) {
        data[query.value(0).toString()][query.value(1).toString()] += query.value(2).toDouble();
    }

    table->setRowCount(data.size());
    int row = 0;
    for (auto date : data.keys()) {
        table->setItem(row, 0, new QTableWidgetItem(date));
        QStringList types = {"维修费", "物业费", "车位费"};
        for (int col = 1; col < 4; ++col) {
            double amount = data[date].value(types[col-1], 0.0);
            table->setItem(row, col, new QTableWidgetItem(QString::number(amount, 'f', 2)));
        }
        row++;
    }

    QVBoxLayout *layout = new QVBoxLayout(ui->tableContainer);
    layout->addWidget(table);
}

payment_2detail::~payment_2detail()
{
    delete ui;
}

void payment_2detail::on_commandLinkButton_clicked()
{
    payment *back = new payment(this);
    back->hide();
    this->close();
}
