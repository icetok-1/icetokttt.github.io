#include "ownerinfo.h"
#include "ui_ownerinfo.h"


extern int useridentification;

ownerinfo::ownerinfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ownerinfo)
{
    ui->setupUi(this);
    infoshow();
}

ownerinfo::~ownerinfo()
{
    delete ui;
}
void ownerinfo::infoshow()
{

    QSqlQuery query;
    query.prepare("SELECT * FROM usrlist WHERE id = :id");
    query.bindValue(":id", useridentification); // 使用全局变量作为查询条件
    if (!query.exec()) {
        QMessageBox::critical(this, "查询失败", "数据库查询错误：" + query.lastError().text());
        return;
    }

    if (!query.next()) {
        QMessageBox::information(this, "提示", QString("未找到ID为 %1 的用户").arg(useridentification));
        return;
    }
    QSqlQuery query2;
    query2.prepare("SELECT * FROM information WHERE id = :id");
    query2.bindValue(":id", useridentification); // 使用全局变量作为查询条件
    if (!query2.exec()) {
        QMessageBox::critical(this, "查询失败", "数据库查询错误：" + query.lastError().text());
        return;
    }
    if (!query2.next()) {
        QMessageBox::information(this, "提示", QString("未找到ID为 %1 的用户").arg(useridentification));
        return;
    }
    ui->nameEdit->setText(query.value("name").toString());
    ui->IDEdit->setText(query.value("id").toString());
    ui->telEdit->setText(query.value("tel").toString());
    ui->ZHEdit->setText(query.value("IDcard").toString());
    ui->pwdEdit->setText(query.value("password").toString());
    ui->addressEdit->setText(query2.value("address").toString());
    ui->sexEdit->setText(query2.value("sex").toString());
    ui->ageEdit->setText(query2.value("age").toString());
}

void ownerinfo::on_pushButton_2_clicked()
{
    ui->ZHEdit->setEnabled(false);
    QString name = ui->nameEdit->text().trimmed();
    QString tel = ui->telEdit->text().trimmed();
    QString IDcard = ui->ZHEdit->text().trimmed();
    QString password = ui->pwdEdit->text().trimmed();
    QString address = ui->addressEdit->text().trimmed();
    QString sex = ui->sexEdit->text().trimmed();
    QString age = ui->ageEdit->text().trimmed();

    if (name.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "用户名不能为空！");
        return;
    }

    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        QMessageBox::critical(this, "数据库错误", "数据库连接失败！");
        return;
    }

    // 开始事务，确保两个表的更新要么同时成功，要么同时失败
    db.transaction();
    QSqlQuery query;
    query.prepare("UPDATE usrlist SET "
                  "tel = :tel, "
                  "IDcard = :IDcard, "
                  "password = :pwd "
                  "WHERE name = :name");  // 用用户名查询
    query.bindValue(":tel", tel);
    query.bindValue(":IDcard", IDcard);
    query.bindValue(":pwd", password);
    query.bindValue(":name", name);

    if (!query.exec()) {
        db.rollback();  // 回滚事务
        QMessageBox::critical(this, "修改失败", "用户表更新失败：" + query.lastError().text());
        return;
    }

    // 2. 更新information表（使用useridentification作为ID条件，修复SQL语法错误）
    QSqlQuery query2;
    query2.prepare("UPDATE information SET "
                   "address = :address, "
                   "sex = :sex, "
                   "age = :age "  // 移除多余的逗号
                   "WHERE id = :id");  // 修复括号和引号错误
    query2.bindValue(":address", address);
    query2.bindValue(":sex", sex);
    query2.bindValue(":age", age);
    query2.bindValue(":id", useridentification);  // 使用useridentification作为ID条件

    if (!query2.exec()) {
        db.rollback();  // 回滚事务
        QMessageBox::critical(this, "修改失败", "信息表更新失败：" + query2.lastError().text());
        return;
    }

    // 提交事务
    if (db.commit()) {
        QMessageBox::information(this, "成功", "信息修改成功！");
    } else {
        db.rollback();
        QMessageBox::critical(this, "提交失败", "事务提交失败：" + db.lastError().text());
    }
}
