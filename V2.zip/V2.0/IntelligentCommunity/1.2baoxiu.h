#ifndef OWNER_ADD_H
#define OWNER_ADD_H

#include <QWidget>
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QTableView>
#include <string>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlRelationalTableModel>

namespace Ui {
class baoxiu;
}

class baoxiu : public QWidget
{
    Q_OBJECT

public:
    explicit baoxiu(QWidget *parent = nullptr);
    ~baoxiu();

private slots:
    void on_pushButton_2_clicked();

private:
    Ui::baoxiu *ui;
    QSqlDatabase db;
};

#endif // OWNER_ADD_H
