#include "carpark.h"
#include "ui_carpark.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QDebug>
#include <QDate>
#include <QTableView>
#include <QHeaderView>
#include <QSqlError>
extern int useridentification;

Carpark::Carpark(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Carpark)
{
    ui->setupUi(this);
    table2show();
    table3show();
    ui->tableView_3->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView_3->setSelectionMode(QAbstractItemView::SingleSelection);
    connect(ui->tableView_3, &QTableView::clicked, this, &Carpark::on_tableView_3_clicked);
}
Carpark::~Carpark()
{
    delete ui;
}
void Carpark::table2show()
{
    auto *model = new QSqlQueryModel(this);
    model->setQuery("SELECT number, addr, sellout FROM park WHERE sellout = '否'");
    model->setHeaderData(0, Qt::Horizontal, "车位编号");
    model->setHeaderData(1, Qt::Horizontal, "车位地址");
    model->setHeaderData(2, Qt::Horizontal, "是否已出售");
    ui->tableView_3->setModel(model);
    if (auto *header = ui->tableView_3->horizontalHeader()) {
        header->setSectionResizeMode(QHeaderView::Interactive);
        header->resizeSection(0, 300);
        header->resizeSection(1, 500);
        header->resizeSection(2, 120);
        header->setStretchLastSection(true);
    }
    qDebug() << "可售车位数：" << model->rowCount();
}
void Carpark::table3show()
{
    auto *model = new QSqlQueryModel(this);
    QString sql = QString(
        "SELECT p.number, p.addr, p.sellout, s.state "
        "FROM park p "
        "INNER JOIN ParkingApply s ON p.number = s.parknum "
        "WHERE s.user_id = %1").arg(useridentification);
    model->setQuery(sql);
    model->setHeaderData(0, Qt::Horizontal, "车位编号");
    model->setHeaderData(1, Qt::Horizontal, "车位地址");
    model->setHeaderData(2, Qt::Horizontal, "是否售出");
    model->setHeaderData(3, Qt::Horizontal, "状态");
    ui->tableView_2->setModel(model);
    if (auto *header = ui->tableView_2->horizontalHeader()) {
        header->setSectionResizeMode(QHeaderView::Interactive);
        header->resizeSection(0, 300);  // 车位编号
        header->resizeSection(1, 500);  // 车位地址
        header->resizeSection(2, 120);  // 是否售出
        header->resizeSection(3, 200);  // 状态
        header->setStretchLastSection(true);
    }
    qDebug() << "车位申请记录：" << model->rowCount();
}
void Carpark::on_tableView_3_clicked(const QModelIndex &index)
{
    if (auto *model = ui->tableView_3->model()) {
        int row = index.row();
        QString licensePlate = model->data(model->index(row, 0)).toString();
        ui->parklineEdit->setText(licensePlate);
        ui->tableView_3->selectRow(row);
    }
}
void Carpark::on_shenpushButton_clicked()
{
    QString date = QDate::currentDate().toString("yyyy-MM-dd");
    QModelIndexList selectedRows = ui->tableView_3->selectionModel()->selectedRows();
    if (selectedRows.isEmpty()) {
        QMessageBox::warning(this,
                             tr("选择错误"),
                             tr("请先在表格中选择要申请的车位"));
        return;
    }
    int row = selectedRows.first().row();
    QString parknum = ui->tableView_3->model()->index(row, 0).data().toString();
    QSqlQuery checkQuery;
    checkQuery.prepare(R"(
        SELECT state
          FROM ParkingApply
         WHERE user_id = :uid
           AND parknum = :parknum
         ORDER BY sid DESC
         LIMIT 1
    )");
    checkQuery.bindValue(":uid",  useridentification);
    checkQuery.bindValue(":parknum",  parknum);
    if (checkQuery.exec() && checkQuery.next()) {
        QString prevState = checkQuery.value(0).toString();
        QMessageBox::information(this,
                                 tr("重复申请"),
                                 tr("您已对车位 %1 提交过申请，当前状态：%2")
                                   .arg(parknum, prevState));
        return;
    }
    QSqlQuery insertQuery;
    insertQuery.prepare(R"(
        INSERT INTO ParkingApply
        (user_id, state, date, parknum)
        VALUES
        (:uid, '待审核', :date, :parknum)
    )");
    insertQuery.bindValue(":uid",      useridentification);
    insertQuery.bindValue(":date",     date);
    insertQuery.bindValue(":parknum",  parknum);
    if (!insertQuery.exec()) {
        QMessageBox::critical(this,
                              tr("错误"),
                              tr("提交申请失败：%1").arg(insertQuery.lastError().text()));
        return;
    }
    QMessageBox::information(this,
                             tr("申请提交"),
                             tr("车位 %1 的申请已提交，状态“待审核”").arg(parknum));
    auto *model = new QSqlQueryModel(this);
    model->setQuery(QString(R"(
        SELECT
            p.number         AS 车位编号,
            p.addr           AS 车位地址,
            p.sellout        AS 是否已出售,
            COALESCE((
              SELECT state
                FROM ParkingApply
               WHERE user_id = %1
                 AND parknum = p.number
               ORDER BY sid DESC
               LIMIT 1
            ), '') AS 申请状态
          FROM park p
         WHERE p.sellout = '否'
    )").arg(useridentification));
    model->setHeaderData(0, Qt::Horizontal, tr("车位编号"));
    model->setHeaderData(1, Qt::Horizontal, tr("车位地址"));
    model->setHeaderData(2, Qt::Horizontal, tr("是否已出售"));
    model->setHeaderData(3, Qt::Horizontal, tr("申请状态"));
    ui->tableView_3->setModel(model);
    ui->tableView_3->selectRow(row);
}
