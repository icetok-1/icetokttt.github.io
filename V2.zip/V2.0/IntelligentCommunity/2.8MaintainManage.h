#ifndef MaintainManage_H
#define MaintainManage_H

#include <QWidget>
#include <QSqlTableModel>
#include <QStyledItemDelegate>

namespace Ui {
class MaintainManage;
}

class CenterAlignDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    explicit CenterAlignDelegate(QObject *parent = nullptr)
        : QStyledItemDelegate(parent) {}

    void initStyleOption(QStyleOptionViewItem *option,
                         const QModelIndex &index) const override
    {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;
    }
};

class WeixiuTableModel : public QSqlTableModel
{
    Q_OBJECT
public:
    explicit WeixiuTableModel(QObject *parent = nullptr,
                              QSqlDatabase db = QSqlDatabase())
        : QSqlTableModel(parent, db) {}

    Qt::ItemFlags flags(const QModelIndex &index) const override
    {
        Qt::ItemFlags f = QSqlTableModel::flags(index);
        if (!index.isValid())
            return f;
        int col = index.column();               // 0:序号 1:姓名 2:电话 … 9:ID
        if (col == 0 || col == 1 || col == 2 || col == 9)
            f &= ~Qt::ItemIsEditable;
        return f;
    }
};

class MaintainManage : public QWidget
{
    Q_OBJECT

public:
    explicit MaintainManage(QWidget *parent = nullptr);
    ~MaintainManage();

private slots:
    void on_pushButton_clicked();   // 刷新
    void on_pushButton_2_clicked(); // 保存
    void on_pushButton_3_clicked(); // 删除

private:
    Ui::MaintainManage *ui;
    WeixiuTableModel     *model = nullptr;

    void initModel();               // 初始化模型
};

#endif // MaintainManage_H
