#ifndef ADMIN_MAINWINDOW_H
#define ADMIN_MAINWINDOW_H

#include <QMainWindow>
#include <QSplitter>
#include <particlesystem.h>
namespace Ui {
class admin_MainWindow;
}

class admin_MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit admin_MainWindow(QWidget *parent = nullptr);
    ~admin_MainWindow();


private:
    Ui::admin_MainWindow *ui;
    QSplitter *splitter;
    void paintEvent(QPaintEvent *event) override;
    particlesystem *m_particlesystem;
};

#endif // ADMIN_MAINWINDOW_H
