#ifndef WELCOME_H
#define WELCOME_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLinearGradient>
#include <QPalette>
#include <QSqlDatabase> // 添加数据库支持
#include <QSqlQuery>
#include <QSqlDatabase> // 添加
#include <QSqlQuery>
namespace Ui {
class Welcome;
}

class Welcome : public QWidget
{
    Q_OBJECT

public:
    explicit Welcome(QWidget *parent = nullptr);
    ~Welcome();

private:
    Ui::Welcome *ui;
};

#endif // WELCOME_H
