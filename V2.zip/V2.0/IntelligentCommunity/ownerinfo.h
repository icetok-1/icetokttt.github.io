#ifndef OWNERINFO_H
#define OWNERINFO_H

#include <QWidget>
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QTableView>
#include <string>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlRelationalTableModel>

namespace Ui {
class ownerinfo;
}

class ownerinfo : public QWidget
{
    Q_OBJECT

public:
    explicit ownerinfo(QWidget *parent = nullptr);
    ~ownerinfo();
private slots:
    void on_pushButton_2_clicked();
private:
    Ui::ownerinfo *ui;
    QSqlDatabase db;
    QSqlTableModel *model;
    void infoshow();
};

#endif // OWNERINFO_H
