#include "2.12business.h"
#include "ui_2.12business.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QHeaderView>
#include <QSqlRecord>
#include <QDebug>
#include <QStyledItemDelegate>

class CenterAlignDelegate : public QStyledItemDelegate {
public:
    CenterAlignDelegate(QObject *parent = nullptr) : QStyledItemDelegate(parent) {}

    void initStyleOption(QStyleOptionViewItem *option,
                         const QModelIndex &index) const override {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;
    }
};

extern int useridentification;


business::business(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::business)
{
    ui->setupUi(this);

    {
        QSqlQuery q;
        q.prepare("SELECT name FROM usrlist WHERE id = :id");
        q.bindValue(":id", useridentification);
        if (!q.exec() || !q.next()) {
            QMessageBox::critical(this, "错误", "获取用户姓名失败：" + q.lastError().text());
            myName = QStringLiteral("未知用户");
        } else {
            myName = q.value(0).toString().trimmed();
        }
    }

    initTables();
}

business::~business()
{
    delete ui;
}


void business::initTables()
{
    myModel = new QSqlTableModel(this);
    myModel->setTable("weixiu");
    myModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    myModel->setFilter(QStringLiteral("工作人员 = '%1'").arg(myName));
    myModel->select();

    ui->tableView->setModel(myModel);
    for (int col = 0; col < myModel->columnCount(); ++col)
        ui->tableView->setColumnHidden(col, !(col == 1 || col == 2 || col == 3 ||
                                              col == 4 || col == 6 || col == 7 || col == 8));

    myModel->setHeaderData(1, Qt::Horizontal, "姓名");
    myModel->setHeaderData(2, Qt::Horizontal, "电话");
    myModel->setHeaderData(3, Qt::Horizontal, "地址");
    myModel->setHeaderData(4, Qt::Horizontal, "问题描述");
    myModel->setHeaderData(6, Qt::Horizontal, "维修进度");
    myModel->setHeaderData(7, Qt::Horizontal, "维修评价");
    myModel->setHeaderData(8, Qt::Horizontal, "工作人员");

    beautifyTableView(ui->tableView);

    pendingModel = new QSqlTableModel(this);
    pendingModel->setTable("weixiu");
    pendingModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    pendingModel->setFilter(QStringLiteral("维修进度 = '未派工'"));
    pendingModel->select();

    ui->tableView_2->setModel(pendingModel);
    for (int col = 0; col < pendingModel->columnCount(); ++col)
        ui->tableView_2->setColumnHidden(col, !(col == 0 || col == 1 || col == 2 ||
                                                col == 3 || col == 4 || col == 6 || col == 8));

    pendingModel->setHeaderData(0, Qt::Horizontal, "用户ID");
    pendingModel->setHeaderData(1, Qt::Horizontal, "姓名");
    pendingModel->setHeaderData(2, Qt::Horizontal, "电话");
    pendingModel->setHeaderData(3, Qt::Horizontal, "地址");
    pendingModel->setHeaderData(4, Qt::Horizontal, "问题描述");
    pendingModel->setHeaderData(6, Qt::Horizontal, "维修进度");
    pendingModel->setHeaderData(8, Qt::Horizontal, "工作人员");

    beautifyTableView(ui->tableView_2);

    QList<int> widths = {125, 200, 200, 300, 200, 200, 100};
    int idx = 0;
    for (int col : {1,2,3,4,6,7,8})
        ui->tableView->setColumnWidth(col, widths[idx++]);

    idx = 0;
    for (int col : {0,1,2,3,4,6,8})
        ui->tableView_2->setColumnWidth(col, widths[idx++]);
}

void business::refreshTables()
{
    myModel->select();
    pendingModel->select();
}

void business::beautifyTableView(QTableView *view)
{
    view->setSelectionBehavior(QAbstractItemView::SelectRows);
    view->setSelectionMode(QAbstractItemView::SingleSelection);
    view->setAlternatingRowColors(true);
    view->horizontalHeader()->setStretchLastSection(true);
    view->setEditTriggers(QAbstractItemView::NoEditTriggers);
    view->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);

    view->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #E6F3FF;
            color: #000000;
            padding: 4px;
            border: 1px solid #CCDDEE;
            font-weight: bold;
        }
        QTableView {
            gridline-color: #A8C6DE;
        }
        QTableView::item:selected {
            background-color: #C6E2FF;
        }
        QTableView::item:hover {
            background-color: #EFF6FF;
        }
    )");

    view->setItemDelegate(new CenterAlignDelegate(view));
}

void business::on_pushButton_clicked()
{
    QModelIndex curIdx = ui->tableView_2->currentIndex();
    if (!curIdx.isValid()) {
        QMessageBox::information(this, "提示", "请先选中一条待派工记录！");
        return;
    }

    int row = curIdx.row();
    QSqlRecord rc = pendingModel->record(row);
    int primaryID = rc.value("ID").toInt();

    QSqlQuery q;
    q.prepare("UPDATE weixiu "
              "SET 维修进度 = '已派工', 工作人员 = :worker "
              "WHERE ID = :id");
    q.bindValue(":worker", myName);
    q.bindValue(":id", primaryID);

    if (!q.exec()) {
        QMessageBox::critical(this, "数据库错误", "更新维修记录失败：\n" + q.lastError().text());
        return;
    }

    refreshTables();
    QMessageBox::information(this, "成功", "已成功认领该维修项目！");
}
