#include "1.2baoxiu.h"
#include "ui_1.2baoxiu.h"

extern int useridentification;

baoxiu::baoxiu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::baoxiu)
{
    ui->setupUi(this);
}
baoxiu::~baoxiu()
{
    delete ui;
}
void baoxiu::on_pushButton_2_clicked()//业主故障报修
{
    QString issue = ui->textEdit->toPlainText().trimmed(); // 添加trimmed()去除空白字符
    if(issue.isEmpty()){  // 改用isEmpty()检查
        QMessageBox::information(this, "Fault", "请填写故障问题!!");
        return;
    }
    // 查询usrlist表
    QSqlQuery query1;
    QString str = QString("SELECT * FROM usrlist WHERE id = '%1'").arg(useridentification);
    if(!query1.exec(str)) {
        QMessageBox::critical(this, "数据库错误", "查询用户表失败: " + query1.lastError().text());
        return;
    }
    if(!query1.next()) {  // 移动到第一条记录
        QMessageBox::warning(this, "用户不存在", "未找到该用户信息！");
        return;
    }
    QString idd = query1.value(0).toString();     // ID
    QString namee = query1.value(5).toString();   // 姓名
    QString tell = query1.value(1).toString();    // 电话
    // 查询information表 - 获取地址
    QSqlQuery query2;
    QString str1 = QString("SELECT address FROM information WHERE id = '%1'").arg(useridentification);
    if(!query2.exec(str1)) {
        QMessageBox::critical(this, "数据库错误", "查询信息表失败: " + query2.lastError().text());
        return;
    }
    QString addd;
    if(query2.next()) {
        addd = query2.value(0).toString();  // 只查询address字段，所以索引为0
    } else {
        QMessageBox::warning(this, "地址缺失", "未找到该用户的地址信息！");
        return;
    }
    QSqlQuery query3;
    QString temp = QString("INSERT INTO weixiu (序号, 姓名, 电话, 地址, 问题描述) "
                          "VALUES ('%1', '%2', '%3', '%4', '%5')")
                   .arg(idd).arg(namee).arg(tell).arg(addd).arg(issue);
    if(!query3.exec(temp)) {
        QMessageBox::critical(this, "插入失败", "报修记录创建失败: " + query3.lastError().text());
        return;
    }
    QMessageBox::information(this, "Success", "故障报修成功!!");
}
