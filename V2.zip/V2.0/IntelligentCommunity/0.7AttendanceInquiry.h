#ifndef AttendanceInquiry_H
#define AttendanceInquiry_H

#include <QWidget>
#include <QLabel>  // 添加标签支持
#include <QtCharts/Qtcharts>

// 前向声明
QT_CHARTS_USE_NAMESPACE // 使用QtCharts命名空间

namespace Ui {
class AttendanceInquiry;
}

class AttendanceInquiry : public QWidget
{
    Q_OBJECT

public:
    explicit AttendanceInquiry(QWidget *parent = nullptr);
    ~AttendanceInquiry();
private slots:
    void on_pushButton_clicked();
    void on_browseButton_clicked();
private:
    Ui::AttendanceInquiry *ui;

    // 添加标题标签
    QLabel *titleLabel;

    void loadAttendanceData(); // 加载考勤数据到表格
    void setStyle();           // 设置界面样式

    // 添加图表相关函数
    void createPieChart(QVBoxLayout *layout);       // 创建饼图
    void createPersonalBarChart(QVBoxLayout *layout, const QString &userName);
    void createLateBarChart(QVBoxLayout *layout, const QString &userName);
    void createUserAttendanceBarChart(QVBoxLayout *layout);
    // 添加数据库查询函数
    void queryAttendanceStats();                    // 查询考勤统计数据

    // 添加成员变量存储统计数据
    struct AttendanceStats {
        int normalCount = 0;   // 正常出勤次数
        int lateCount = 0;     // 迟到次数
        int earlyCount = 0;    // 早退次数
        int absentCount = 0;   // 缺勤次数
    } attendanceStats;
};

#endif // AttendanceInquiry_H
