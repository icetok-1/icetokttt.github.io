#ifndef CARPARK_H
#define CARPARK_H

#include <QWidget>

namespace Ui {
class Carpark;
}

class Carpark : public QWidget
{
    Q_OBJECT

public:
    explicit Carpark(QWidget *parent = nullptr);
    ~Carpark();
private slots:
    void on_shenpushButton_clicked();
private:
    Ui::Carpark *ui;
    void table2show();
    void table3show();
    void on_tableView_3_clicked(const QModelIndex &index);
};

#endif // CARPARK_H
