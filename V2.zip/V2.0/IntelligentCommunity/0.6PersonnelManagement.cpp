#include "0.6PersonnelManagement.h"
#include "ui_0.6PersonnelManagement.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>
#include <QSqlTableModel>
#include <QRegularExpression>
extern int useridentification;
PersonnelManagement::PersonnelManagement(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setupStyles();
}
PersonnelManagement::~PersonnelManagement()
{
    delete ui;
}
void PersonnelManagement::on_pushButton_clicked()
{
    QString searchName = ui->lineEdit_6->text().trimmed();
    if (searchName.isEmpty()) {
        QMessageBox::information(this, "提示", "请输入需要查询人员的姓名！");
        return;
    }
    QSqlQuery query;
    query.prepare("SELECT * FROM usrlist WHERE name = :name");
    query.bindValue(":name", searchName);
    if (!query.exec() || !query.next()) {
        QMessageBox::information(this, "提示", QString("未找到名为 %1 的人员").arg(searchName));
        clearInputs();
        return;
    }
    ui->lineEdit->setText(query.value("name").toString());
    ui->lineEdit_7->setText(query.value("id").toString());
    ui->lineEdit_2->setText(query.value("tel").toString());
    ui->lineEdit_3->setText(query.value("IDcard").toString());
    ui->lineEdit_4->setText(query.value("password").toString());
    ui->lineEdit_5->setText(query.value("mark").toString());
    ui->lineEdit_6->clear();
    QMessageBox::information(this, "成功", "查询成功！");
}
void PersonnelManagement::on_pushButton_2_clicked()
{
    QString name     = ui->lineEdit->text().trimmed();
    QString id       = ui->lineEdit_7->text().trimmed();
    QString tel      = ui->lineEdit_2->text().trimmed();
    QString IDcard   = ui->lineEdit_3->text().trimmed();
    QString password = ui->lineEdit_4->text().trimmed();
    QString mark     = ui->lineEdit_5->text().trimmed();
    if (name.isEmpty()) {
        QMessageBox::information(this, "提示", "请输入要修改的人员姓名");
        return;
    }
    QRegularExpression re("^\\d+$");
    if (!re.match(IDcard).hasMatch()) {
        QMessageBox::warning(this, "输入错误", "身份证号（IDcard）必须为纯数字！");
        return;
    }
    QRegularExpression te("^\\d+$");
    if (!te.match(tel).hasMatch()) {
        QMessageBox::warning(this, "输入错误", "电话号码(tel)必须为纯数字！");
        return;
    }
    QSqlQuery query;
    query.prepare(R"(
        UPDATE usrlist
           SET id     = :id,
               tel    = :tel,
               IDcard = :IDcard,
               password = :pwd,
               mark   = :mark
         WHERE name   = :name
    )");
    query.bindValue(":id",       id);
    query.bindValue(":tel",      tel);
    query.bindValue(":IDcard",   IDcard);
    query.bindValue(":pwd",      password);
    query.bindValue(":mark",     mark);
    query.bindValue(":name",     name);
    if (!query.exec()) {
        QMessageBox::critical(this, "修改失败",
                              "数据库更新失败：" + query.lastError().text());
        return;
    }
    QMessageBox::information(this, "成功", "信息修改成功！");
    clearInputs();
}
void PersonnelManagement::on_pushButton_3_clicked()
{
    QString id = ui->lineEdit_7->text().trimmed();
    QString tel = ui->lineEdit_2->text().trimmed();
    QString IDcard = ui->lineEdit_3->text().trimmed();
    QString password = ui->lineEdit_4->text().trimmed();
    QString mark = ui->lineEdit_5->text().trimmed();
    QString name = ui->lineEdit->text().trimmed();

    if (id.isEmpty() || tel.isEmpty() || IDcard.isEmpty() ||
        password.isEmpty() || mark.isEmpty() || name.isEmpty()) {
        QMessageBox::information(this, "提示", "请输入完整的信息！");
        return;
    }
    QSqlQuery query;
    query.prepare("INSERT INTO usrlist (id, tel, IDcard, password, mark, name) "
                  "VALUES (:id, :tel, :IDcard, :pwd, :mark, :name)");
    query.bindValue(":id", id);
    query.bindValue(":tel", tel);
    query.bindValue(":IDcard", IDcard);
    query.bindValue(":pwd", password);
    query.bindValue(":mark", mark);
    query.bindValue(":name", name);
    if (!query.exec()) {
        QMessageBox::critical(this, "写入失败", "写入数据库失败：" + query.lastError().text());
        return;
    }
    QMessageBox::information(this, "成功", "信息写入成功！");
    clearInputs();
}
void PersonnelManagement::on_pushButton_4_clicked()
{
    QString name = ui->lineEdit->text().trimmed();
    if (name.isEmpty()) {
        QMessageBox::information(this, "提示", "请输入要删除的人员姓名！");
        return;
    }
    QSqlQuery query;
    query.prepare("SELECT COUNT(*) FROM usrlist WHERE name = :name");
    query.bindValue(":name", name);
    if (!query.exec() || !query.next() || query.value(0).toInt() == 0) {
        QMessageBox::information(this, "提示", QString("未找到名为 %1 的人员").arg(name));
        clearInputs();
        return;
    }
    query.prepare("DELETE FROM usrlist WHERE name = :name");
    query.bindValue(":name", name);
    if (!query.exec()) {
        QMessageBox::critical(this, "删除失败", "删除失败：" + query.lastError().text());
        return;
    }

    QMessageBox::information(this, "成功", "信息删除成功！");
    clearInputs();
}
void PersonnelManagement::clearInputs()
{
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_4->clear();
    ui->lineEdit_5->clear();
    ui->lineEdit_6->clear();
    ui->lineEdit_7->clear();
}
void PersonnelManagement::on_pushButton_5_clicked()
{
    auto *model = new QSqlTableModel(this);
    model->setTable("usrlist");
    model->select();
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);  // 手动提交修改
    model->setHeaderData(0, Qt::Horizontal, "登录账号");
    model->setHeaderData(1, Qt::Horizontal, "手机号");
    model->setHeaderData(2, Qt::Horizontal, "身份证号");
    model->setHeaderData(3, Qt::Horizontal, "密码");
    model->setHeaderData(4, Qt::Horizontal, "身份标识");
    model->setHeaderData(5, Qt::Horizontal, "姓名");
    model->setHeaderData(6, Qt::Horizontal, "什么玩意 ");
    ui->tableview->setModel(model);
    ui->tableview->resizeColumnsToContents();
    ui->tableview->horizontalHeader()->setStyleSheet(
                "QHeaderView::section { background-color: #87CEFA; color: black; font-weight: bold; }"
            );
    ui->tableview->horizontalHeader()->setVisible(true);
    ui->tableview->verticalHeader()->setVisible(true);
    ui->tableview->setAlternatingRowColors(true);
    ui->tableview->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableview->horizontalHeader()->setStretchLastSection(true);
    ui->tableview->setColumnWidth(0, 150);
    ui->tableview->setColumnWidth(1, 250);
    ui->tableview->setColumnWidth(2, 300);
    ui->tableview->setColumnWidth(3, 250);
    ui->tableview->setColumnWidth(4, 100);
    ui->tableview->setColumnWidth(5, 100);
    ui->tableview->setColumnWidth(6, 100);
}
void PersonnelManagement::setupStyles()
{
    QString buttonStyle = R"(
        QPushButton {
        border-radius: 4px;
        padding: 6px 12px;
        font-weight: bold;
        }
        QPushButton:hover {
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            background-color: white;
            color: palette(button-text);
        }
        QPushButton:pressed {
            background-color: palette(button);
            color: palette(button-text);
        }
    )";
    QString lineEditStyle = R"(
        QLineEdit {
            background-color: #bdc3c7;
            border: 1px solid #BDBDBD;
            border-radius: 8px;
            padding: 4px;
        }
        QLineEdit:focus {
            border: 2px solid #1976D2;
            background-color: #F5F5F5;
            outline: none;
        }
    )";
    QString tableViewStyle = R"(
        QTableView {
            alternate-background-color: #F5F5F5;
            selection-background-color: #BBDEFB;
            selection-color: black;
        }
        QTableView::item:hover {
            background-color: #EEEEEE;
        }
    )";
    ui->pushButton->setStyleSheet(ui->pushButton->styleSheet() + "background-color: #4CAF50; color: white;"); // 查询按钮-绿色
    ui->pushButton_5->setStyleSheet(ui->pushButton_5->styleSheet() + "background-color: #607D8B; color: white;"); // 显示按钮-灰色
    ui->lineEdit->setStyleSheet(lineEditStyle);
    ui->lineEdit_2->setStyleSheet(lineEditStyle);
    ui->lineEdit_3->setStyleSheet(lineEditStyle);
    ui->lineEdit_4->setStyleSheet(lineEditStyle);
    ui->lineEdit_5->setStyleSheet(lineEditStyle);
    ui->lineEdit_6->setStyleSheet(lineEditStyle);
    ui->lineEdit_7->setStyleSheet(lineEditStyle);
    QString existingTableStyle = ui->tableview->styleSheet();
    ui->tableview->setStyleSheet(existingTableStyle + tableViewStyle);
}
