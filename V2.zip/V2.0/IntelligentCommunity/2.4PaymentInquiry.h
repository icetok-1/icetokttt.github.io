#ifndef PaymentInquiry_H
#define PaymentInquiry_H

#include <QWidget>
#include <QLineEdit>

namespace Ui {
class PaymentInquiry;
}

class PaymentInquiry : public QWidget
{
    Q_OBJECT

public:
    explicit PaymentInquiry(QWidget *parent = nullptr);
    ~PaymentInquiry();
    int a = 0;

private slots:
    void on_pushButton_clicked();
    void on_comboBox_2_currentTextChanged(const QString &arg1);
    void updateUI();  // 添加的UI更新函数

private:
    Ui::PaymentInquiry *ui;
};

#endif // PaymentInquiry_H
