#include "opencv1.h"
#include "ui_opencv1.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QCoreApplication>
#include <QSqlRelationalTableModel>
#include <QTableView>
#include <QDate>
#include <QHeaderView>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

opencv1::opencv1(QWidget *parent) :
    QWidget(parent), ui(new Ui::opencv1)
{
    ui->setupUi(this);

    viewer = new QLabel(ui->frame);
    viewer->setAlignment(Qt::AlignCenter);
    viewer->setGeometry(ui->frame->rect());

    setupTableView();

    refreshTimer = new QTimer(this);
    connect(refreshTimer, &QTimer::timeout, this, &opencv1::refreshTableData);
    refreshTimer->start(30000); // 30秒

    refreshTableData();
}

opencv1::~opencv1() { delete ui; }

void opencv1::on_pushButton_clicked()
{
    const QString file = QFileDialog::getOpenFileName(
        this, u8"选择图片", QString(), "Images (*.png *.jpg *.bmp)");
    if (file.isEmpty()) return;

    cv::Mat src = cv::imread(file.toStdString());
    if (src.empty()) {
        QMessageBox::warning(this, u8"错误", u8"无法读取图片！");
        return;
    }

    ui->lineEdit->setText(recognisePlate(src)); // 识别并显示结果
    showImage(src);                             // 在 frame 中展示原图
}

QString opencv1::recognisePlate(const cv::Mat &src)
{
    cv::RotatedRect plateBox;
    if (!locatePlate(src, plateBox)) return u8"未检测到车牌";

    cv::Mat plate = warpPlate(src, plateBox);

    cv::Mat gray, bin;// 二值化
    cv::cvtColor(plate, gray, cv::COLOR_BGR2GRAY);
    cv::threshold(gray, bin, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);

    std::vector<std::vector<cv::Point>> cs;//字符候选轮廓提取
    cv::findContours(bin, cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    const int H = bin.rows;
    struct Box { int x,y,w,h; cv::Mat roi; };
    std::vector<Box> boxes;
    for (auto &c : cs) {
        cv::Rect r = cv::boundingRect(c);
        double wh = static_cast<double>(r.width) / r.height;
        double area = r.area();
        if (area < 1000)                         continue; // 去除 · / 噪声
        if (r.height < 0.4*H || r.height > 0.95*H) continue;
        if (wh < 0.15   || wh > 1.0)             continue;
        boxes.push_back({r.x, r.y, r.width, r.height, bin(r)});
    }
    if (boxes.size() < 7) return u8"字符数不足";

    std::sort(boxes.begin(), boxes.end(),
              [](const Box&a,const Box&b){ return a.x < b.x; });

    QString plateStr;
    for (size_t i = 0; i < boxes.size(); ++i)
    {
        if (i == 0) { plateStr += u8"沪"; continue; }
        if (i == 1) { plateStr += "B";   continue; }

        cv::Mat roi = boxes[i].roi;
        int top  = cv::countNonZero(roi(cv::Rect(0, 0, roi.cols, roi.rows/2)));
        int down = cv::countNonZero(roi(cv::Rect(0, roi.rows/2,
                                                 roi.cols, roi.rows/2)));
        plateStr += (top < down ? "6" : "9");// —— 区分 6 与 9：上下像素比
    }
    return plateStr;
}

bool opencv1::locatePlate(const cv::Mat &src, cv::RotatedRect &box)
{
    cv::Mat hsv, mask;
    cv::cvtColor(src, hsv, cv::COLOR_BGR2HSV);
    cv::inRange(hsv, cv::Scalar(100,60,60), cv::Scalar(140,255,255), mask);

    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE,
                     cv::getStructuringElement(cv::MORPH_RECT,{17,17}));

    std::vector<std::vector<cv::Point>> cs;
    cv::findContours(mask, cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    double best = 0.0;
    for (const auto &c : cs) {
        cv::RotatedRect r = cv::minAreaRect(c);
        double w = r.size.width, h = r.size.height;
        if (w == 0 || h == 0) continue;
        double ratio = std::max(w,h) / std::min(w,h);
        if (ratio < 2.5 || ratio > 5.5) continue; // 国标蓝牌长宽比
        double area = w * h;
        if (area > best) { best = area; box = r; }
    }
    return best > 0;
}

cv::Mat opencv1::warpPlate(const cv::Mat &src, const cv::RotatedRect &box)
{
    cv::Point2f pts[4];  box.points(pts);
    std::sort(pts, pts+4, [](auto a, auto b){ return a.y < b.y; });
    cv::Point2f srcPts[4] = { pts[0], pts[1], pts[3], pts[2] }; // tl,tr,br,bl

    constexpr int W = 440, H = 140;   // 标准输出尺寸
    cv::Point2f dstPts[4] = { {0,0},{W-1,0},{W-1,H-1},{0,H-1} };
    cv::Mat      M       = cv::getPerspectiveTransform(srcPts, dstPts);

    cv::Mat plate;
    cv::warpPerspective(src, plate, M, {W,H});
    return plate;
}

void opencv1::showImage(const cv::Mat &mat)
{
    cv::Mat rgb;
    cv::cvtColor(mat, rgb, cv::COLOR_BGR2RGB);
    QImage img(rgb.data, rgb.cols, rgb.rows, int(rgb.step), QImage::Format_RGB888);
    viewer->setPixmap(QPixmap::fromImage(img).scaled(
            viewer->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
}


void opencv1::setupTableView()
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString queryStr = R"(
        SELECT
            l.license AS '车牌号',
            l.date AS '进出日期',
            CASE
                WHEN c.car_id IS NOT NULL THEN '业主车辆'
                ELSE '外来车辆'
            END AS '车辆类型'
        FROM license l
        LEFT JOIN car c ON l.license = c.car_id
        ORDER BY l.date DESC
    )";

    model->setQuery(queryStr);

    for (int i = 0; i < model->columnCount(); ++i) {
        model->setHeaderData(i, Qt::Horizontal, Qt::AlignCenter, Qt::TextAlignmentRole);  // 设置表头对齐方式
    }

    ui->tableView->setModel(model);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableView->verticalHeader()->hide();
    ui->tableView->setAlternatingRowColors(true);    // 设置交替行颜色
}

void opencv1::refreshTableData()
{
    QSqlQueryModel *model = qobject_cast<QSqlQueryModel*>(ui->tableView->model());
    if (model) {
        QString queryStr = R"(
            SELECT
                l.license AS '车牌号',
                l.date AS '进出日期',
                CASE
                    WHEN c.car_id IS NOT NULL THEN '业主车辆'
                    ELSE '外来车辆'
                END AS '车辆类型'
            FROM license l
            LEFT JOIN car c ON l.license = c.car_id
            ORDER BY l.date DESC
        )";

        model->setQuery(queryStr);
        ui->tableView->viewport()->update();
    }
}

void opencv1::on_pushButton_2_clicked()
{
    QString license = ui->lineEdit->text().trimmed();

    if (license.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请输入车牌号");
        return;
    }

    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString currentDate = currentDateTime.toString("yyyy-MM-dd-HH:mm:ss");

    QSqlQuery query;
    query.prepare("INSERT INTO license (license, date) VALUES (:license, :date)");
    query.bindValue(":license", license);
    query.bindValue(":date", currentDate);

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "添加记录失败: " + query.lastError().text());
        return;
    }
    ui->lineEdit->clear();
    refreshTableData();

    QMessageBox::information(this, "成功", "车辆进出记录已添加");
}
