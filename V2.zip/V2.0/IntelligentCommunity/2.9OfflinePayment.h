#ifndef OfflinePayment_H
#define OfflinePayment_H

#include <QWidget>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QModelIndex>
#include <QDebug>

namespace Ui {
class OfflinePayment;
}

class OfflinePayment : public QWidget
{
    Q_OBJECT

public:
    explicit OfflinePayment(QWidget *parent = nullptr);
    ~OfflinePayment();

private slots:
    void on_pushButton_clicked();            // 查询
    void on_pushButton_2_clicked();          // 缴费
    void onTableRowClicked(const QModelIndex &index);

private:
    Ui::OfflinePayment *ui;
};

#endif // OfflinePayment_H
