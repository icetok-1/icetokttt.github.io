#ifndef SHENPI_H
#define SHENPI_H

#include <QWidget>

namespace Ui {
class LeaveApproval;
}

class LeaveApproval : public QWidget
{
    Q_OBJECT

public:
    explicit LeaveApproval(QWidget *parent = nullptr);
    ~LeaveApproval();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableView_clicked(const QModelIndex &index);
private:
    Ui::LeaveApproval *ui;
    QString currentLeaveId;

    void setStyle();
};

#endif // SHENPI_H
