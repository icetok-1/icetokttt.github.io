#ifndef REPAIRMANAGE_H
#define REPAIRMANAGE_H

#include <QWidget>
#include <QSqlTableModel>
#include <QMessageBox>

namespace Ui {
class repairManage;
}

class repairManage : public QWidget
{
    Q_OBJECT

public:
    explicit repairManage(QWidget *parent = nullptr);
    ~repairManage();

private slots:
    void loadData(); // 加载数据
    void on_leftTable_clicked(const QModelIndex &index); // 左表点击
    void on_rightTable_clicked(const QModelIndex &index); // 右表点击
    void on_assignButton_clicked(); // 指派按钮
    void setupStyles();

private:
    Ui::repairManage *ui;
    QSqlTableModel *leftModel;  // 维修记录表模型
    QSqlTableModel *rightModel; // 工作人员表模型
    int selectedRepairId;       // 选中的维修记录ID
    QString selectedWorker;     // 选中的工作人员姓名
};

#endif // REPAIRMANAGE_H
