#ifndef CLOCKOUT_H
#define CLOCKOUT_H

#include <QWidget>
#include <QDateTime>
#include <QSize>
#include <QPropertyAnimation>
#include <QRect>

namespace Ui {
class ClockOut;
}

class ClockOut : public QWidget
{
    Q_OBJECT

public:
    explicit ClockOut(QWidget *parent = nullptr);
    ~ClockOut();

private slots:
    void on_pushButton_2_clicked();
    void on_pushButton_clicked();

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    Ui::ClockOut *ui;
    QRect originalGeometryBtn;
};

#endif // CLOCKOUT_H
