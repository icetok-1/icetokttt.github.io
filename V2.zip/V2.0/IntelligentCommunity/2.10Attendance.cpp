#include "2.10Attendance.h"
#include "ui_2.10Attendance.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QDebug>
#include <QStyledItemDelegate>

class CenterAlignDelegate : public QStyledItemDelegate {
public:
    using QStyledItemDelegate::QStyledItemDelegate;

    void initStyleOption(QStyleOptionViewItem *option, const QModelIndex &index) const override {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;  // 居中显示
    }
};

extern int useridentification;

Attendance::Attendance(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Attendance)
{
    ui->setupUi(this);

    QStandardItemModel *initModel = new QStandardItemModel(1, 1, this);
    initModel->setHeaderData(0, Qt::Horizontal, "提示信息");
    initModel->setItem(0, 0, new QStandardItem("请点击查询以查看考勤记录"));
    ui->tableView->setModel(initModel);

    ui->tableView->setStyleSheet(R"(
        QTableView {
            font-style: italic;
            color: gray;
            background-color: #fafafa;
        }
    )");
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
}

Attendance::~Attendance()
{
    delete ui;
}

void Attendance::on_pushButton1_clicked()
{
    QString name;
    QSqlQuery query;

    QString str = QString("SELECT name FROM usrlist WHERE id = %1").arg(useridentification);
    if (query.exec(str) && query.next()) {
        name = query.value(0).toString();
    } else {
        QMessageBox::warning(this, "查询失败", "无法获取当前用户名！");
        return;
    }

    // 查询考勤记录
    QString sql = QString("SELECT * FROM attendance WHERE name = '%1'").arg(name);
    QSqlQueryModel *model = new QSqlQueryModel(this);
    model->setQuery(sql);

    if (model->lastError().isValid()) {
        QMessageBox::warning(this, "查询失败", model->lastError().text());
        return;
    }
    model->setHeaderData(0, Qt::Horizontal, "姓名");
    model->setHeaderData(1, Qt::Horizontal, "上班时间");
    model->setHeaderData(2, Qt::Horizontal, "下班时间");
    model->setHeaderData(3, Qt::Horizontal, "日期");

    // 应用模型到 tableView
    ui->tableView->setModel(model);

    // 设置表头样式
    ui->tableView->horizontalHeader()->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #3A8DDE;
            color: white;
            font-weight: bold;
            padding: 4px;
            border: 1px solid lightgray;
        }
    )");

    ui->tableView->setColumnWidth(0, 200);  // 姓名
    ui->tableView->setColumnWidth(1, 350);  // 上班时间
    ui->tableView->setColumnWidth(2, 350);  // 下班时间
    ui->tableView->setColumnWidth(3, 350);  // 日期

    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->tableView->setStyleSheet(R"(
        QTableView {
            gridline-color: lightgray;
            background-color: white;
            alternate-background-color: #f5f5f5;
        }
        QTableView::item:hover {
            background-color: #D6EAF8;
        }
    )");

    ui->tableView->horizontalHeader()->setStretchLastSection(true);

    ui->tableView->setItemDelegate(new CenterAlignDelegate(this));
}
