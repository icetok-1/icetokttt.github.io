#ifndef PUNCHIN_H
#define PUNCHIN_H

#include <QWidget>
#include <QDateTime>
#include <QSize>
#include <QPropertyAnimation>
#include <QRect>

namespace Ui {
class PunchIn;
}

class PunchIn : public QWidget
{
    Q_OBJECT

public:
    explicit PunchIn(QWidget *parent = nullptr);
    ~PunchIn();

private slots:
    void on_pushButton_clicked();   // 上班打卡
    void on_pushButton_3_clicked(); // 获取时间戳

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;

private:
    Ui::PunchIn *ui;
    QRect originalGeometryBtn3;
};

#endif // PUNCHIN_H
