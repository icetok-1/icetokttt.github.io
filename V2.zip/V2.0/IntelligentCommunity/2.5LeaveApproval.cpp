#include "2.5LeaveApproval.h"
#include "ui_2.5LeaveApproval.h"

#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QDate>
#include <QItemSelectionModel>
#include <QHeaderView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QStyledItemDelegate>

class CenterAlignDelegate : public QStyledItemDelegate {
public:
    using QStyledItemDelegate::QStyledItemDelegate;
    void initStyleOption(QStyleOptionViewItem *option, const QModelIndex &index) const override {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;
    }
};

extern int useridentification;   // 当前登录用户编号

workerleaveapproval::workerleaveapproval(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::workerleaveapproval)
{
    ui->setupUi(this);

    auto *placeholderModel = new QStandardItemModel(1, 1, this);
    auto *placeholderItem  = new QStandardItem(
        u8"提示：如需请假，请先填写相关信息再点击【请假】；如需销假，仅需选中需要销假的记录后点击【销假】即可。");
    placeholderItem->setTextAlignment(Qt::AlignCenter);
    placeholderModel->setItem(0, 0, placeholderItem);

    ui->tableView->setModel(placeholderModel);
    ui->tableView->horizontalHeader()->hide();                               // 隐藏表头
    ui->tableView->horizontalHeader()->setSectionResizeMode(0, QHeaderView::Stretch);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);       // 只读
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);      // 行选中
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);     // 单选

    ui->reasonEdit->setPlaceholderText("请输入请假原因 / 类型");
}

workerleaveapproval::~workerleaveapproval()
{
    delete ui;
}
void workerleaveapproval::on_pushButton_clicked()
{
    QSqlQuery qUser;
    qUser.prepare("SELECT name FROM usrlist WHERE id = :id");
    qUser.bindValue(":id", useridentification);

    if (!qUser.exec() || !qUser.next()) {
        QMessageBox::warning(this, "查询错误", "无法获取用户信息！");
        return;
    }
    QString name = qUser.value(0).toString();

    auto *model = new QSqlQueryModel(this);

    QSqlQuery dataQuery;
    dataQuery.prepare(
        "SELECT  lid,                "          // 0 隐藏列：主键
        "        name,               "          // 1 姓名
        "        date,               "          // 2 起始时间
        "        id,                 "          // 3 原因
        "        date2,              "          // 4 结束时间
        "        shenpi,             "          // 5 审批结果
        "        IFNULL(xiaojia,'')  "          // 6 销假时间
        "FROM    leave "
        "WHERE   name = :name"
    );
    dataQuery.bindValue(":name", name);
    dataQuery.exec();

    model->setQuery(dataQuery);

    if (model->lastError().isValid()) {
        qWarning() << "请假查询失败: " << model->lastError().text();
        QMessageBox::warning(this, "查询错误", "获取请假记录失败！");
        return;
    }

    model->setHeaderData(1, Qt::Horizontal, "姓名");
    model->setHeaderData(2, Qt::Horizontal, "请假起始时间");
    model->setHeaderData(3, Qt::Horizontal, "原因");
    model->setHeaderData(4, Qt::Horizontal, "请假结束时间");
    model->setHeaderData(5, Qt::Horizontal, "审批结果");
    model->setHeaderData(6, Qt::Horizontal, "销假时间");

    ui->tableView->setModel(model);
    ui->tableView->hideColumn(0);                       // 隐藏 lid
    ui->tableView->setColumnWidth(1, 150);   // 第 1 列：姓名
    ui->tableView->setColumnWidth(2, 230);   // 第 2 列：请假起始时间
    ui->tableView->setColumnWidth(3, 300);   // 第 3 列：原因
    ui->tableView->setColumnWidth(4, 230);   // 第 4 列：请假结束时间
    ui->tableView->setColumnWidth(5, 150);   // 第 5 列：审批结果
    ui->tableView->setColumnWidth(6, 230);   // 第 6 列：销假时间

    ui->tableView->setItemDelegateForColumn(1, new CenterAlignDelegate(this));
    ui->tableView->setItemDelegateForColumn(2, new CenterAlignDelegate(this));
    ui->tableView->setItemDelegateForColumn(3, new CenterAlignDelegate(this));
    ui->tableView->setItemDelegateForColumn(4, new CenterAlignDelegate(this));
    ui->tableView->setItemDelegateForColumn(5, new CenterAlignDelegate(this));
    ui->tableView->setItemDelegateForColumn(6, new CenterAlignDelegate(this));


    ui->tableView->horizontalHeader()->show();
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
}

void workerleaveapproval::on_leaveButton_clicked()
{
    QSqlQuery qUser;
    qUser.prepare("SELECT name FROM usrlist WHERE id = ?");
    qUser.addBindValue(useridentification);
    if (!qUser.exec() || !qUser.next()) {
        QMessageBox::warning(this, "错误", "无法获取当前用户姓名！");
        return;
    }
    QString name = qUser.value(0).toString();

    QString startDate = ui->startEdit ->text().trimmed();
    QString endDate   = ui->endEdit   ->text().trimmed();
    QString reason    = ui->reasonEdit->text().trimmed();

    if (startDate.isEmpty() || endDate.isEmpty() || reason.isEmpty()) {
        QMessageBox::warning(this, "提示", "请填写完整的请假信息！");
        return;
    }

    QSqlQuery qIns;
    qIns.prepare(
        "INSERT INTO leave (name, date, id, date2, shenpi) "
        "VALUES (?, ?, ?, ?, '待审批')"
    );
    qIns.addBindValue(name);
    qIns.addBindValue(startDate);
    qIns.addBindValue(reason);
    qIns.addBindValue(endDate);

    if (!qIns.exec()) {
        qDebug() << "请假申请失败：" << qIns.lastError().text();
        QMessageBox::critical(this, "错误", "请假申请提交失败！");
    } else {
        QMessageBox::information(this, "成功", "请假申请提交成功！");
        on_pushButton_clicked();                       // 刷新表格
    }
}
void workerleaveapproval::on_backButton_clicked()
{
    QItemSelectionModel *sel = ui->tableView->selectionModel();
    if (!sel || !sel->hasSelection()) {
        QMessageBox::warning(this, "提示", "请先选中要销假的记录！");
        return;
    }
    int row = sel->currentIndex().row();
    int lid = ui->tableView->model()->index(row, 0).data().toInt();  // 0 隐藏列为 lid

    QString today = QDate::currentDate().toString("yyyy-MM-dd");
    QSqlQuery qUpd;
    qUpd.prepare("UPDATE leave SET xiaojia = :today WHERE lid = :lid");
    qUpd.bindValue(":today", today);
    qUpd.bindValue(":lid",   lid);

    if (!qUpd.exec()) {
        qDebug() << "销假失败：" << qUpd.lastError().text();
        QMessageBox::critical(this, "错误", "销假申请提交失败！");
    } else {
        QMessageBox::information(this, "成功", "销假申请提交成功！");
        on_pushButton_clicked();                       // 刷新表格
    }
}
