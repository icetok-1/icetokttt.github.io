#ifndef NOTICE_H
#define NOTICE_H
#include <QSqlTableModel>
#include <QTableView>
#include <QWidget>

namespace Ui {
class notice;
}

class notice : public QWidget
{
    Q_OBJECT

public:
    explicit notice(QWidget *parent = nullptr);
    ~notice();

private:
    Ui::notice *ui;
    QSqlTableModel *noticeModel;
};

#endif // NOTICE_H
