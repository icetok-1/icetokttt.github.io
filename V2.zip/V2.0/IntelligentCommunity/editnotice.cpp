#include "editnotice.h"
#include "ui_editnotice.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDate>
#include <QMessageBox>
#include <QDebug>

extern int useridentification; // 全局用户名变量

editnotice::editnotice(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::editnotice),
    model(nullptr),
    isEditMode(false),
    currentNoticeId(-1)
{
    ui->setupUi(this);
    setupTableView();
    setEditMode(false); // 初始为添加模式
    ui->titleEdit->setPlaceholderText("请输入标题");
    ui->textEdit->setPlaceholderText("请输入内容");
}

editnotice::~editnotice()
{
    delete ui;
    if (model) delete model;
}

void editnotice::setupTableView()
{
        model = new QSqlTableModel(this);
        model->setTable("notice");

        model->setHeaderData(model->fieldIndex("id"), Qt::Horizontal, tr("ID"));
        model->setHeaderData(model->fieldIndex("title"), Qt::Horizontal, tr("公告标题"));
        model->setHeaderData(model->fieldIndex("description"), Qt::Horizontal, tr("公告描述"));
        model->setHeaderData(model->fieldIndex("publisher"), Qt::Horizontal, tr("发布人"));
        model->setHeaderData(model->fieldIndex("pub_date"), Qt::Horizontal, tr("发布日期"));

        model->setSort(model->fieldIndex("pub_date"), Qt::DescendingOrder);

        if (!model->select()) {
            QMessageBox::critical(this, "错误", "加载公告数据失败: " + model->lastError().text());
            return;
        }

        ui->tableView->setModel(model);

        ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
        ui->tableView->horizontalHeader()->setStretchLastSection(true);

        ui->tableView->setColumnHidden(model->fieldIndex("id"), true);
    ui->tableView->setModel(model);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
}

void editnotice::setEditMode(bool enabled)
{
    isEditMode = enabled;

    if (enabled) {
        ui->tableView->setEnabled(true);
        ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
        ui->pbEdit->setStyleSheet("background-color: #4CAF50; color: white;"); // 高亮编辑按钮
        ui->pbAdd->setStyleSheet(""); // 重置添加按钮样式
    } else {
        ui->tableView->clearSelection();
        ui->tableView->setEnabled(false);
        ui->textEdit->clear();
        ui->titleEdit->clear();
        currentNoticeId = -1;
        ui->pbAdd->setStyleSheet("background-color: #2196F3; color: white;"); // 高亮添加按钮
        ui->pbEdit->setStyleSheet(""); // 重置编辑按钮样式
    }
}

void editnotice::on_pbEdit_clicked()
{
    setEditMode(true); // 切换到编辑模式
}

void editnotice::on_pbAdd_clicked()
{
    setEditMode(false); // 切换到添加模式
}

void editnotice::on_tableView_clicked(const QModelIndex &index)
{
    if (!isEditMode) return;  // 仅编辑模式下响应

    int row      = index.row();
    int idCol    = model->fieldIndex("id");
    int titleCol = model->fieldIndex("title");
    int descCol  = model->fieldIndex("description");

    currentNoticeId = model->data(model->index(row, idCol)).toInt();
    ui->titleEdit->setText(
        model->data(model->index(row, titleCol)).toString()
    );
    ui->textEdit->setPlainText(
        model->data(model->index(row, descCol)).toString()
    );
}


// 保存按钮：添加／编辑逻辑保持不变，新增标题校验与写库
void editnotice::on_pushButton_clicked()
{
    QString title       = ui->titleEdit->text().trimmed();
    QString description = ui->textEdit->toPlainText().trimmed();
    if (title.isEmpty()) {
        QMessageBox::warning(this, tr("输入错误"), tr("公告标题不能为空！"));
        return;
    }
    if (description.isEmpty()) {
        QMessageBox::warning(this, tr("输入错误"), tr("公告内容不能为空！"));
        return;
    }

    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        QMessageBox::critical(this, tr("错误"), tr("数据库未连接"));
        return;
    }

    QSqlQuery query;
    if (isEditMode) {
        // ——— 编辑模式：更新 title + description ———
        if (currentNoticeId == -1) {
            QMessageBox::warning(this, tr("操作失败"), tr("请先选择要编辑的公告"));
            return;
        }
        query.prepare(R"(
            UPDATE notice
               SET title       = :title,
                   description = :desc
             WHERE id          = :id
        )");
        query.bindValue(":title", title);
        query.bindValue(":desc",  description);
        query.bindValue(":id",    currentNoticeId);
        if (!query.exec()) {
            QMessageBox::critical(this, tr("更新失败"),
                                  tr("更新公告失败：") + query.lastError().text());
        } else {
            QMessageBox::information(this, tr("成功"), tr("公告更新成功!"));
            model->select();
        }
    } else {
        QString pubDate = QDate::currentDate().toString("yyyy-MM-dd");
        QString userName;
        QSqlQuery userQuery;
        userQuery.prepare("SELECT name FROM usrlist WHERE id = :id");
        userQuery.bindValue(":id", useridentification);
        if (!userQuery.exec() || !userQuery.next()) {
            QMessageBox::critical(this, tr("查询失败"),
                                  tr("无法获取用户信息：") +
                                  (userQuery.lastError().isValid()
                                   ? userQuery.lastError().text()
                                   : tr("未找到用户ID")));
            return;
        }
        userName = userQuery.value(0).toString();

        query.prepare(R"(
            INSERT INTO notice (title, description, publisher, pub_date)
            VALUES (:title, :desc, :pub, :date)
        )");
        query.bindValue(":title", title);
        query.bindValue(":desc",  description);
        query.bindValue(":pub",   userName);
        query.bindValue(":date",  pubDate);
        if (!query.exec()) {
            QMessageBox::critical(this, tr("保存失败"),
                                  tr("保存公告失败：") + query.lastError().text());
        } else {
            QMessageBox::information(this, tr("成功"), tr("公告发布成功!"));
            ui->titleEdit->clear();
            ui->textEdit->clear();
            model->select();
        }
    }
}

void editnotice::on_pushButton_2_clicked()
{
    if (!isEditMode || currentNoticeId == -1) {
        QMessageBox::warning(this, tr("操作失败"),
                             tr("请先在编辑模式下选择要删除的公告"));
        return;
    }
    auto ret = QMessageBox::question(
        this, tr("删除确认"),
        tr("是否确认删除选中的公告？"),
        QMessageBox::Yes | QMessageBox::No
    );
    if (ret != QMessageBox::Yes)
        return;

    QSqlQuery delQuery;
    delQuery.prepare("DELETE FROM notice WHERE id = :id");
    delQuery.bindValue(":id", currentNoticeId);

    if (!delQuery.exec()) {
        QMessageBox::critical(this, tr("删除失败"),
                              tr("删除公告失败：") + delQuery.lastError().text());
    } else {
        QMessageBox::information(this, tr("成功"), tr("公告删除成功"));
        model->select();
        setEditMode(false);
        ui->titleEdit->clear();
        ui->textEdit->clear();
    }
}
