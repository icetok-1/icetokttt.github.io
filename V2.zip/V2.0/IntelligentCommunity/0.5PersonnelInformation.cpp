#include "0.5PersonnelInformation.h"
#include "ui_0.5PersonnelInformation.h"
#include <QSqlTableModel>
#include <QMessageBox>

PersonnelInformation::PersonnelInformation(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PersonnelInformation)
{
    ui->setupUi(this);
    setupStyle();
    on_pushButton_clicked();
}
PersonnelInformation::~PersonnelInformation()
{
    delete ui;
}
void PersonnelInformation::on_pushButton_clicked()
{
    model = new QSqlTableModel(this);
    model->setTable("usrlist");
    model->select();
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->setHeaderData(0, Qt::Horizontal, "登录账号");
    model->setHeaderData(1, Qt::Horizontal, "手机号");
    model->setHeaderData(2, Qt::Horizontal, "身份证号");
    model->setHeaderData(3, Qt::Horizontal, "密码");
    model->setHeaderData(4, Qt::Horizontal, "身份标识");
    model->setHeaderData(5, Qt::Horizontal, "姓名");
    ui->tableView->setModel(model);
    ui->tableView->setEditTriggers(QAbstractItemView::DoubleClicked); // 双击编辑
    ui->tableView->resizeColumnsToContents();
    ui->tableView->horizontalHeader()->setStyleSheet(
        "QHeaderView::section { background-color: #87CEFA; color: black; font-weight: bold; }"
    );
    ui->tableView->horizontalHeader()->setVisible(true);
    ui->tableView->verticalHeader()->setVisible(true);
    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->setColumnWidth(0, 150);
    ui->tableView->setColumnWidth(1, 250);
    ui->tableView->setColumnWidth(2, 500);
    ui->tableView->setColumnWidth(3, 250);
    ui->tableView->setColumnWidth(4, 50);
    ui->tableView->setColumnWidth(5, 150);
}
void PersonnelInformation::on_btnDelete_clicked()
{
    if (!model) {
            QMessageBox::warning(this, "提示", "请先点击“显示”加载表格");
            return;
        }
        QModelIndexList selectedRows = ui->tableView->selectionModel()->selectedRows();
        if (selectedRows.isEmpty()) {
            QMessageBox::warning(this, "提示", "请选择要删除的行");
            return;
        }
        for (const QModelIndex &index : selectedRows) {
            model->removeRow(index.row());
        }
        model->submitAll();
}
void PersonnelInformation::on_btnSave_clicked()
{
    if (!model) {
            QMessageBox::warning(this, "提示", "请先点击“显示”加载表格");
            return;
        }
        if (model->submitAll()) { // 提交所有修改（包括删除和编辑）
            QMessageBox::information(this, "成功", "保存成功！");
        } else {
            QMessageBox::critical(this, "失败", "保存失败：" + model->lastError().text());
            model->revertAll(); // 回滚失败的修改
        }
}
void PersonnelInformation::setupStyle()
{
    QString tableViewStyle = R"(
        QTableView {
            alternate-background-color: #F5F5F5;
            selection-background-color: #BBDEFB;
            selection-color: black;
        }
        QTableView::item:hover {
            background-color: #EEEEEE;
        }
    )";
    QString existingTableStyle = ui->tableView->styleSheet();
    ui->tableView->setStyleSheet(existingTableStyle + tableViewStyle);
}
