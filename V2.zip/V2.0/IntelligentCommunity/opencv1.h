#ifndef opencv1_H
#define opencv1_H

#include <QWidget>
#include <QLabel>
#include <opencv2/opencv.hpp>

#include <QTableView>
#include <QSqlRelationalTableModel>
#include <QTimer>
QT_BEGIN_NAMESPACE
namespace Ui { class opencv1; }
QT_END_NAMESPACE

class opencv1 : public QWidget
{
    Q_OBJECT
public:
    explicit opencv1(QWidget *parent = nullptr);
    ~opencv1() override;

private slots:
    void on_pushButton_clicked();   // 选图并识别
    void refreshTableData();
    void on_pushButton_2_clicked();

private:
    void    showImage(const cv::Mat &mat); // 在 frame 中显示
    QString recognisePlate(const cv::Mat &src);

    static bool locatePlate(const cv::Mat &src, cv::RotatedRect &box);
    static cv::Mat warpPlate   (const cv::Mat &src, const cv::RotatedRect &box);

private:
    Ui::opencv1 *ui;
    QLabel         *viewer;
    QTableView *tableView;
    QSqlRelationalTableModel *tableModel;
    QTimer *refreshTimer;
    void setupTableModel();
    void setupTableView();// frame 内嵌显示标签
};
#endif // opencv1_H
