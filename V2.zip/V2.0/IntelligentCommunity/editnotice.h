#ifndef editnotice_H
#define editnotice_H

#include <QWidget>
#include <QSqlTableModel>

namespace Ui {
class editnotice;
}

class editnotice : public QWidget
{
    Q_OBJECT

public:
    explicit editnotice(QWidget *parent = nullptr);
    ~editnotice();

private slots:
    void on_pbEdit_clicked();      // 编辑按钮
    void on_pbAdd_clicked();       // 添加按钮
    void on_pushButton_clicked();    // 提交按钮
    void on_tableView_clicked(const QModelIndex &index); // 表格点击事件

    void on_pushButton_2_clicked();

private:
    Ui::editnotice *ui;
    QSqlTableModel *model;         // 表格模型
    bool isEditMode;               // 当前模式：true=编辑模式, false=添加模式
    int currentNoticeId;           // 当前编辑的公告ID
    void setupTableView();         // 初始化表格视图
    void setEditMode(bool enabled);// 设置编辑模式
};

#endif // editnotice_H
