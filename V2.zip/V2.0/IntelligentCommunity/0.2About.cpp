#include "0.2About.h"
#include "ui_0.2About.h"

extern int yonghuming;

canshushezhi::canshushezhi(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::canshushezhi)
{
    ui->setupUi(this);
}

canshushezhi::~canshushezhi()
{
    delete ui;
}
