#include "1.5SelfPayment.h"
#include "ui_1.5SelfPayment.h"

#include <QHeaderView>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>

extern int useridentification;

SelfPayment::SelfPayment(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::SelfPayment)
{
    ui->setupUi(this);

    ui->tableView->horizontalHeader()
        ->setSectionResizeMode(QHeaderView::Stretch);
}

SelfPayment::~SelfPayment()
{
    delete ui;
}

void SelfPayment::on_pushButton_clicked()
{
    QString state = ui->payTypecomboBox->currentText().trimmed();
    QString whereClause;
    if (state == "显示未缴费") {
        whereClause = "AND state = '否'";
    } else if (state == "显示已缴费") {
        whereClause = "AND state = '是'";
    }

    QString sql = QString(
        "SELECT payid, id, name, type, date, state, number "
        "FROM payment "
        "WHERE id = %1 %2"
    ).arg(useridentification).arg(whereClause);

    qDebug() << "查询：" << sql;
    auto *model = new QSqlQueryModel(this);
    model->setQuery(sql);
    if (model->lastError().isValid()) {
        QMessageBox::critical(this, "查询失败", model->lastError().text());
        return;
    }
    model->setHeaderData(0, Qt::Horizontal, "缴费单序列号");
    model->setHeaderData(1, Qt::Horizontal, "账号");
    model->setHeaderData(2, Qt::Horizontal, "姓名");
    model->setHeaderData(3, Qt::Horizontal, "类型");
    model->setHeaderData(4, Qt::Horizontal, "日期");
    model->setHeaderData(5, Qt::Horizontal, "是否缴费");
    model->setHeaderData(6, Qt::Horizontal, "缴费数量");

    ui->tableView->setModel(model);

    m_selectedPayId = -1;
    m_selectedType.clear();
}

void SelfPayment::on_tableView_clicked(const QModelIndex &index)
{
    auto *model = qobject_cast<QSqlQueryModel*>(ui->tableView->model());
    if (!model)
        return;

    int row = index.row();
    m_selectedPayId = model->data(model->index(row, 0)).toInt();
    m_selectedType  = model->data(model->index(row, 3)).toString();

    ui->tableView->selectRow(row);
    qDebug() << "已选择 payid =" << m_selectedPayId
             << ", type =" << m_selectedType;
}

void SelfPayment::on_pushButton_2_clicked()
{
    if (m_selectedPayId <= 0) {
        QMessageBox::warning(this, "错误", "请先在表格中选中一条缴费记录");
        return;
    }

    {
        QSqlQuery checkQuery;
        checkQuery.prepare(R"(
            SELECT state
              FROM payment
             WHERE type = ? AND payid = ?
        )");
        checkQuery.addBindValue(m_selectedType);
        checkQuery.addBindValue(m_selectedPayId);
        if (!checkQuery.exec()) {
            QMessageBox::critical(this, "错误", "校验缴费状态失败：" + checkQuery.lastError().text());
            return;
        }
        if (checkQuery.next()) {
            QString currState = checkQuery.value(0).toString().trimmed();
            if (currState == "是") {
                QMessageBox::information(this, "提示", "该记录已完成缴费，无需重复操作");
                return;
            }
        } else {
            QMessageBox::critical(this, "错误", "未能找到对应的缴费记录");
            return;
        }
    }

    QSqlQuery updateQuery;
    updateQuery.prepare(R"(
        UPDATE payment
           SET state = '是'
         WHERE type = ? AND payid = ?
    )");
    updateQuery.addBindValue(m_selectedType);
    updateQuery.addBindValue(m_selectedPayId);

    if (!updateQuery.exec()) {
        QMessageBox::critical(this, "错误", "缴费失败：" + updateQuery.lastError().text());
        return;
    }
    if (updateQuery.numRowsAffected() == 0) {
        QMessageBox::critical(this, "错误",
            QString("缴费失败：未找到 类型【%1】 序号【%2】 的记录")
            .arg(m_selectedType).arg(m_selectedPayId));
        return;
    }

    QMessageBox::information(this, "成功", "缴费成功！");
    on_pushButton_clicked();
}

