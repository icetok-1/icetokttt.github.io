#include "2.4PaymentInquiry.h"
#include "ui_2.4PaymentInquiry.h"
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QLineEdit>
#include <QStyledItemDelegate>
#include <QStyleOptionViewItem>

class CenterAlignDelegate : public QStyledItemDelegate {
public:
    using QStyledItemDelegate::QStyledItemDelegate;

    void initStyleOption(QStyleOptionViewItem *option, const QModelIndex &index) const override {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;
    }
};

extern int useridentification;

PaymentInquiry::PaymentInquiry(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaymentInquiry)
{
    ui->setupUi(this);

    ui->comboBox->clear();
    ui->comboBox->addItem("车位费");
    ui->comboBox->addItem("物业费");
    ui->comboBox->addItem("维修费");
    ui->comboBox->addItem("所有类型");

    ui->tableView->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #e7f9ff;
            color: black;
            padding: 4px;
            border: 1px solid #ccc;
            font-weight: bold;
        }
    )");

    updateUI();

    connect(ui->comboBox_2, &QComboBox::currentTextChanged, this, &PaymentInquiry::updateUI);
    connect(ui->comboBox, &QComboBox::currentTextChanged, this, &PaymentInquiry::updateUI);
}

PaymentInquiry::~PaymentInquiry()
{
    delete ui;
}

void PaymentInquiry::updateUI()
{
    bool isAllOwners = (ui->comboBox_2->currentText() == "所有业主");

    bool showOwnerFields = (ui->comboBox_2->currentText() == "个人");
    ui->label_6->setVisible(showOwnerFields);
    ui->lineEdit_3->setVisible(showOwnerFields);
}

void PaymentInquiry::on_pushButton_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString id = ui->lineEdit_3->text().trimmed();
    QString type = ui->comboBox->currentText();
    QString range = ui->comboBox_2->currentText(); // 改为 range 表示查询范围

    QString baseSql = "SELECT id, name, type, date, state, number FROM payment";
    QStringList conditions;

    if (type != "所有类型") {
        conditions.append(QString("type = '%1'").arg(type));
    }

    if (range == "个人") {
        if (id.isEmpty()) {
            QMessageBox::warning(this, "输入错误", "请输入业主ID进行个人查询");
            delete model;
            return;
        }
        conditions.append(QString("id = '%1'").arg(id));
    }

    QString whereClause;
    if (!conditions.isEmpty()) {
        whereClause = " WHERE " + conditions.join(" AND ");
    }

    QString sql = baseSql + whereClause;
    qDebug() << "Executing SQL:" << sql;

    model->setQuery(sql);

    if (model->lastError().isValid()) {
        QMessageBox::critical(this, "查询错误", "执行查询时出错:\n" + model->lastError().text());
        delete model;
        return;
    }

    model->setHeaderData(0, Qt::Horizontal, tr("账号"));
    model->setHeaderData(1, Qt::Horizontal, tr("姓名"));
    model->setHeaderData(2, Qt::Horizontal, tr("类型"));
    model->setHeaderData(3, Qt::Horizontal, tr("日期"));
    model->setHeaderData(4, Qt::Horizontal, tr("是否缴费"));
    model->setHeaderData(5, Qt::Horizontal, tr("缴费数量"));

    ui->tableView->setModel(model);
    ui->tableView->setColumnWidth(0, 240);
    ui->tableView->setColumnWidth(1, 240);
    ui->tableView->setColumnWidth(2, 240);
    ui->tableView->setColumnWidth(3, 300);
    ui->tableView->setColumnWidth(4, 150);
    ui->tableView->setColumnWidth(5, 210);

    for (int col = 0; col < model->columnCount(); ++col) {
        ui->tableView->setItemDelegateForColumn(col, new CenterAlignDelegate(this));
    }
}

void PaymentInquiry::on_comboBox_2_currentTextChanged(const QString &arg1)
{
    Q_UNUSED(arg1); // 实际处理由 updateUI() 完成
}
