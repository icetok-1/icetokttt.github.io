#include "0.3Initialization.h"
#include "ui_0.3Initialization.h"
#include <qdebug.h>
#include <QSqlQuery>
#include <QtSql/QSqlError>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQueryModel>
#include <QMessageBox>
extern int useridentification;
Initialization::Initialization(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Initialization)
{
    ui->setupUi(this);
}
Initialization::~Initialization()
{
    delete ui;
}
void Initialization::on_pushButton_clicked()
{
    QSqlQuery query;
    QString temp1 = QString("SELECT * FROM usrlist");
    query.exec(temp1);
    QMessageBox::information(nullptr, "警告", "信息是否要删除！！");
    QString str1 = QString("DELETE FROM usrlist WHERE mark != 0");
    query.exec(str1);  // 删除非管理员用户
    QString str2 = QString("DELETE FROM car");
    query.exec(str2);
    QString str3 = QString("DELETE FROM attendance");
    query.exec(str3);
    QString str4 = QString("DELETE FROM park");
    query.exec(str4);
    QString str5 = QString("DELETE FROM payment");
    query.exec(str5);
    QString str6 = QString("DELETE FROM leave");
    query.exec(str6);
    QString str7 = QString("DELETE FROM ParkingApply");
    query.exec(str7);
    QString str8 = QString("DELETE FROM weixiu");
    query.exec(str8);
    QString str9 = QString("DELETE FROM information");
    query.exec(str9);
    QMessageBox::information(nullptr, "Success", "信息删除成功！！");
}
