#ifndef WORKER_MAINWINDOW_H
#define WORKER_MAINWINDOW_H

#include <QMainWindow>
#include <particlesystem.h>
namespace Ui {
class worker_MainWindow;
}

class worker_MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit worker_MainWindow(QWidget *parent = nullptr);
    ~worker_MainWindow();

private:
    Ui::worker_MainWindow *ui;
    void paintEvent(QPaintEvent *event) override;
    particlesystem *m_particlesystem;
};

#endif // WORKER_MAINWINDOW_H
