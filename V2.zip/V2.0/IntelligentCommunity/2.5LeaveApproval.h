#ifndef workerleaveapproval_H
#define workerleaveapproval_H

#include <QWidget>

namespace Ui {
class workerleaveapproval;
}

class workerleaveapproval : public QWidget
{
    Q_OBJECT

public:
    explicit workerleaveapproval(QWidget *parent = nullptr);
    ~workerleaveapproval();

private slots:
    void on_pushButton_clicked();

    void on_leaveButton_clicked();

    void on_backButton_clicked();

private:
    Ui::workerleaveapproval *ui;
};

#endif // workerleaveapproval_H
