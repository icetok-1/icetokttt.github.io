#ifndef PARTICLESYSTEM_H
#define PARTICLESYSTEM_H

#include <QObject>
#include <QVector>
#include <QPointF>
#include <QColor>

class QTimer;
class QWidget;
class QPainter;

struct particle {
    QPointF position;
    QPointF velocity;
    qreal rotation;
    qreal rotationSpeed;
    qreal size;
    QColor color;
    int life;
    int initialLife;
};

class particlesystem : public QObject {
    Q_OBJECT
public:
    explicit particlesystem(QWidget *parent = nullptr);
    ~particlesystem();

    void start();
    void stop();
    void draw(QPainter *painter);

private slots:
    void updateParticles();

private:
    void addParticle();

    QWidget *m_parent;
    QTimer *m_timer;
    QVector<particle> m_particles;
};

#endif // PARTICLESYSTEM_H
