#ifndef PAYMENT_2DETAIL_H
#define PAYMENT_2DETAIL_H

#include <QWidget>

namespace Ui {
class payment_2detail;
}

class payment_2detail : public QWidget
{
    Q_OBJECT

public:
    explicit payment_2detail(QWidget *parent = nullptr);
    ~payment_2detail();

private slots:
    void on_commandLinkButton_clicked();

private:
    Ui::payment_2detail *ui;
};

#endif // PAYMENT_2DETAIL_H
