#include "particlesystem.h"
#include <QTimer>
#include <QPainter>
#include <QRandomGenerator>
#include <QDebug>
#include <QObject>
#include <QWidget>
particlesystem::particlesystem(QWidget *parent)
    : QObject(parent), m_parent(parent)
{
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &particlesystem::updateParticles);

    // 初始创建粒子
    for (int i = 0; i < 60; ++i) {
        addParticle();
    }
}

particlesystem::~particlesystem()
{
    stop();
}

void particlesystem::start()
{
    if (!m_timer->isActive()) {
        m_timer->start(16); // ≈60fps
    }
}

void particlesystem::stop()
{
    m_timer->stop();
}

void particlesystem::addParticle()
{
    if (!m_parent) return;

    particle p;
    p.position = QPointF(
        QRandomGenerator::global()->bounded(m_parent->width()),
        QRandomGenerator::global()->bounded(m_parent->height())
    );
    p.velocity = QPointF(QRandomGenerator::global()->bounded(0.5) - 0.25,
                        -1.5 - QRandomGenerator::global()->bounded(1.0));
    p.rotation = QRandomGenerator::global()->bounded(360);
    p.rotationSpeed = QRandomGenerator::global()->bounded(1.0) - 0.5;
    p.size = (2 + QRandomGenerator::global()->bounded(40));
    p.color = QColor(196,221,226,140);
    p.initialLife = 100 + QRandomGenerator::global()->bounded(200);
    p.life = p.initialLife;

    m_particles.append(p);
}

void particlesystem::updateParticles()
{
    for (int i = m_particles.size() - 1; i >= 0; --i) {
        particle &p = m_particles[i];
        p.position += p.velocity;
        p.rotation += p.rotationSpeed;
        p.life--;

        if (p.life <= 0 || p.position.y() < -20) {
            m_particles.removeAt(i);
            addParticle();
        }
    }
    if (m_parent) {
        m_parent->update();
    }
}

void particlesystem::draw(QPainter *painter)
{
    for (const particle &p : m_particles) {
        painter->save();
        painter->translate(p.position);
        painter->rotate(p.rotation);

        QColor color = p.color;
        qreal lifeRatio = static_cast<qreal>(p.life) / p.initialLife;
        qreal alphaFactor = 4 * lifeRatio * (1 - lifeRatio);
        color.setAlphaF(color.alphaF() * alphaFactor);

        painter->setBrush(color);
        painter->setPen(Qt::NoPen);
        painter->drawRect(-p.size/2, -p.size/2, p.size, p.size);
        painter->restore();
    }
}
