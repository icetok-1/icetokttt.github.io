#include "2.3PaymentEntry.h"
#include "ui_2.3PaymentEntry.h"

#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QDebug>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QHeaderView>
#include <QDate>
#include <QComboBox>

PaymentEntry::PaymentEntry(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PaymentEntry),
    tableModel(new QStandardItemModel(this))
{
    ui->setupUi(this);

    QStringList headers = { u8"账号", u8"姓名", u8"类型",
                            u8"日期", u8"是否缴费", u8"缴费数量" };
    tableModel->setHorizontalHeaderLabels(headers);

    ui->tableView->setModel(tableModel);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    refreshTableView();
    populateOwnersComboBox();
    connect(ui->comboBox_id,
            &QComboBox::currentTextChanged,
            this,
            &PaymentEntry::onOwnerSelectionChanged);

    ui->lineEdit->setText(QDate::currentDate().toString("yyyy-MM"));
}

PaymentEntry::~PaymentEntry()
{
    delete ui;
}
void PaymentEntry::refreshTableView()
{
    tableModel->removeRows(0, tableModel->rowCount());
    QSqlQuery query("SELECT id, name, type, date, state, number FROM payment");

    while (query.next()) {
        QList<QStandardItem*> rowItems;
        for (int i = 0; i < 6; ++i) {
            QStandardItem *item = new QStandardItem(query.value(i).toString());
            rowItems.append(item);
        }

        tableModel->appendRow(rowItems);
    }
    ui->tableView->resizeColumnsToContents();
}
void PaymentEntry::populateOwnersComboBox()
{
    ui->comboBox_id->clear();
    ui->comboBox_id->addItem(u8"所有业主");           // 默认项

    QSqlQuery query("SELECT id FROM usrlist WHERE mark = 1 ORDER BY id");
    while (query.next())
        ui->comboBox_id->addItem(query.value(0).toString());

    ui->comboBox_id->setCurrentIndex(0);             // 默认选中“所有业主”
    ui->lineEdit_2->setText(u8"所有业主");
}
void PaymentEntry::onOwnerSelectionChanged(const QString &text)
{
    if (text == u8"所有业主") {
        ui->lineEdit_2->setText(u8"所有业主");
        return;
    }

    QSqlQuery query;
    query.prepare("SELECT name FROM usrlist WHERE id = :id");
    query.bindValue(":id", text);
    if (query.exec() && query.next())
        ui->lineEdit_2->setText(query.value(0).toString());
    else
        ui->lineEdit_2->clear();
}
void PaymentEntry::on_pushButton_clicked()
{
    const QString date        = ui->lineEdit  ->text().trimmed();
    const QString propertyFee = ui->lineEdit_5->text().trimmed();
    const QString parkingFee  = ui->lineEdit_6->text().trimmed();
    const QString repairFee   = ui->lineEdit_7->text().trimmed();
    if (date.isEmpty() || (propertyFee.isEmpty() && parkingFee.isEmpty() && repairFee.isEmpty())) {
        QMessageBox::warning(this, "输入不完整", "请填写日期并至少输入一项费用！");
        return;
    }
    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        QMessageBox::critical(this, "数据库错误", "数据库未连接！");
        return;
    }
    if (!db.transaction()) {
        QMessageBox::critical(this, "事务失败",
                              "无法开启数据库事务：" + db.lastError().text());
        return;
    }

    QSqlQuery query;
    bool ok = true;

    auto execInsert = [&](const QString &uid,
                          const QString &uname,
                          const QString &type,
                          const QString &amount) {
        ok &= query.exec(QString(
            "INSERT INTO payment (id, name, type, date, state, number) "
            "VALUES ('%1', '%2', '%3', '%4', '否', '%5')")
            .arg(uid, uname, type, date, amount));
        if (ok)
            appendRowToView({ uid, uname, type, date, u8"否", amount });
    };

    if (ui->comboBox_id->currentText() == u8"所有业主") {
        QSqlQuery listQuery("SELECT id, name FROM usrlist WHERE mark = 1");
        while (listQuery.next()) {
            const QString uid   = listQuery.value(0).toString();
            const QString uname = listQuery.value(1).toString();

            if (!propertyFee.isEmpty())
                execInsert(uid, uname, u8"物业费",  propertyFee);
            if (!parkingFee.isEmpty())
                execInsert(uid, uname, u8"车位费",  parkingFee);
            if (!repairFee.isEmpty())
                execInsert(uid, uname, u8"维修费",  repairFee);
        }
    } else {
        const QString userId = ui->comboBox_id->currentText().trimmed();
        const QString name   = ui->lineEdit_2->text().trimmed();

        if (userId.isEmpty() || name.isEmpty()) {
            QMessageBox::warning(this, "信息缺失", "业主信息缺失，请重新选择！");
            db.rollback();
            return;
        }

        if (!propertyFee.isEmpty())
            execInsert(userId, name, u8"物业费",  propertyFee);
        if (!parkingFee.isEmpty())
            execInsert(userId, name, u8"车位费",  parkingFee);
        if (!repairFee.isEmpty())
            execInsert(userId, name, u8"维修费",  repairFee);
    }

    if (ok) {
        db.commit();
        QMessageBox::information(this, "操作成功", "费用信息成功写入！");
        clearInputFields();
    } else {
        db.rollback();
        QMessageBox::critical(this, "写入失败",
                              "数据库操作失败，已回滚。\n错误信息：" +
                              query.lastError().text());
        tableModel->removeRows(0, tableModel->rowCount());   // 清空视图残留
    }
}

void PaymentEntry::on_pushButton_2_clicked()
{
    const QModelIndex idx = ui->tableView->currentIndex();
    if (!idx.isValid()) {
        QMessageBox::information(this, "未选择", "请先在表格中选择一行再删除！");
        return;
    }

    const int row = idx.row();
    QList<QString> record;
    for (int col = 0; col < 6; ++col)
        record << tableModel->item(row, col)->text();

    if (!removeRowFromDb(record)) {
        QMessageBox::critical(this, "删除失败",
                              "数据库删除操作失败或未找到匹配记录！");
        return;
    }

    tableModel->removeRow(row);
}

bool PaymentEntry::removeRowFromDb(const QList<QString> &row)
{
    // row: id, name, type, date, state, number
    QSqlQuery query;
    query.prepare(
        "DELETE FROM payment "
        "WHERE id     = :id     AND "
              "name   = :name   AND "
              "type   = :type   AND "
              "date   = :date   AND "
              "state  = :state  AND "
              "number = :number");
    query.bindValue(":id",     row[0]);
    query.bindValue(":name",   row[1]);
    query.bindValue(":type",   row[2]);
    query.bindValue(":date",   row[3]);
    query.bindValue(":state",  row[4]);
    query.bindValue(":number", row[5]);

    if (!query.exec())
        return false;

    return query.numRowsAffected() > 0;
}

void PaymentEntry::appendRowToView(const QList<QString> &row)
{
    QList<QStandardItem*> items;
    items.reserve(6);
    for (const QString &text : row) {
        auto *it = new QStandardItem(text);
        it->setTextAlignment(Qt::AlignCenter);
        items << it;
    }
    tableModel->appendRow(items);
}

void PaymentEntry::clearInputFields()
{
    ui->comboBox_id->setCurrentIndex(0);
    ui->lineEdit_2->setText(u8"所有业主");
    ui->lineEdit->setText(QDate::currentDate().toString("yyyy-MM"));
    ui->lineEdit_5->clear();
    ui->lineEdit_6->clear();
    ui->lineEdit_7->clear();
}
