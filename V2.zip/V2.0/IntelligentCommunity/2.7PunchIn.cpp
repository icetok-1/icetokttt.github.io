#include "2.7PunchIn.h"
#include "ui_2.7PunchIn.h"

#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>
#include <QDateTime>
#include <QEvent>
#include <QPropertyAnimation>

extern int useridentification;

PunchIn::PunchIn(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PunchIn)
{
    ui->setupUi(this);
    ui->lineEdit_2->setEnabled(false);
    ui->lineEdit_4->setEnabled(false);
    originalGeometryBtn3 = ui->pushButton_3->geometry(); // ① 记录
    ui->pushButton_3->installEventFilter(this);          // ② 安装过滤器
}

PunchIn::~PunchIn()
{
    delete ui;
}

void PunchIn::on_pushButton_clicked()
{
    QSqlQuery query;
    QString namel;

    if (query.exec(QString("SELECT name FROM usrlist WHERE id = %1").arg(useridentification))) {
        if (query.next())
            namel = query.value(0).toString();
    }

    const QString shangban = ui->lineEdit_2->text().trimmed();
    const QString date     = ui->lineEdit_4->text().trimmed();

    if (namel.isEmpty() || shangban.isEmpty() || date.isEmpty()) {
        QMessageBox::warning(this, tr("提示"), tr("请填写完整信息"));
        return;
    }

    const QString insertStr =
        QStringLiteral("INSERT INTO attendance (name, shangban, date) "
                       "VALUES ('%1', '%2', '%3')")
        .arg(namel, shangban, date);

    if (!query.exec(insertStr)) {
        qDebug() << "插入失败:" << query.lastError();
        QMessageBox::critical(this, tr("错误"), tr("上班打卡失败！"));
    } else {
        QMessageBox::information(this, tr("成功"), tr("上班打卡成功！"));
    }
}

void PunchIn::on_pushButton_3_clicked()
{
    /* —— 1. 获取当前日期和时间 —— */
    const QDateTime now   = QDateTime::currentDateTime();
    const QTime     ctime = now.time();

    /* —— 2. 判断是否迟到 ——
       迟到区间：08:00:00–11:00:00  或  14:00:00–17:00:00 */
    const QTime startLate1(8, 0, 0),  endLate1(11, 0, 0);
    const QTime startLate2(14, 0, 0), endLate2(17, 0, 0);

    bool isLate = (ctime >= startLate1 && ctime <= endLate1) ||
                  (ctime >= startLate2 && ctime <= endLate2);

    /* —— 3. 组装显示文本 —— */
    QString display = ctime.toString("HH:mm:ss");
    if (isLate) display += "（迟到）";

    /* —— 4. 写入 lineEdit 并设定颜色 —— */
    ui->lineEdit_4->setText(now.date().toString("yyyy-MM-dd"));
    ui->lineEdit_2->setText(display);

    if (isLate)
        ui->lineEdit_2->setStyleSheet("color: red;"); // 整行变红提示
    else
        ui->lineEdit_2->setStyleSheet("");            // 恢复默认颜色

    /* —— 5. 点击后将按钮缩回原大小 —— */
    auto *anim = new QPropertyAnimation(ui->pushButton_3, "geometry", this);
    anim->setDuration(120);
    anim->setStartValue(ui->pushButton_3->geometry());
    anim->setEndValue(originalGeometryBtn3);
    anim->start(QAbstractAnimation::DeleteWhenStopped);
}

bool PunchIn::eventFilter(QObject *watched, QEvent *event)
{
    if (watched == ui->pushButton_3) {

        if (event->type() == QEvent::Enter) {

            const double scale = 1.1;
            QRect target = originalGeometryBtn3;
            target.setWidth (int(target.width()  * scale));
            target.setHeight(int(target.height() * scale));
            target.moveCenter(originalGeometryBtn3.center());

            auto *anim = new QPropertyAnimation(ui->pushButton_3, "geometry", this);
            anim->setDuration(120);
            anim->setStartValue(ui->pushButton_3->geometry());
            anim->setEndValue(target);
            anim->start(QAbstractAnimation::DeleteWhenStopped);

            return true;
        }

        if (event->type() == QEvent::Leave) {

            auto *anim = new QPropertyAnimation(ui->pushButton_3, "geometry", this);
            anim->setDuration(120);
            anim->setStartValue(ui->pushButton_3->geometry());
            anim->setEndValue(originalGeometryBtn3);
            anim->start(QAbstractAnimation::DeleteWhenStopped);

            return true;
        }
    }
    return QWidget::eventFilter(watched, event);
}
