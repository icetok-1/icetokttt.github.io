#include "2.0worker_mainwindow.h"
#include "ui_2.0worker_mainwindow.h"
#include "2.6clockout.h"
#include "2.11OwnerInformation.h"
#include "2.10Attendance.h"
#include "2.7PunchIn.h"
#include "2.8MaintainManage.h"
#include "2.2ParkingInformation.h"
#include "2.1ParkingRent.h"
#include "2.4PaymentInquiry.h"
#include "2.3PaymentEntry.h"
#include "2.9OfflinePayment.h"
#include "2.5LeaveApproval.h"
#include "2.12business.h"
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QSplitter>
#include <QSqlQuery>
#include <QLabel>
#include <QFont>
#include <QIcon>
#include <welcome.h>
#include <DataBaseManagerAndMainWindow.h>
#include <notice.h>
#include <opencv1.h>
#include <QPainter>
extern int useridentification;

worker_MainWindow::worker_MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::worker_MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("物业管理面板");
    this->setFixedSize(1700, 1100);
    m_particlesystem = new particlesystem(this);
    m_particlesystem->start();
    QTreeWidget *menuTree = new QTreeWidget;
    menuTree->setHeaderHidden(true);
    menuTree->setFixedWidth(260);
    menuTree->setStyleSheet(R"(
             QTreeWidget {
                 background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                 stop:0 #2079a1,
                 stop:1 #26cdcb);
                 border: none;
                 outline: 0;
              }
              QTreeWidget::item {
                background-color: transparent;  /* 透明以显示渐变背景 */
                border: none;
                padding: 6px 10px;
                margin: 2px;
                color: white;
                font-weight: bold;
                outline: none;
                border-radius:6px;
             }
             QTreeWidget::item:hover {
                background-color: qlineargradient(
                x1:0, y1:0.5, x2:1, y2:0.5,
                stop:0 rgba(33, 134, 167, 40),
                stop:1 rgba(29, 117, 146, 80)
                );
             }
             QTreeWidget::item:selected {
                 background-color: qlineargradient(
                 x1:0, y1:0.5, x2:1, y2:0.5,
                 stop:0 rgba(33, 134, 167, 40),
                 stop:1 rgba(29, 117, 146, 150)
                 );
                 color: white;
                 border: none;
             }
       )");
    QFont rootFont;  rootFont.setFamily("微软雅黑");  rootFont.setBold(true);  rootFont.setPointSize(16);
    QFont childFont; childFont.setFamily("微软雅黑"); childFont.setPointSize(12);

    QTreeWidgetItem *welRoot = new QTreeWidgetItem(menuTree, QStringList() << "首页");
    welRoot->setFont(0, rootFont);
    welRoot->setIcon(0, QIcon(":/iicoon/7.svg"));
    welRoot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *wel = new QTreeWidgetItem(welRoot, QStringList() << " 欢迎页");
    wel->setFont(0, childFont);
    wel->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *noticep = new QTreeWidgetItem(welRoot, QStringList() << " 公告");
    noticep->setFont(0, childFont);
    noticep->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *backp = new QTreeWidgetItem(welRoot, QStringList() << " 返回登录界面");
    backp->setFont(0, childFont);
    backp->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *ownerRoot = new QTreeWidgetItem(menuTree, QStringList() << "业主管理");
    ownerRoot->setFont(0, rootFont);
    ownerRoot->setIcon(0, QIcon(":/iicoon/7.svg"));
    ownerRoot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *ownerInfo = new QTreeWidgetItem(ownerRoot, QStringList() << " 业主信息管理");
    ownerInfo->setFont(0, childFont);
    ownerInfo->setSizeHint(0, QSize(200, 50));

    QTreeWidgetItem *hrRoot = new QTreeWidgetItem(menuTree, QStringList() << "人事管理");
    hrRoot->setFont(0, rootFont);
    hrRoot->setIcon(0, QIcon(":/iicoon/2.svg"));
    hrRoot->setSizeHint(0, QSize(200, 95));

    auto *hrAttendance = new QTreeWidgetItem(hrRoot, QStringList() << " 月度出勤");
    auto *hrPunch      = new QTreeWidgetItem(hrRoot, QStringList() << " 上班登记");
    auto *hrClockOut   = new QTreeWidgetItem(hrRoot, QStringList() << " 下班登记");
    auto *hrApproval   = new QTreeWidgetItem(hrRoot, QStringList() << " 请假销假");

    for (auto *item : { hrAttendance, hrPunch, hrApproval,hrClockOut}) {
        item->setFont(0, childFont);
        item->setSizeHint(0, QSize(200, 50));
    }

    // --- 车位管理 ---
    QTreeWidgetItem *parkRoot = new QTreeWidgetItem(menuTree, QStringList() << "车位管理");
    parkRoot->setFont(0, rootFont);
    parkRoot->setIcon(0, QIcon(":/iicoon/4.svg"));
    parkRoot->setSizeHint(0, QSize(200, 95));
    auto *license = new QTreeWidgetItem(parkRoot, QStringList() << " 车牌识别");
    auto *parkInfo = new QTreeWidgetItem(parkRoot, QStringList() << " 车位信息管理");
    auto *parkRent = new QTreeWidgetItem(parkRoot, QStringList() << " 车位出租");
    for (auto *item : {parkInfo, parkRent,license}) {
        item->setFont(0, childFont);
        item->setSizeHint(0, QSize(200, 50));
    }

    // --- 维修管理 ---
    QTreeWidgetItem *repairRoot = new QTreeWidgetItem(menuTree, QStringList() << "维修管理");
    repairRoot->setFont(0, rootFont);
    repairRoot->setIcon(0, QIcon(":/iicoon/6.svg"));
    repairRoot->setSizeHint(0, QSize(200, 95));

    QTreeWidgetItem *repairManage = new QTreeWidgetItem(repairRoot, QStringList() << " 维修管理");
    QTreeWidgetItem *repairbusiness = new QTreeWidgetItem(repairRoot, QStringList() << " 我的业务");
    repairManage->setFont(0, childFont);
    repairManage->setSizeHint(0, QSize(200, 50));
    repairbusiness->setFont(0, childFont);
    repairbusiness->setSizeHint(0, QSize(200, 50));
    // --- 缴费管理 ---
    QTreeWidgetItem *payRoot = new QTreeWidgetItem(menuTree, QStringList() << "缴费管理");
    payRoot->setFont(0, rootFont);
    payRoot->setIcon(0, QIcon(":/iicoon/5.svg"));
    payRoot->setSizeHint(0, QSize(200, 95));

    auto *payQuery    = new QTreeWidgetItem(payRoot, QStringList() << " 缴费信息查询");
    auto *payMaintain = new QTreeWidgetItem(payRoot, QStringList() << " 缴费发布系统");
    auto *payOffline  = new QTreeWidgetItem(payRoot, QStringList() << " 线下收费");
    for (auto *item : {payQuery, payMaintain, payOffline}) {
        item->setFont(0, childFont);
        item->setSizeHint(0, QSize(200, 50));
    }

    menuTree->setRootIsDecorated(true);
    menuTree->setIndentation(24);
    menuTree->collapseAll();

    QWidget *defaultPage = new Welcome;

    QSplitter *splitter = new QSplitter(this);
    splitter->addWidget(menuTree);
    splitter->addWidget(defaultPage);
    splitter->setStretchFactor(1, 1);
    splitter->setHandleWidth(2);
    splitter->setStyleSheet("QSplitter::handle { background-color: black; }");
    this->setCentralWidget(splitter);

    QSqlQuery query;
    query.exec(QString("SELECT * FROM usrlist WHERE id=%1").arg(useridentification));
    query.next();
    QString usrname = query.value(5).toString().trimmed();

    QLabel *normal = new QLabel(tr("欢迎您物业工作人员：%1").arg(usrname), this);
    ui->statusbar->addWidget(normal);
    ui->statusbar->setSizeGripEnabled(false);
    ui->statusbar->setStyleSheet("QStatusBar::item{border: 0px;}");

    connect(menuTree, &QTreeWidget::itemClicked, this,
        [=](QTreeWidgetItem *item, int) {
            QString text = item->text(0);
            QWidget *newPage = nullptr;
            if (text == " 业主信息管理")         newPage = new OwnerInformation;
            else if (text == " 月度出勤")        newPage = new Attendance;
            else if (text == " 欢迎页")         newPage = new Welcome;
            else if (text == " 公告")        newPage = new notice;
            else if (text == " 上班登记")      newPage = new PunchIn;
            else if (text == " 下班登记")      newPage = new ClockOut;
            else if (text == " 车牌识别")      newPage = new opencv1;
            else if (text == " 请假销假")        newPage = new workerleaveapproval;
            else if (text == " 车位信息管理")     newPage = new ParkingInformation;
            else if (text == " 车位出租")        newPage = new ParkingRent;
            else if (text == " 维修管理")        newPage = new MaintainManage;
            else if (text == " 缴费信息查询")     newPage = new PaymentInquiry;
            else if (text == " 缴费发布系统")        newPage = new PaymentEntry;
            else if (text == " 线下收费")        newPage = new OfflinePayment;
            else if (text == " 我的业务")        newPage = new business;
            else if (text == " 返回登录界面"){
                MainWindow *w = new MainWindow();
                w->show();
                this->hide();
            }
            if (newPage) {
                QWidget *old = splitter->widget(1);
                splitter->replaceWidget(1, newPage);
                delete old;
            }
    });
}
void worker_MainWindow::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    m_particlesystem->draw(&painter);
}
worker_MainWindow::~worker_MainWindow()
{
    delete ui;
}
