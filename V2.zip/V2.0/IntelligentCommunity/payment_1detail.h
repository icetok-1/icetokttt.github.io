#ifndef PAYMENT_1DETAIL_H
#define PAYMENT_1DETAIL_H

#include <QWidget>

namespace Ui {
class payment_1detail;
}

class payment_1detail : public QWidget
{
    Q_OBJECT

public:
    explicit payment_1detail(QWidget *parent = nullptr);
    ~payment_1detail();

private slots:
    void on_commandLinkButton_clicked();

private:
    Ui::payment_1detail *ui;
};

#endif // PAYMENT_1DETAIL_H
