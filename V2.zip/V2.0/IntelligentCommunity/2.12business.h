#ifndef BUSINESS_H
#define BUSINESS_H

#include <QWidget>
#include <QSqlTableModel>
#include <QTableView>

namespace Ui {
class business;
}

class business : public QWidget
{
    Q_OBJECT

public:
    explicit business(QWidget *parent = nullptr);
    ~business();

private slots:
    void on_pushButton_clicked();

private:
    Ui::business *ui {};
    QSqlTableModel *myModel      {};   // “我的业务”数据模型
    QSqlTableModel *pendingModel {};   // “待派工”数据模型
    QString         myName;            // 当前登录用户姓名

    void initTables();
    void refreshTables();

    static void beautifyTableView(QTableView *view);
};

#endif // BUSINESS_H
