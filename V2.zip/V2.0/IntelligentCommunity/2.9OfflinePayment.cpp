#include "2.9OfflinePayment.h"
#include "ui_2.9OfflinePayment.h"

#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>
#include <QStyledItemDelegate>

extern int useridentification;

class CenterAlignDelegate : public QStyledItemDelegate {
public:
    using QStyledItemDelegate::QStyledItemDelegate;
    void initStyleOption(QStyleOptionViewItem *option,
                         const QModelIndex &index) const override {
        QStyledItemDelegate::initStyleOption(option, index);
        option->displayAlignment = Qt::AlignCenter;
    }
};

OfflinePayment::OfflinePayment(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OfflinePayment)
{
    ui->setupUi(this);

    ui->tableView->setItemDelegate(new CenterAlignDelegate(this));

    connect(ui->tableView,
            &QTableView::clicked,
            this,
            &OfflinePayment::onTableRowClicked);
}

OfflinePayment::~OfflinePayment()
{
    delete ui;
}

void OfflinePayment::on_pushButton_clicked()
{
    QString id = ui->lineEdit_4->text().trimmed();
    if (id.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入用户 ID");
        return;
    }

    QSqlQueryModel *model = new QSqlQueryModel(this);
    QString sql = QString(
        "SELECT id, name, type, date, state, number "
        "FROM payment WHERE id = %1 AND state = '否'"
    ).arg(id);

    model->setQuery(sql);
    if (model->lastError().isValid()) {
        QMessageBox::warning(this, "查询失败", model->lastError().text());
        return;
    }

    model->setHeaderData(0, Qt::Horizontal, "ID");
    model->setHeaderData(1, Qt::Horizontal, "姓名");
    model->setHeaderData(2, Qt::Horizontal, "类型");
    model->setHeaderData(3, Qt::Horizontal, "日期");
    model->setHeaderData(4, Qt::Horizontal, "是否缴费");
    model->setHeaderData(5, Qt::Horizontal, "缴费金额");

    ui->tableView->setModel(model);

    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive); // 手动设置
    ui->tableView->horizontalHeader()->setStretchLastSection(false);                  // 不自动填满
    ui->tableView->setColumnWidth(0, 200);   // ID
    ui->tableView->setColumnWidth(1, 200);   // 姓名
    ui->tableView->setColumnWidth(2, 200);  // 类型
    ui->tableView->setColumnWidth(3, 375);  // 日期
    ui->tableView->setColumnWidth(4, 200);   // 是否缴费
    ui->tableView->setColumnWidth(5, 200);  // 金额
}

void OfflinePayment::onTableRowClicked(const QModelIndex &index)
{
    if (!index.isValid())
        return;

    QAbstractItemModel *model = ui->tableView->model();
    const int row = index.row();

    QString type  = model->index(row, 2).data().toString();
    ui->lineEdit->setText(type);

    QString date  = model->index(row, 3).data().toString();
    ui->lineEdit_6->setText(date);

    QString money = model->index(row, 5).data().toString();
    ui->lineEdit_2->setText(money);
}

void OfflinePayment::on_pushButton_2_clicked()
{
    QString id    = ui->lineEdit_4->text().trimmed();
    QString type  = ui->lineEdit   ->text().trimmed();
    QString date  = ui->lineEdit_6->text().trimmed();
    QString money = ui->lineEdit_2->text().trimmed();

    if (id.isEmpty() || type.isEmpty() || date.isEmpty() || money.isEmpty()) {
        QMessageBox::warning(this, "提示", "请完整填写 ID、类型、日期 和 金额！");
        return;
    }

    QSqlQuery query;
    query.prepare(
        "UPDATE payment SET state = '是' "
        "WHERE id = :id AND type = :type AND date = :date "
        "AND number = :number AND state = '否'");

    query.bindValue(":id",     id);
    query.bindValue(":type",   type);
    query.bindValue(":date",   date);
    query.bindValue(":number", money);

    if (!query.exec()) {
        QMessageBox::warning(this, "缴费失败", "数据库更新失败：" + query.lastError().text());
        return;
    }
    if (query.numRowsAffected() == 0) {
        QMessageBox::information(this, "提示", "未找到待更新记录，可能已缴费或信息不匹配。");
        return;
    }

    ui->lineEdit   ->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_6->clear();

    QMessageBox::information(this, "成功", "缴费成功！");
    on_pushButton_clicked();
}
