#include "2.6clockout.h"
#include "ui_2.6clockout.h"

#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>
#include <QDateTime>
#include <QEvent>
#include <QPropertyAnimation>

extern int useridentification;

ClockOut::ClockOut(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ClockOut)
{
    ui->setupUi(this);
    ui->lineEdit_3->setEnabled(false);
    ui->lineEdit_4->setEnabled(false);
    originalGeometryBtn = ui->pushButton->geometry();  // 时间戳按钮
    ui->pushButton->installEventFilter(this);
}

ClockOut::~ClockOut()
{
    delete ui;
}

void ClockOut::on_pushButton_clicked()
{
    const QDateTime now = QDateTime::currentDateTime();
    ui->lineEdit_4->setText(now.date().toString("yyyy-MM-dd")); // 年月日
    ui->lineEdit_3->setText(now.time().toString("HH:mm:ss"));   // 时:分:秒

    auto *anim = new QPropertyAnimation(ui->pushButton, "geometry", this);
    anim->setDuration(120);
    anim->setStartValue(ui->pushButton->geometry());
    anim->setEndValue(originalGeometryBtn);
    anim->start(QAbstractAnimation::DeleteWhenStopped);
}

void ClockOut::on_pushButton_2_clicked()
{
    QSqlQuery query;
    QString namel;

    if (query.exec(QString("SELECT name FROM usrlist WHERE id = %1").arg(useridentification))) {
        if (query.next())
            namel = query.value(0).toString();
    }

    const QString xiaban = ui->lineEdit_3->text().trimmed();
    const QString date   = ui->lineEdit_4->text().trimmed();

    if (namel.isEmpty() || xiaban.isEmpty() || date.isEmpty()) {
        QMessageBox::warning(this, tr("提示"), tr("请填写完整信息"));
        return;
    }

    const QString updateStr =
        QStringLiteral("UPDATE attendance SET xiaban = '%1' "
                       "WHERE name = '%2' AND date = '%3'")
        .arg(xiaban, namel, date);

    if (!query.exec(updateStr)) {
        qDebug() << "更新失败:" << query.lastError();
        QMessageBox::critical(this, tr("错误"), tr("下班打卡失败！"));
    } else {
        QMessageBox::information(this, tr("成功"), tr("下班打卡成功！"));
        ui->lineEdit_3->clear();
    }
}

bool ClockOut::eventFilter(QObject *watched, QEvent *event)
{
    if (watched == ui->pushButton) {

        if (event->type() == QEvent::Enter) {

            const double scale = 1.1;                      // 放大 110%
            QRect target = originalGeometryBtn;
            target.setWidth (int(target.width()  * scale));
            target.setHeight(int(target.height() * scale));
            target.moveCenter(originalGeometryBtn.center());

            auto *anim = new QPropertyAnimation(ui->pushButton, "geometry", this);
            anim->setDuration(120);
            anim->setStartValue(ui->pushButton->geometry());
            anim->setEndValue(target);
            anim->start(QAbstractAnimation::DeleteWhenStopped);

            return true;
        }

        if (event->type() == QEvent::Leave) {

            auto *anim = new QPropertyAnimation(ui->pushButton, "geometry", this);
            anim->setDuration(120);
            anim->setStartValue(ui->pushButton->geometry());
            anim->setEndValue(originalGeometryBtn);
            anim->start(QAbstractAnimation::DeleteWhenStopped);

            return true;
        }
    }

    return QWidget::eventFilter(watched, event);  // 其余事件交由基类处理
}
