#include "notice.h"
#include "ui_notice.h"
#include <QSqlTableModel>
#include <QTableView>
#include <QMessageBox>
#include <QSqlError>
notice::notice(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::notice)
{
    ui->setupUi(this);
    noticeModel = new QSqlTableModel(this);
        noticeModel->setTable("notice");

        noticeModel->setHeaderData(noticeModel->fieldIndex("id"), Qt::Horizontal, tr("ID"));
        noticeModel->setHeaderData(noticeModel->fieldIndex("description"), Qt::Horizontal, tr("公告描述"));
        noticeModel->setHeaderData(noticeModel->fieldIndex("publisher"), Qt::Horizontal, tr("发布人"));
        noticeModel->setHeaderData(noticeModel->fieldIndex("pub_date"), Qt::Horizontal, tr("发布日期"));

        noticeModel->setSort(noticeModel->fieldIndex("pub_date"), Qt::DescendingOrder);

        if (!noticeModel->select()) {
            QMessageBox::critical(this, "错误", "加载公告数据失败: " + noticeModel->lastError().text());
            return;
        }

        ui->tableView->setModel(noticeModel);

        ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
        ui->tableView->horizontalHeader()->setStretchLastSection(true);

        ui->tableView->setColumnHidden(noticeModel->fieldIndex("id"), true);

        ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);

        ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
}

notice::~notice()
{
    delete ui;
}
