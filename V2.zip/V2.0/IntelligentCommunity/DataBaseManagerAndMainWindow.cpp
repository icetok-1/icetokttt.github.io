#include "DataBaseManagerAndMainWindow.h"
#include "ui_DataBaseManagerAndMainWindow.h"
#include "2.0worker_mainwindow.h"
#include "1.0ownermainwindow.h"
#include "0.0admin_mainwindow.h"
#include <hoverlineedit.h>
#include "overall.h"
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QLineEdit>
#include <QFile>
#include <QSqlError>
#include <QCoreApplication>
#include <QPainter>
#include <QDebug>
#include <QStyle>
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <hoverlineedit.h>
#include "overall.h"
extern int useridentification;
ParticleSystem::ParticleSystem(QWidget *parent)
    : QObject(parent), m_parent(parent)
{
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &ParticleSystem::updateParticles);
    m_timer->start(16);
    for (int i = 0; i < 60; ++i)
    {
        addParticle();
    }
}
void ParticleSystem::addParticle()
{
    Particle p;
    p.position = QPointF(
        QRandomGenerator::global()->bounded(m_parent->width()),
        QRandomGenerator::global()->bounded(m_parent->height())
    );
    p.velocity = QPointF(QRandomGenerator::global()->bounded(0.5) - 0.25,
                        -1.5 - QRandomGenerator::global()->bounded(1.0));
    p.rotation = QRandomGenerator::global()->bounded(360);
    p.rotationSpeed = QRandomGenerator::global()->bounded(1.0) - 0.5;
    p.size = (5 + QRandomGenerator::global()->bounded(40));
    p.color = QColor(200, 200, 255, 180);

    p.initialLife = 100 + QRandomGenerator::global()->bounded(200);
    p.life = p.initialLife;
    m_particles.append(p);
}
void ParticleSystem::updateParticles()
{
    for (int i = m_particles.size() - 1; i >= 0; --i)
    {
        Particle &p = m_particles[i];
        p.position += p.velocity;
        p.rotation += p.rotationSpeed;
        p.life--;
        if (p.life <= 0 || p.position.y() < -20)
        {
            m_particles.removeAt(i);
            addParticle();
        }
    }
    m_parent->update();
}
void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QLinearGradient gradient(0, 0, width(), height());
    gradient.setColorAt(0.0, QColor(32, 120, 160));
    gradient.setColorAt(1.0, QColor(38, 208, 206));
    painter.fillRect(rect(), gradient);
    const QVector<Particle> &particles = m_particleSystem->particles();
    for (const Particle &p : particles)
    {
            painter.save();
            painter.translate(p.position);
            painter.rotate(p.rotation);
            QColor color = p.color;
            qreal lifeRatio = static_cast<qreal>(p.life) / p.initialLife;
            qreal alphaFactor = 4 * lifeRatio * (1 - lifeRatio);
            color.setAlphaF((p.color.alphaF() * alphaFactor));
            painter.setBrush(color);
            painter.setPen(Qt::NoPen);
            painter.drawRect(-p.size/2, -p.size/2, p.size, p.size);
            painter.restore();
     }
}
//模拟鼠标悬浮放大lineEdit
HoverLineEdit::HoverLineEdit(QWidget *parent)
    : QLineEdit(parent), m_isHovered(false)
{
    m_animation = new QPropertyAnimation(this, "geometry");
    m_animation->setDuration(100);
    m_animation->setEasingCurve(QEasingCurve::OutQuad);
    m_originalGeometry = geometry();
}
void HoverLineEdit::enterEvent(QEvent *event)
{
    Q_UNUSED(event);
    if (m_animation->state() == QAbstractAnimation::Running) {
        m_animation->stop();
    }
    m_originalGeometry = geometry();
    QRect enlarged = m_originalGeometry;
    enlarged.setWidth(m_originalGeometry.width() * 1.05);
    enlarged.setHeight(m_originalGeometry.height() * 1.3);
    enlarged.moveCenter(m_originalGeometry.center());
    m_animation->setStartValue(geometry());
    m_animation->setEndValue(enlarged);
    m_animation->start();
}
void HoverLineEdit::leaveEvent(QEvent *event)
{
    Q_UNUSED(event);
    if (m_animation->state() == QAbstractAnimation::Running) {
        m_animation->stop();
    }
    m_animation->setStartValue(geometry());
    m_animation->setEndValue(m_originalGeometry);
    m_animation->start();
}
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("智慧社区管理系统");
    this->setFixedSize(1400, 791);
    m_particleSystem = new ParticleSystem(this);
    QString dbPath = QCoreApplication::applicationDirPath() + "/Database.db";
    bool dbFileExists = QFile::exists(dbPath);
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);
    if (!db.open()) {
        QMessageBox::critical(nullptr, "数据库连接失败",
                              "无法打开数据库文件。\n" + db.lastError().text(),
                              QMessageBox::Cancel);
        return;
    }
    QSqlQuery query;
    // 表1：usrlist 用户表
    if (!dbFileExists || !db.tables().contains("usrlist")) {
        QString createUsrlist = R"(
            CREATE TABLE IF NOT EXISTS usrlist (
                id INTEGER PRIMARY KEY,
                tel TEXT,
                IDcard TEXT,
                password TEXT,
                mark INTEGER,
                name TEXT
            )
        )";
        if (!query.exec(createUsrlist)) {
            QMessageBox::critical(this, "初始化失败", "创建 usrlist 表失败：" + query.lastError().text());
            return;
        }
        QString insertInit = R"(
            INSERT INTO usrlist (id, tel, IDcard, password, mark, name) VALUES
            (1001, '15800000000', '445566000000000000', '1', 1, '张三'),
            (1002, '18300000000', '778899000000000000', '2', 2, '李四'),
            (1003, '17900000000', '666999000000000000', '3', 0, '李辉'),
            (1004, '17600000000', '332211000000000000', '4', 1, '王五'),
            (1000, '19800000000', '666666000000000000', '0', 0, '赵六'),
            (1005, '18300000000', '370784000000000000', '123456', 1, '钱七'),
            (1006, '15800000000', '370722000000000000', '123456', 2, '孙八'),
            (1010, '17900000000', '370700000000000000', '123456', 2, '李华'),
            (1007, '15500000000', '123456000000000000', '654321', 1, '周九'),
            (1008, '17600000000', '112233000000000000', '654321', 1, '吴十'),
            (1009, '19800000000', '666888000000000000', '666888', 1, '郑一')
        )";
        query.exec(insertInit);
    }
    // 表2：car 车辆信息表
    QString createCar = R"(
        CREATE TABLE IF NOT EXISTS car (
            cid INTEGER PRIMARY KEY AUTOINCREMENT,
            color TEXT,
            brand TEXT,
            car_id TEXT,
            user_id INTEGER
        )
    )";
    if (!query.exec(createCar)) {
        QMessageBox::critical(this, "初始化失败", "创建 car 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM car");
    if (query.next() && query.value(0).toInt() == 0) {
        query.exec(R"(
            INSERT INTO car (color, brand, car_id, user_id) VALUES
            ('黑色', '宝马', '京A12345', 1001),
            ('白色', '奔驰', '京B67890', 1002),
            ('银色', '奥迪', '京C54321', 1003),
            ('红色', '宝马', '京D98765', 1004),
            ('蓝色', '特斯拉', '京E24680', 1005),
            ('黑色', '比亚迪', '京F13579', 1006),
            ('灰色', '大众', '京G86420', 1007),
            ('香槟色', '雷克萨斯', '京H97531', 1008),
            ('绿色', '沃尔沃', '京J25801', 1009),
            ('橙色', '保时捷', '沪B69999', 1000)
        )");
    }
    // 表3：park 车位信息表
    QString createPark = R"(
        CREATE TABLE IF NOT EXISTS park (
            number  TEXT PRIMARY KEY,
            addr    TEXT,
            sellout TEXT,
            user_id INTEGER
        )
    )";
    if (!query.exec(createPark)) {
        QMessageBox::critical(this, "初始化失败", "创建 park 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM park");
    if (query.next() && query.value(0).toInt() == 0) {
        query.exec(R"(
            INSERT INTO park (number, addr, sellout, user_id) VALUES
            ('A001', '1号楼地下1层A区001号', '否', 1001),
            ('A002', '1号楼地下1层A区002号', '否', 1002),
            ('A003', '1号楼地下1层A区003号', '是', 1003),
            ('B001', '1号楼地下1层B区001号', '否', 1004),
            ('B002', '1号楼地下1层B区002号', '是', 1005),
            ('B003', '1号楼地下1层B区003号', '否', 1006),
            ('C001', '2号楼地下1层C区001号', '是', 1007),
            ('C002', '2号楼地下1层C区002号', '否', 1008),
            ('C003', '2号楼地下1层C区003号', '是', 1009),
            ('D001', '2号楼地下1层D区001号', '否', 1000)
        )");
    }
    // 表4：ParkingApply 车位申请表
    QString createParkingApply = R"(
        CREATE TABLE IF NOT EXISTS ParkingApply (
            sid INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            state TEXT,
            date TEXT,
            parknum TEXT
        )
    )";
    if (!query.exec(createParkingApply)) {
        QMessageBox::critical(this, "初始化失败", "创建 ParkingApply 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM ParkingApply");
    if (query.next() && query.value(0).toInt() == 0) {
        query.exec(R"(
            INSERT INTO ParkingApply (user_id, state, date, parknum) VALUES
            (1001, '申请中', '2025-07-08', 'A001'),
            (1002, '已通过', '2025-07-09', 'A002'),
            (1003, '申请中', '2025-07-07', 'A003'),
            (1004, '申请中', '2025-07-10', 'B001'),
            (1005, '已通过', '2025-07-06', 'B002'),
            (1006, '申请中', '2025-07-05', 'B003'),
            (1007, '已通过', '2025-07-04', 'C001'),
            (1008, '申请中', '2025-07-03', 'C002'),
            (1009, '已通过', '2025-07-02', 'C003'),
            (1000, '申请中', '2025-07-01', 'D001')
        )");
    }
    // 表5：leave 请假表
    QString createLeave = R"(
        CREATE TABLE IF NOT EXISTS leave (
            name   TEXT,
            date   TEXT,
            id     TEXT,
            date2  TEXT,
            shenpi TEXT,
            xiaojia TEXT,
            lid    INTEGER PRIMARY KEY AUTOINCREMENT
        )
    )";
    if (!query.exec(createLeave)) {
        QMessageBox::critical(this, "初始化失败", "创建 leave 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM leave");
    if (query.next() && query.value(0).toInt() == 0) {
        query.exec(R"(
            INSERT INTO leave (name, date, id, date2, shenpi, xiaojia) VALUES
            ('李四', '2025-07-08', '事假', '2025-07-20', '待审批','2025-07-21'),
            ('孙八', '2025-07-09', '病假', '2025-07-12', '待审批', '2025-07-13'),
            ('李华', '2025-07-10', '病假', '2025-07-23', '待审批', NULL)
        )");
    }
    // 表6：attendance 出勤记录表
    QString createAttendance = R"(
        CREATE TABLE IF NOT EXISTS attendance (
            name     TEXT,
            shangban TEXT,
            xiaban   TEXT,
            date     TEXT
        )
    )";
    if (!query.exec(createAttendance)) {
        QMessageBox::critical(this, "初始化失败", "创建 attendance 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM attendance");
    if (query.next() && query.value(0).toInt() == 0) {
        query.exec(R"(
            INSERT INTO attendance (name, shangban, xiaban, date) VALUES
            ('李四', '07:59:59', '11:30:21', '2025-07-08'),
            ('孙八','08:00:01(迟到)','11:30:00','2025-07-14'),
            ('李四', '07:30:00', '12:30:10', '2025-07-14'),
            ('孙八','08:30:01(迟到)','11:30:20','2025-07-15'),
            ('李四', '13:59:59', '17:30:21', '2025-07-15'),
            ('孙八','07:50:01','11:40:00','2025-07-16'),
            ('李四', '14:05:59(迟到)', '17:30:21', '2025-07-16'),
            ('孙八','08:02:01(迟到)','11:30:00','2025-07-17'),
            ('李华','07:50:01','11:40:00','2025-07-08'),
            ('李华','07:55:01','11:30:00','2025-07-09'),
            ('李华','07:52:01','11:43:00','2025-07-10'),
            ('李华','07:53:01','11:41:00','2025-07-11'),
            ('李华','07:53:01','11:41:00','2025-07-12'),
            ('李四', NULL, NULL, '2025-07-13')
        )");
    }
    // 表7：payment 缴费记录表（合并了 typer.number 字段）
    QString createPayment = R"(
        CREATE TABLE IF NOT EXISTS payment (
            id     INTEGER,
            name   TEXT,
            type   TEXT,
            date   TEXT,
            state  TEXT,
            number TEXT,
            payid  INTEGER PRIMARY KEY AUTOINCREMENT
        )
    )";
    if (!query.exec(createPayment)) {
        QMessageBox::critical(this, "初始化失败", "创建 payment 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM payment");
    if (query.next() && query.value(0).toInt() == 0) {
        query.exec(R"(
            INSERT INTO payment (id, name, type, date, state, number) VALUES
            (1001, '张三', '物业费', '2025-05', '否', '200.00'),
            (1001, '张三', '维修费', '2025-07', '是', '999.00'),
            (1001, '张三', '车位费', '2025-07', '否', '200.00'),
            (1004, '王五', '物业费', '2025-06', '否', '200.00'),
            (1004, '王五', '维修费', '2025-05', '否', '150.50'),
            (1004, '王五', '车位费', '2025-07', '否', '150.50'),
            (1005, '钱七', '物业费', '2025-05', '是', '200.00'),
            (1005, '钱七', '维修费', '2025-05', '否', '450.00'),
            (1005, '钱七', '车位费', '2025-05', '是', '450.00'),
            (1007, '周九', '物业费', '2025-06', '否', '200.00'),
            (1007, '周九', '维修费', '2025-06', '否', '120.30'),
            (1007, '周九', '车位费', '2025-06', '否', '120.30'),
            (1008, '吴十', '物业费', '2025-07', '否', '200.00'),
            (1008, '吴十', '维修费', '2025-07', '是', '500.00'),
            (1008, '吴十', '车位费', '2025-06', '否', '500.00'),
            (1009, '郑一', '物业费', '2025-07', '是', '200.00'),
            (1009, '郑一', '维修费', '2025-07', '否', '300.00'),
            (1009, '郑一', '车位费', '2025-05', '是', '300.00'),
            (1001, '张三', '物业费', '2025-06', '是', '200.00'),
            (1001, '张三', '维修费', '2025-05', '是', '999.00'),
            (1001, '张三', '车位费', '2025-05', '是', '200.00'),
            (1004, '王五', '物业费', '2025-05', '是', '200.00'),
            (1004, '王五', '维修费', '2025-06', '是', '150.50'),
            (1004, '王五', '车位费', '2025-06', '否', '150.50'),
            (1005, '钱七', '物业费', '2025-07', '是', '200.00'),
            (1005, '钱七', '维修费', '2025-06', '是', '450.00'),
            (1005, '钱七', '车位费', '2025-06', '是', '450.00')
        )");
    }
    // 表8：weixiu 报修记录表
    QString createWeixiu = R"(
        CREATE TABLE IF NOT EXISTS weixiu (
            序号       INTEGER,
            姓名       TEXT,
            电话       TEXT,
            地址       TEXT,
            问题描述   TEXT,
            受理情况   TEXT,
            维修进度   TEXT,
            维修评价   TEXT,
            工作人员    TEXT,
            ID       INTEGER PRIMARY KEY AUTOINCREMENT
        )
    )";
    if (!query.exec(createWeixiu)) {
        QMessageBox::critical(this, "初始化失败", "创建 weixiu 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM weixiu");
    if (query.next() && query.value(0).toInt() == 0) {
        query.exec(R"(
            INSERT INTO weixiu (序号, 姓名, 电话, 地址, 问题描述, 受理情况, 维修进度, 维修评价,工作人员) VALUES
            (1001, '张三', '001', '1号楼101 室', '门锁损坏', '已受理', '已派工', NULL,'李四'),
            (1004, '王五', '004', '1号楼104 室', '马桶损坏', '已受理', '未派工', NULL,NUll),
            (1002, '李四', '002', '1号楼102 室', '水管漏水', '已受理', '未派工', NULL, NUll),
            (1003, '李辉', '003', '1号楼103 室', '电路故障', '已受理', '已完成', '满意', '李四'),
            (1005, '钱七', '005', '1号楼105 室', '窗户损坏', '未受理', '未派工', NULL, NULL),
            (1006, '孙八', '006', '2号楼201 室', '空调不制冷', '已受理', '已派工', NULL, '李四'),
            (1007, '周九', '007', '2号楼202 室', '马桶堵塞', '已受理', '未派工', NULL, NUll),
            (1008, '吴十', '008', '2号楼203 室', '门锁卡顿', '已受理', '已派工', NULL, '孙八'),
            (1009, '郑一', '009', '2号楼204 室', '墙面渗水', '未受理', '未派工', NULL, NULL),
            (1000, '赵六', '000', '2号楼205 室', '灯具损坏', '已受理', '已完成', '非常满意', '李四')
        )");
    }
    // 表9：information 信息登记表
    QString createInformation = R"(
        CREATE TABLE IF NOT EXISTS information (
            id      INTEGER PRIMARY KEY,
            name    TEXT,
            age     INTEGER,
            sex     TEXT,
            tel     TEXT,
            address TEXT
        )
    )";
    if (!query.exec(createInformation)) {
        QMessageBox::critical(this, "初始化失败", "创建 information 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM information");
    if (query.next() && query.value(0).toInt() == 0) {
        QString insertInformation = R"(
            INSERT INTO information (id, name, age, sex, tel, address) VALUES
            (1001, '张三', 20, '男', '15800000000', '1号楼101室'),
            (1004, '王五', 20, '男', '17600000000', '1号楼104室'),
            (1002, '李四', 25, '男', '18300000000', '1号楼102室'),
            (1003, '李辉', 35, '男', '17900000000', '1号楼103室'),
            (1005, '钱七', 22, '女', '18300000000', '1号楼105室'),
            (1006, '孙八', 28, '男', '15800000000', '2号楼201室'),
            (1007, '周九', 30, '女', '15500000000', '2号楼202室'),
            (1008, '吴十', 26, '男', '17600000000', '2号楼203室'),
            (1009, '郑一', 24, '女', '19800000000', '2号楼204室'),
            (1000, '赵六', 29, '男', '19800000000', '2号楼205室'),
            (1010, '李华', 22, '男', '17900000000', '3号楼303室')
        )";
        if (!query.exec(insertInformation)) {
            QMessageBox::warning(this, "插入失败", "初始化插入信息失败：" + query.lastError().text());
        }
    }
    //表10. notice 公告信息表
    QString createNotice = R"(
        CREATE TABLE IF NOT EXISTS notice (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            title       TEXT,
            description TEXT,
            publisher   TEXT,
            pub_date    TEXT
        )
    )";  
    if (!query.exec(createNotice)) {
        QMessageBox::critical(this, "初始化失败", "创建 notice 表失败：" + query.lastError().text());
        return;
    }
    query.exec("SELECT COUNT(*) FROM notice");
    if (query.next() && query.value(0).toInt() == 0) {
        // 插入带描述的公告数据（推荐）
        QString insertNotice = R"(
            INSERT INTO notice (title, description, publisher, pub_date) VALUES
            ('系统维护通知', '系统将于2025-07-05 00:00至06:00进行停机维护，请提前保存数据。', '管理员', '2025-07-01'),
            ('暑期放假安排', '2025年暑期放假时间为7月20日至8月20日，请各部门做好工作交接。', '管理员', '2025-07-10'),
            ('消防安全检查', '本周五下午3点开展全员消防演练，请各部门准时参加。', '管理员', '2025-07-15'),
            ('新版系统上线公告', '新一代管理系统将于2025-07-01正式上线，新增智能报表功能。', '管理员', '2025-06-25'),
            ('会议室使用规范', '即日起会议室需提前24小时预约，单次使用不得超过3小时。', '管理员', '2025-06-20')
        )";
        if (!query.exec(insertNotice)) {
            QMessageBox::warning(this, "插入失败", "初始化公告数据失败：" + query.lastError().text());
        }
    }
    //表11. license车辆进出表
    QString createlicenseTable = R"(
        CREATE TABLE IF NOT EXISTS license (
            license       TEXT,       -- 车牌号
            date        TEXT        -- 进出日期（yyyy-mm-dd）
        )
    )";
    if (!query.exec(createlicenseTable)) {
        QMessageBox::critical(this, "初始化失败", "创建 license 表失败：" + query.lastError().text());
        return;
    }

    // 检查是否需要插入初始数据
    query.exec("SELECT COUNT(*) FROM license");
    if (query.next() && query.value(0).toInt() == 0) {
        // 拟造车辆进出数据（车牌号、日期）
        query.exec(R"(
            INSERT INTO license (license, date) VALUES
            ('京A12345', '2025-07-15-08:52:59'),
            ('沪B67890', '2025-07-15-12:59:23'),
            ('京B67890', '2025-07-16-18:32:11'),
            ('京E24680', '2025-07-16-00:00:00'),
            ('川E67890', '2025-07-17-23:59:59'),
            ('京F13579', '2025-07-17-11:11:11'),
            ('鲁G44556', '2025-07-17-13:12:11'),
            ('京G86420', '2025-07-17-22:10:56')
        )");
    }
    QPalette palette;
    palette.setColor(QPalette::PlaceholderText, QColor(51, 181, 210));
    QFont font("Microsoft YaHei", 12);
    ui->lineEdit->setPalette(palette);
    ui->lineEdit->setFont(font);
    ui->lineEdit->setPlaceholderText("        用户名/手机号/ID号码");
    ui->lineEdit_2->setPalette(palette);
    ui->lineEdit_2->setFont(font);
    ui->lineEdit_2->setPlaceholderText("        密码");
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
    ui->lineEdit->setFocus();
    connect(ui->lineEdit_2, &QLineEdit::returnPressed, this, [=]() {
        on_pushButton_clicked(true);
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked(bool checked)
{
    QSqlQuery query;
    if (!query.exec("SELECT * FROM usrlist"))
    {
        QMessageBox::warning(this, "数据库错误", "查询用户信息失败：" + query.lastError().text());
        return;
    }
    QString inputID = ui->lineEdit->text().trimmed();
    QString inputPwd = ui->lineEdit_2->text().trimmed();
    while (query.next())
    {
        QString id = query.value(0).toString().trimmed();
        QString tel = query.value(1).toString().trimmed();
        QString IDcard = query.value(2).toString().trimmed();
        QString password = query.value(3).toString().trimmed();
        QString name = query.value(5).toString().trimmed();
        int mark = query.value(4).toInt();
        bool idMatch = (inputID == id || inputID == tel || inputID == IDcard);
        bool pwdMatch = (inputPwd == password);
        if (idMatch && pwdMatch)
        {
            useridentification = id.toInt();
            if (mark == 1)
            {
                QMessageBox::information(this, "提示", QString("尊贵的业主：%1 欢迎您！").arg(name));
                Owner_MainWindow *owner = new Owner_MainWindow;
                owner->show();
                this->close();
                return;
            }
            else if (mark == 2)
            {
                QMessageBox::information(this, "提示", QString("物业工作人员：%1 欢迎您！").arg(name));
                worker_MainWindow *worker = new worker_MainWindow;
                worker->show();
                this->close();
                return;
            }
            else if (mark == 0)
            {
                QMessageBox::information(this, "提示", QString("管理员：%1 欢迎您！").arg(name));
                admin_MainWindow *worker = new admin_MainWindow;
                worker->show();
                this->close();
                return;
            }
        }
    }
    QMessageBox::warning(this, "登录失败", "请输入正确的账号或密码！");
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
}
void MainWindow::on_pushButton_2_clicked(bool checked)
{
    this->close();
}

