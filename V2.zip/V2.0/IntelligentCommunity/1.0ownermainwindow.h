#ifndef OWNER_MAINWINDOW_H
#define OWNER_MAINWINDOW_H
#include <particlesystem.h>
#include <QMainWindow>
#include <DataBaseManagerAndMainWindow.h>
namespace Ui {
class Owner_MainWindow;
}

class Owner_MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit Owner_MainWindow(QWidget *parent = nullptr);
    ~Owner_MainWindow();

private:
    Ui::Owner_MainWindow *ui;
    void paintEvent(QPaintEvent *event) override;
    particlesystem *m_particlesystem;
};

#endif // OWNER_MAINWINDOW_H
