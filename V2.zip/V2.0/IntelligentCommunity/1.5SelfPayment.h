// 1.5SelfPayment.h

#ifndef SelfPayment_H
#define SelfPayment_H

#include <QWidget>
#include <QModelIndex>

namespace Ui {
class SelfPayment;
}

class SelfPayment : public QWidget
{
    Q_OBJECT

public:
    explicit SelfPayment(QWidget *parent = nullptr);
    ~SelfPayment();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_tableView_clicked(const QModelIndex &index);

private:
    Ui::SelfPayment *ui;

    int    m_selectedPayId    = -1;
    QString m_selectedType;
};

#endif // SelfPayment_H
