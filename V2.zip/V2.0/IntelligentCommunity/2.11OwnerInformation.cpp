#include "2.11OwnerInformation.h"
#include "ui_2.11OwnerInformation.h"
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QHeaderView>
#include <QStandardItemModel>
#include <QStandardItem>

OwnerInformation::OwnerInformation(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OwnerInformation)
{
    ui->setupUi(this);

    auto *placeholderModel = new QStandardItemModel(1, 1, this);
    auto *placeholderItem  = new QStandardItem(
        u8"提示：您在点击左上角查询按钮后，可以点击此处某一行信息以显示在下面的信息框中，并进行修改。");
    placeholderItem->setTextAlignment(Qt::AlignCenter);
    placeholderModel->setItem(0, 0, placeholderItem);

    ui->tableView->setModel(placeholderModel);
    ui->tableView->horizontalHeader()->setStretchLastSection(true);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableView->setAlternatingRowColors(true);
    ui->tableView->horizontalHeader()->setDefaultAlignment(Qt::AlignCenter);

    ui->tableView->setStyleSheet(R"(
        QHeaderView::section {
            background-color: #3A8DDE;
            color: white;
            padding: 4px;
            border: 1px solid #ddd;
            font-weight: bold;
        }
        QTableView {
            background-color: white;
            alternate-background-color: #f5f5f5;
        }
    )");

    ui->tableView->horizontalHeader()->hide();

    connect(ui->tableView, &QTableView::clicked,
            this, &OwnerInformation::on_tableView_clicked);
}

OwnerInformation::~OwnerInformation()
{
    delete ui;
}

void OwnerInformation::on_pushButton_clicked()
{
    QString searchname = ui->lineEdit_9->text();

    if (searchname.isEmpty()) {
        QMessageBox::information(this, "查询失败", "请输入需要查询的人员姓名！");
        return;
    }

    QString id, tel, IDcard, pwd, name, age, sex, address;
    int mark = -1;

    QSqlQuery query;
    query.exec(QString("SELECT * FROM usrlist WHERE name = '%1'").arg(searchname));
    while (query.next()) {
        mark = query.value(4).toInt();
        if (mark == 1) {
            id     = query.value(0).toString();
            tel    = query.value(1).toString();
            IDcard = query.value(2).toString();
            pwd    = query.value(3).toString();
            name   = query.value(5).toString();
        }
    }

    if (mark != 1) {
        QMessageBox::information(this, "查询失败",
                                  QString("没有叫 %1 的业主，请输入正确的姓名").arg(searchname));
        ui->lineEdit_9->clear();
        return;
    }

    query.exec(QString("SELECT * FROM information WHERE name = '%1'").arg(searchname));
    if (query.next()) {
        age     = query.value(2).toString();
        sex     = query.value(3).toString();
        address = query.value(5).toString();
    }

    ui->lineEdit->setText(name);
    ui->lineEdit_2->setText(id);
    ui->lineEdit_3->setText(tel);
    ui->lineEdit_4->setText(IDcard);
    ui->lineEdit_5->setText(pwd);
    ui->lineEdit_6->setText(sex);
    ui->lineEdit_7->setText(age);
    ui->lineEdit_8->setText(address);
    ui->lineEdit_9->clear();

    QMessageBox::information(this, "成功", "信息查询成功！");
}

void OwnerInformation::on_pushButton_2_clicked()
{
    // 获取输入数据
    QString name = ui->lineEdit->text().trimmed();
    QString id = ui->lineEdit_2->text().trimmed();
    QString tel = ui->lineEdit_3->text().trimmed();
    QString IDcard = ui->lineEdit_4->text().trimmed();
    QString pwd = ui->lineEdit_5->text().trimmed();
    QString sex = ui->lineEdit_6->text().trimmed();
    QString ageStr = ui->lineEdit_7->text().trimmed();
    QString address = ui->lineEdit_8->text().trimmed();

    // 1. 检查字段非空
    if (name.isEmpty() || id.isEmpty() || tel.isEmpty() ||
        IDcard.isEmpty() || pwd.isEmpty() || sex.isEmpty() ||
        ageStr.isEmpty() || address.isEmpty())
    {
        QMessageBox::warning(this, "插入失败", "所有字段必须填写！");
        return;
    }
    // 2. 验证年龄格式
    bool ok;
    int age = ageStr.toInt(&ok);
    if (!ok || age <= 0 || age > 120) {
        QMessageBox::warning(this, "输入错误", "年龄必须是有效数字（1-120）");
        return;
    }

    // 3. 开启事务
    QSqlDatabase::database().transaction();

    QSqlQuery query;
    QString sqlUsrlist = "INSERT INTO usrlist (id, tel, IDcard, password, mark, name) "
                         "VALUES (:id, :tel, :IDcard, :pwd, 1, :name)"; // 4. 使用参数化查询防止SQL注入
    query.prepare(sqlUsrlist);
    query.bindValue(":id", id);
    query.bindValue(":tel", tel);
    query.bindValue(":IDcard", IDcard);
    query.bindValue(":pwd", pwd);
    query.bindValue(":name", name);

    if (!query.exec()) {
        QSqlDatabase::database().rollback();
        QMessageBox::critical(this, "插入失败", "用户表写入失败：" + query.lastError().text());
        return;
    }
    QString sqlInfo = "INSERT INTO information (id, name, age, sex, tel, address) "
                      "VALUES (:id, :name, :age, :sex, :tel, :address)";
    query.prepare(sqlInfo);
    query.bindValue(":id", id);
    query.bindValue(":name", name);
    query.bindValue(":age", age);  // 整数类型
    query.bindValue(":sex", sex);
    query.bindValue(":tel", tel);
    query.bindValue(":address", address);

    if (!query.exec()) {
        QSqlDatabase::database().rollback();
        QMessageBox::critical(this, "插入失败", "信息表写入失败：" + query.lastError().text());
        return;
    }

    // 6. 提交事务
    QSqlDatabase::database().commit();

    QMessageBox::information(this, "成功", "信息写入成功！");

    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_4->clear();
    ui->lineEdit_5->clear();
    ui->lineEdit_6->clear();
    ui->lineEdit_7->clear();
    ui->lineEdit_8->clear();
}

void OwnerInformation::on_pushButton_3_clicked()
{
    // 获取用户输入
    QString name = ui->lineEdit->text().trimmed();
    QString tel = ui->lineEdit_3->text().trimmed();
    QString IDcard = ui->lineEdit_4->text().trimmed();
    QString pwd = ui->lineEdit_5->text().trimmed();
    QString sex = ui->lineEdit_6->text().trimmed();
    QString age = ui->lineEdit_7->text().trimmed();
    QString address = ui->lineEdit_8->text().trimmed();
    QString id = ui->lineEdit_2->text().trimmed(); // 只读ID

    // 验证输入
    if (name.isEmpty()) {
        QMessageBox::information(this, "修改失败", "请输入需要修改的姓名");
        return;
    }
    if (id.isEmpty()) {
        QMessageBox::information(this, "修改失败", "未指定用户ID");
        return;
    }

    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        QMessageBox::critical(this, "数据库错误", "数据库连接失败");
        return;
    }

    QString originalName;
    QSqlQuery getNameQuery;
    getNameQuery.prepare("SELECT name FROM usrlist WHERE id = ?");
    getNameQuery.addBindValue(id);
    if (getNameQuery.exec() && getNameQuery.next()) {
        originalName = getNameQuery.value(0).toString();
    } else {
        QMessageBox::critical(this, "错误", "无法获取原始用户名");
        return;
    }

    db.transaction();

    QSqlQuery usrlistQuery;
    usrlistQuery.prepare("UPDATE usrlist SET "
                         "name = :name, "
                         "tel = :tel, "
                         "IDcard = :IDcard, "
                         "password = :password "
                         "WHERE id = :id");
    usrlistQuery.bindValue(":name", name);
    usrlistQuery.bindValue(":tel", tel);
    usrlistQuery.bindValue(":IDcard", IDcard);
    usrlistQuery.bindValue(":password", pwd);
    usrlistQuery.bindValue(":id", id);

    if (!usrlistQuery.exec()) {
        db.rollback();
        QMessageBox::critical(this, "修改失败",
                             "更新用户表失败：" + usrlistQuery.lastError().text());
        return;
    }

    QSqlQuery infoQuery;
    infoQuery.prepare("UPDATE information SET "
                      "name = :name, "
                      "age = :age, "
                      "sex = :sex, "
                      "address = :address, "
                      "tel = :tel "
                      "WHERE id = :id");
    infoQuery.bindValue(":name", name);
    infoQuery.bindValue(":age", age);
    infoQuery.bindValue(":sex", sex);
    infoQuery.bindValue(":address", address);
    infoQuery.bindValue(":tel", tel);
    infoQuery.bindValue(":id", id);

    if (!infoQuery.exec()) {
        db.rollback();
        QMessageBox::critical(this, "修改失败",
                             "更新信息表失败：" + infoQuery.lastError().text());
        return;
    }

    QSqlQuery paymentQuery;
    paymentQuery.prepare("UPDATE payment SET name = :name WHERE id = :id");
    paymentQuery.bindValue(":name", name);
    paymentQuery.bindValue(":id", id);
    if (!paymentQuery.exec()) {
        // 记录错误但不中断
        qDebug() << "更新payment表失败:" << paymentQuery.lastError();
    }

    QSqlQuery weixiuQuery;
    weixiuQuery.prepare("UPDATE weixiu SET 姓名 = :name WHERE 序号 = :id");
    weixiuQuery.bindValue(":name", name);
    weixiuQuery.bindValue(":id", id);
    if (!weixiuQuery.exec()) {
        qDebug() << "更新weixiu表失败:" << weixiuQuery.lastError();
    }

    QSqlQuery attendanceQuery;
    attendanceQuery.prepare("UPDATE attendance SET name = :newName WHERE name = :oldName");
    attendanceQuery.bindValue(":newName", name);
    attendanceQuery.bindValue(":oldName", originalName);
    if (!attendanceQuery.exec()) {
        qDebug() << "更新attendance表失败:" << attendanceQuery.lastError();
    }

    QSqlQuery leaveQuery;
    leaveQuery.prepare("UPDATE leave SET name = :newName WHERE name = :oldName");
    leaveQuery.bindValue(":newName", name);
    leaveQuery.bindValue(":oldName", originalName);
    if (!leaveQuery.exec()) {
        qDebug() << "更新leave表失败:" << leaveQuery.lastError();
    }

    if (db.commit()) {
        QMessageBox::information(this, "成功", "业主信息修改成功！");
    } else {
        db.rollback();
        QMessageBox::critical(this, "提交失败", "事务提交失败：" + db.lastError().text());
    }
    on_pushButton_5_clicked();
}

void OwnerInformation::on_pushButton_4_clicked()
{
    QString name = ui->lineEdit->text();
    if (name.isEmpty()) {
        QMessageBox::information(this, "删除失败", "请输入需要删除的姓名！");
        return;
    }

    QSqlQuery query;
    if (!query.exec(QString("DELETE FROM usrlist WHERE name = '%1'").arg(name)) ||
        !query.exec(QString("DELETE FROM information WHERE name = '%1'").arg(name))) {
        QMessageBox::critical(this, "删除失败",
                              "数据库删除失败：" + query.lastError().text());
        return;
    }

    QMessageBox::information(this, "成功", "信息删除成功！");
    ui->lineEdit->clear(); ui->lineEdit_2->clear(); ui->lineEdit_3->clear();
    ui->lineEdit_4->clear(); ui->lineEdit_5->clear(); ui->lineEdit_6->clear();
    ui->lineEdit_7->clear(); ui->lineEdit_8->clear();
}

void OwnerInformation::on_pushButton_5_clicked()
{
    QSqlQuery query;
    query.prepare(R"(
        SELECT u.name, u.id, u.tel, u.IDcard, u.password,
               i.age, i.sex, i.address
        FROM usrlist u
        LEFT JOIN information i ON u.id = i.id
        WHERE u.mark = 1
    )");

    if (!query.exec()) {
        QMessageBox::critical(this, "查询失败", "无法查询业主信息：" + query.lastError().text());
        return;
    }

    auto *model = new QStandardItemModel(this);
    model->setColumnCount(8);
    model->setHorizontalHeaderLabels(
        {"姓名","登录账号","手机号","身份证号","密码","年龄","性别","住址"});

    while (query.next()) {
        QList<QStandardItem*> items;
        for (int i = 0; i < 8; ++i) {
            QStandardItem *item = new QStandardItem(query.value(i).toString());
            item->setTextAlignment(Qt::AlignCenter);
            items << item;
        }
        model->appendRow(items);
    }

    ui->tableView->setModel(model);
    ui->tableView->horizontalHeader()->show();

    ui->tableView->setColumnWidth(0, 120);   // 姓名
    ui->tableView->setColumnWidth(1, 150);   // 登录账号
    ui->tableView->setColumnWidth(2, 250);   // 手机号
    ui->tableView->setColumnWidth(3, 370);   // 身份证号
    ui->tableView->setColumnWidth(4, 150);   // 密码
    ui->tableView->setColumnWidth(5, 80);    // 年龄
    ui->tableView->setColumnWidth(6, 60);    // 性别
    ui->tableView->setColumnWidth(7, 200);   // 住址
}

void OwnerInformation::on_tableView_clicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    auto *m = ui->tableView->model();
    if (m->columnCount() < 8) return;

    const int row = index.row();
    ui->lineEdit->setText (m->index(row, 0).data().toString()); // 姓名
    ui->lineEdit_2->setText(m->index(row, 1).data().toString()); // 登录账号
    ui->lineEdit_3->setText(m->index(row, 2).data().toString()); // 手机号
    ui->lineEdit_4->setText(m->index(row, 3).data().toString()); // 身份证号
    ui->lineEdit_5->setText(m->index(row, 4).data().toString()); // 密码
    ui->lineEdit_6->setText(m->index(row, 6).data().toString()); // 性别
    ui->lineEdit_7->setText(m->index(row, 5).data().toString()); // 年龄
    ui->lineEdit_8->setText(m->index(row, 7).data().toString()); // 住址
}
