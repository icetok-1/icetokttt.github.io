#ifndef OWNER_SEARCH_H
#define OWNER_SEARCH_H

#include <QWidget>
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QTableView>
#include <string>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlRelationalTableModel>

namespace Ui {
class Trouble;
}

class Trouble : public QWidget
{
    Q_OBJECT

public:
    explicit Trouble(QWidget *parent = nullptr);
    ~Trouble();

private slots:
    void on_queryButton_clicked();
    void on_tableView_doubleClicked(const QModelIndex &index);
    void on_pushButton_2_clicked();

private:
    Ui::Trouble *ui;
     QSqlDatabase db;
   void tableshow();
};

#endif // OWNER_SEARCH_H
