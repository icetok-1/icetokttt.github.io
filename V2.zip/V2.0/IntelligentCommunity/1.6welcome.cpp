#include "1.6welcome.h"
#include "ui_1.6welcome.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QLabel>
#include <QGraphicsDropShadowEffect>
extern int useridentification;

Welcome::Welcome(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Welcome)
{
    ui->setupUi(this);

    QSqlQuery query;
    query.prepare("SELECT name FROM usrlist WHERE id = :id");
    query.bindValue(":id", useridentification);
    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "查询失败: " + query.lastError().text());
        return;
    }
    QString name = "用户";
    if (query.next()) {
        name = query.value("name").toString().trimmed();
    } else {
        QMessageBox::warning(this, "查询失败", "未找到用户信息");
    }
    ui->Label->setText("欢迎您!  " + name);
    ui->Label->setGeometry(420,400, 600, 100);
    ui->Label->setStyleSheet(QString(
        "QLabel {"
        "font: bold 80px '微软雅黑';"
        "color: rgb(34, 134, 167);"
        "font-style: italic;"
        "}"
    ));
}
Welcome::~Welcome()
{
    delete ui;
}
